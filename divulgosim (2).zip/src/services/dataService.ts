import { 
    RaveEvent, EventCategory, User, UserType, UserProfile, RBLevel,
    Task, Campaign, CampaignApplication, Invitation, Excursion, Passenger, 
    ExcursionApplication, GigApplication, PerformanceApplication, TicketSale, 
    Notification, RBTransaction, DailyMission, RewardStoreItem, DecorationProject,
    Equipment, Product, Message, Conversation, Post, Track, Performance, Photo,
    Video, Order, CoverageRequest, SocialPlatform, Placement, ProductCategory, PostComment,
    Cart,
    RealTransaction,
    GigProposal,
    EquipmentCategory,
    OrderStatus,
    NotificationType
} from '../types.ts';

// Mercado Pago Test Credentials
const MERCADO_PAGO_ACCESS_TOKEN = 'APP_USR-286c6d62-7853-425d-92f2-b8d82e9e9add';

// Helper to create a deep copy to avoid mutation issues
const deepCopy = <T>(obj: T): T => JSON.parse(JSON.stringify(obj));

const today = new Date();
const currentYear = today.getFullYear();
const currentMonth = today.getMonth(); // 0-11
const currentDate = today.getDate();

const categories = Object.values(EventCategory);

// Generate dynamic sample events to ensure they are always visible
const sampleEvents: Omit<RaveEvent, 'id' | 'organizerId' | 'services' | 'comments' | 'gallery' | 'videos'>[] = [];

// 1. Universo Paralello - always upcoming new year
sampleEvents.push({
    name: 'Universo Paralello',
    category: EventCategory.FESTIVAL,
    dates: [`${currentYear}-12-27`, `${currentYear}-12-28`, `${currentYear}-12-29`, `${currentYear}-12-30`, `${currentYear}-12-31`, `${currentYear + 1}-01-01`, `${currentYear + 1}-01-02`, `${currentYear + 1}-01-03`],
    dateString: `27/Dez a 03/Jan`,
    location: 'Praia de Pratigi, BA',
    tickets: [
        { id: 't1', name: 'Lote 3', price: 1200, quantity: 5000, sold: 4800 },
        { id: 't2', name: 'Lote 4', price: 1450, quantity: 2000, sold: 0 },
    ],
    description: 'O maior festival de cultura alternativa do Brasil, celebrando a virada de ano com muita música e arte.',
    image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60',
    commissionRate: 0.1,
});

// 2. XXXPerience - November of current or next year
const xxxYear = (currentMonth > 10 || (currentMonth === 10 && currentDate > 15)) ? currentYear + 1 : currentYear;
sampleEvents.push({
    name: 'XXXPerience',
    category: EventCategory.FESTIVAL,
    dates: [`${xxxYear}-11-15`],
    dateString: `15 de Novembro de ${xxxYear}`,
    location: 'Arena Maeda, Itu/SP',
    tickets: [
        { id: 't3', name: 'Pista Lote 1', price: 250, quantity: 2000, sold: 2000 },
        { id: 't4', name: 'Pista Lote 2', price: 300, quantity: 3000, sold: 1500 },
        { id: 't5', name: 'VIP', price: 450, quantity: 1000, sold: 800 },
    ],
    description: 'Um dos festivais mais tradicionais de música eletrônica do Brasil, comemorando mais uma edição histórica.',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60',
    commissionRate: 0.1,
});

// 3. Generate a few events for the next few months
let eventDate = new Date();
eventDate.setDate(eventDate.getDate() + 3); // Start 3 days from now

for (let i = 0; i < 15; i++) {
    const dateStr = eventDate.toISOString().split('T')[0];
    const day = eventDate.getDate();
    const monthName = eventDate.toLocaleString('pt-BR', { month: 'long' });

    sampleEvents.push({
        name: `Rave Exemplo #${i + 1}`,
        category: categories[i % categories.length],
        dates: [dateStr],
        dateString: `${day} de ${monthName}`,
        location: 'Local Aleatório, BR',
        tickets: [{ id: `t-dyn-${i}`, name: 'Pista', price: 100 + i * 5, quantity: 500, sold: 50 + i * 10 }],
        description: `Descrição do evento de exemplo #${i + 1}.`,
        image: `https://picsum.photos/800/600?random=${i + 10}`,
        commissionRate: 0.1,
    });

    eventDate.setDate(eventDate.getDate() + (i % 4 + 3)); // Add 3-6 days for the next event
}

const samplePosts: Post[] = [
    {
        id: 'post1',
        userId: 'user-organizer-1',
        mediaUrl: 'https://images.unsplash.com/photo-1543364195-bfe6e49023e3?auto=format&fit=crop&q=80&w=1770&ixlib=rb-4.0.3',
        mediaType: 'image',
        caption: 'Preparando a próxima edição! Vai ser histórico. 🔥 #rave #festival',
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), // 2 days ago
        likes: ['user-promoter-1'],
        comments: [
            { id: 'p1c1', userId: 'user-promoter-1', text: 'Não vejo a hora!', createdAt: new Date(Date.now() - 86400000).toISOString() }
        ]
    },
    {
        id: 'post2',
        userId: 'user-promoter-1',
        mediaUrl: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&q=80&w=1770&ixlib-rb-4.0.3',
        mediaType: 'image',
        caption: 'Quem vai colar na XXXPerience? Me chama pra garantir seu ingresso!',
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(), // 5 hours ago
        likes: ['user-organizer-1', 'user-photographer-1'],
        comments: []
    },
    {
        id: 'post3',
        userId: 'user-organizer-1',
        mediaUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        mediaType: 'video',
        caption: 'Testando um post de vídeo! 🎬 #video #test',
        createdAt: new Date(Date.now() - 3600000 * 10).toISOString(), // 10 hours ago
        likes: ['user-promoter-1'],
        comments: []
    }
];

const baseProfile: UserProfile = {
    personal: { fullName: '', username: '', birthDate: '', phone: '', profilePicture: null, cpf: '', rg: '' },
    address: { cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '', country: 'Brasil' },
    social: { instagram: '', facebook: '', tiktok: '', linkedin: '', youtube: '', website: '' },
    medical: { 
        bloodType: '', allergies: '', medications: '', conditions: '', 
        emergencyContacts: [{name: '', phone: '', relationship: ''}], 
        chronicDiseases: '', surgeries: '', recentTreatments: '', 
        primaryCarePhysician: { name: '', phone: '', email: '' }, 
        preferredHospital: '', 
        healthInsurance: { provider: '', policyNumber: '', validity: '', category: '', emergencyPhone: '' }, 
        religion: '', specialNeeds: '', medicalDevices: '', 
        lastUpdated: new Date().toISOString(), 
        attachedDocuments: [] 
    }
};

let allUsers: User[] = [
    {
        id: 'user-organizer-1', email: 'organizador@demo.com', roles: [UserType.ORGANIZER, UserType.STORE_OWNER],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Organizador Chefe', username: 'organizadorchefe', profilePicture: 'https://i.pravatar.cc/150?u=org' }},
        plan: 'premium', subscriptionStatus: 'active',
        realBalance: 500.00,
        rbBalance: 15000, rbLevel: RBLevel.PLATINA,
        cart: { items: [], total: 0 },
        followers: ['user-promoter-1'],
        following: ['user-promoter-1', 'user-photographer-1'],
        posts: samplePosts.filter(p => p.userId === 'user-organizer-1'),
    },
    {
        id: 'user-photographer-1',
        email: 'fotografo@demo.com',
        roles: [UserType.PHOTOGRAPHER],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Click Mágico', username: 'clickmagico', profilePicture: 'https://i.pravatar.cc/150?u=photographer' }},
        portfolio: [], isVerified: true, 
        realBalance: 150.75,
        rbBalance: 850, rbLevel: RBLevel.PRATA,
        cart: { items: [], total: 0 },
        followers: ['user-organizer-1'],
        following: [],
    },
    {
        id: 'user-promoter-1',
        email: 'promoter@demo.com',
        roles: [UserType.PROMOTER, UserType.INFLUENCER, UserType.USER],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Promoter Top', username: 'promotertop', profilePicture: 'https://i.pravatar.cc/150?u=promoter' }},
        isVerified: true, 
        realBalance: 25.50,
        rbBalance: 1250, rbLevel: RBLevel.PRATA, followingEvents: ['event-2'],
        cart: { items: [], total: 0 },
        followers: ['user-organizer-1'],
        following: ['user-organizer-1'],
        posts: samplePosts.filter(p => p.userId === 'user-promoter-1'),
    },
    {
        id: 'user-dj-1',
        email: 'dj@demo.com',
        roles: [UserType.DJ],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'DJ Beatmaster', username: 'djbeatmaster', profilePicture: 'https://i.pravatar.cc/150?u=dj' }},
        isVerified: true,
        realBalance: 1200.00,
        rbBalance: 2500, rbLevel: RBLevel.OURO,
        cart: { items: [], total: 0 },
        followers: [],
        following: [],
    },
    {
        id: 'user-artist-1',
        email: 'artista@demo.com',
        roles: [UserType.ARTIST],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Artista performático', username: 'artista', profilePicture: 'https://i.pravatar.cc/150?u=artist' }},
        isVerified: true,
        realBalance: 300.00,
        rbBalance: 750, rbLevel: RBLevel.PRATA,
        cart: { items: [], total: 0 },
        followers: [],
        following: [],
        performances: [
            { id: 'perf1', userId: 'user-artist-1', name: 'Dança com Fogo', description: 'Performance de dança com malabares de fogo.', duration: 15, category: 'Dança', technicalNeeds: 'Espaço aberto de 10x10m, extintor de incêndio próximo.', createdAt: new Date().toISOString() }
        ]
    },
    {
        id: 'user-sound-1',
        email: 'som@demo.com',
        roles: [UserType.SOUND_LIGHTING],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Som & Luz Pro', username: 'somluzpro', profilePicture: 'https://i.pravatar.cc/150?u=sound' }},
        isVerified: true,
        realBalance: 5000.00,
        rbBalance: 1000, rbLevel: RBLevel.PRATA,
        cart: { items: [], total: 0 },
        followers: [],
        following: []
    },
    {
        id: 'user-deco-1',
        email: 'deco@demo.com',
        roles: [UserType.DECORATION],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Decoração Psicodélica', username: 'decopsi', profilePicture: 'https://i.pravatar.cc/150?u=deco' }},
        isVerified: true,
        realBalance: 2500.00,
        rbBalance: 1800, rbLevel: RBLevel.PRATA,
        cart: { items: [], total: 0 },
        followers: [],
        following: []
    }
];

let allEvents: RaveEvent[] = sampleEvents.map((e, i) => ({
    ...e,
    id: `event-${i+1}`,
    organizerId: 'user-organizer-1',
    services: [],
    comments: [],
    gallery: [],
    videos: []
}));

let allTracks: Track[] = [
    { id: 'track-1', userId: 'user-dj-1', title: 'Psychedelic Sunrise', genre: 'Psytrance', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', createdAt: new Date().toISOString(), coverUrl: 'https://picsum.photos/200/200?random=track1', description: 'Uma jornada psicodélica pelo amanhecer.' },
    { id: 'track-2', userId: 'user-dj-1', title: 'Midnight Drive', genre: 'Techno', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', createdAt: new Date(Date.now() - 86400000 * 5).toISOString(), coverUrl: 'https://picsum.photos/200/200?random=track2', description: 'A trilha sonora perfeita para uma viagem noturna.' },
];

let allGigProposals: GigProposal[] = [
    { id: 'prop-1', eventId: 'event-1', djId: 'user-dj-1', organizerId: 'user-organizer-1', status: 'pending' },
    { id: 'prop-2', eventId: 'event-2', djId: 'user-dj-1', organizerId: 'user-organizer-1', status: 'accepted' },
];

// Add some initial data for relationships

let allCoverageRequests: CoverageRequest[] = [];
let allTasks: Task[] = [
    { 
        id: 'task-1', 
        eventId: 'event-2', // XXXPerience
        title: 'Post sobre a XXXPerience no Instagram', 
        description: 'Faça um post no feed sobre a próxima XXXPerience, use a #xxxperience e marque o perfil oficial.', 
        deadline: new Date(new Date().setDate(new Date().getDate() + 10)).toISOString().split('T')[0],
        rewardRB: 50,
        platform: SocialPlatform.INSTAGRAM,
        placement: Placement.FEED,
        assigneeId: 'user-promoter-1',
        status: 'completed',
        link: 'https://instagram.com/p/12345'
    },
    { 
        id: 'task-2', 
        eventId: 'event-1', // Universo Paralello
        title: 'Stories sobre o Universo Paralello', 
        description: 'Postar uma sequência de 3 stories sobre a venda de ingressos do Lote 4.', 
        deadline: new Date(new Date().setDate(new Date().getDate() + 5)).toISOString().split('T')[0],
        rewardRB: 25,
        platform: SocialPlatform.INSTAGRAM,
        placement: Placement.STORY,
        assigneeId: 'user-promoter-1',
        status: 'approved'
    },
    { 
        id: 'task-3', 
        eventId: 'event-3', // Rave Exemplo #1
        title: 'Divulgar Rave Exemplo #1 no Facebook', 
        description: 'Compartilhar o evento no seu perfil do Facebook.', 
        deadline: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split('T')[0],
        rewardRB: 15,
        platform: SocialPlatform.FACEBOOK,
        placement: Placement.POST,
        status: 'pending' // No assignee yet
    }
];
let allCampaigns: Campaign[] = [];
let allCampaignApplications: CampaignApplication[] = [];
let allInvitations: Invitation[] = [];
let allExcursions: Excursion[] = [];
let allPassengers: Passenger[] = [];
let allExcursionApplications: ExcursionApplication[] = [];
let allGigApplications: GigApplication[] = [];
let allPerformanceApplications: PerformanceApplication[] = [];
let allTicketSales: TicketSale[] = [
    {
        id: 'sale-1',
        eventId: 'event-2', // XXXPerience
        buyerId: 'user-promoter-1',
        ticketId: 't4',
        ticketName: 'Pista Lote 2',
        quantity: 2,
        pricePerTicket: 300,
        soldAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    },
    {
        id: 'sale-2',
        eventId: 'event-1', // Universo Paralello
        buyerId: 'user-promoter-1',
        ticketId: 't1',
        ticketName: 'Lote 3',
        quantity: 1,
        pricePerTicket: 1200,
        soldAt: new Date(Date.now() - 86400000 * 10).toISOString(),
    },
    {
        id: 'sale-3',
        eventId: 'event-3', // Rave Exemplo #1
        buyerId: 'user-dj-1',
        ticketId: 't-dyn-0',
        ticketName: 'Pista',
        quantity: 4,
        pricePerTicket: 100,
        soldAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    }
];
let allNotifications: Notification[] = [
    {
        id: 'notif-1',
        userId: 'user-organizer-1',
        message: 'O fotógrafo Click Mágico solicitou cobertura para o evento XXXPerience.',
        type: NotificationType.REQUEST,
        isRead: false,
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(), // 2 hours ago
        relatedEntityId: 'event-2',
    },
    {
        id: 'notif-2',
        userId: 'user-promoter-1',
        message: 'Sua tarefa "Post sobre a XXXPerience no Instagram" foi aprovada!',
        type: NotificationType.INFO,
        isRead: false,
        createdAt: new Date(Date.now() - 3600000 * 5).toISOString(), // 5 hours ago
    },
    {
        id: 'notif-3',
        userId: 'user-organizer-1',
        message: 'Lembrete: O evento Universo Paralello começa em menos de 10 dias.',
        type: NotificationType.ALERT,
        isRead: true,
        createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
    },
     {
        id: 'notif-4',
        userId: 'user-dj-1',
        message: 'Você foi convidado para tocar no evento Rave Exemplo #5.',
        type: NotificationType.INVITE,
        isRead: false,
        createdAt: new Date().toISOString(),
    },
];

let allRbTransactions: RBTransaction[] = [
    { id: 'rbtx1', userId: 'user-promoter-1', type: 'earn-task', description: 'Post no Instagram: XXXPerience', amountRB: 10, timestamp: new Date(Date.now() - 86400000 * 2).toISOString(), status: 'completed' },
    { id: 'rbtx2', userId: 'user-promoter-1', type: 'daily-mission', description: 'Check-in Diário', amountRB: 10, timestamp: new Date(Date.now() - 86400000 * 1).toISOString(), status: 'completed' },
    { id: 'rbtx3', userId: 'user-promoter-1', type: 'earn-task', description: 'Story: Universo Paralello', amountRB: 5, timestamp: new Date().toISOString(), status: 'completed' },
    { id: 'rbtx4', userId: 'user-organizer-1', type: 'purchase', description: 'Compra de Pacote Pro', amountRB: 15000, timestamp: new Date().toISOString(), status: 'completed' },
    { id: 'rbtx5', userId: 'user-photographer-1', type: 'earn-task', description: 'Bônus de Cobertura de Evento', amountRB: 500, timestamp: new Date().toISOString(), status: 'completed' },
];

let allRealTransactions: RealTransaction[] = [
    { id: 'realtx1', userId: 'user-organizer-1', type: 'deposit', description: 'Depósito inicial', amount: 500.00, timestamp: new Date(Date.now() - 86400000 * 5).toISOString(), status: 'completed' },
    { id: 'realtx2', userId: 'user-photographer-1', type: 'deposit', description: 'Depósito inicial', amount: 150.75, timestamp: new Date(Date.now() - 86400000 * 5).toISOString(), status: 'completed' },
    { id: 'realtx3', userId: 'user-promoter-1', type: 'deposit', description: 'Depósito inicial', amount: 25.50, timestamp: new Date(Date.now() - 86400000 * 5).toISOString(), status: 'completed' },
];

let allRewardStoreItems: RewardStoreItem[] = [
    { id: 'rew1', name: 'Adesivo Exclusivo DivulgoSim', description: 'Mostre seu apoio com um adesivo de alta qualidade.', icon: '✨', priceRB: 150 },
    { id: 'rew2', name: 'Copo Oficial do Evento X', description: 'Leve uma lembrança para casa.', icon: '🥤', priceRB: 500 },
    { id: 'rew3', name: 'Desconto de 10% no Ingresso', description: 'Use seus RBs para economizar na próxima compra.', icon: '🎟️', priceRB: 1000 },
    { id: 'rew4', name: 'Acesso VIP ao Backstage', description: 'Uma experiência única para os mais dedicados.', icon: '⭐', priceRB: 5000 },
];

let allDailyMissions: DailyMission[] = [{id: 'dm1', title: 'Check-in Diário', description: 'Faça check-in para ganhar RB!', target: 1, progress: 0, rewardRB: 10, isCompleted: false}];
let allDecorationProjects: DecorationProject[] = [
    {
        id: 'deco-proj-1',
        userId: 'user-deco-1',
        name: 'Palco Floresta Encantada',
        description: 'Projeto de decoração para palco principal com tema de floresta psicodélica, usando lycra tensionada e projeção mapeada.',
        coverImage: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?auto=format&fit=crop&q=80&w=1770&ixlib=rb-4.0.3',
        images: [
            'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&q=80&w=1770&ixlib=rb-4.0.3',
            'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?auto=format&fit=crop&q=80&w=1770&ixlib=rb-4.0.3'
        ],
        videos: [],
    },
    {
        id: 'deco-proj-2',
        userId: 'user-deco-1',
        name: 'Tenda Chill Out Galáctico',
        description: 'Decoração para área de descanso com tema espacial, estrelas, nebulosas e iluminação UV.',
        coverImage: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?auto=format&fit=crop&q=80&w=1771&ixlib-rb-4.0.3',
        images: [],
        videos: [],
    }
];
let allEquipment: Equipment[] = [
     { id: 'equip1', ownerId: 'user-sound-1', name: 'CDJ-3000', category: EquipmentCategory.MIXER, price: 500, description: 'Pioneer CDJ-3000 Professional DJ Multi Player.', images: ['https://picsum.photos/400/400?random=equip1'], brand: 'Pioneer', power: '30W', voltage: 'Bivolt', videos: [] },
     { id: 'equip2', ownerId: 'user-sound-1', name: 'Moving Head Beam', category: EquipmentCategory.LIGHTING, price: 150, description: 'Moving Head Beam 7R para iluminação de palco.', images: ['https://picsum.photos/400/400?random=equip2'], brand: 'Genérico', power: '230W', voltage: '220v', videos: [] },
];
let allProducts: Product[] = [
    // FIX: Changed 'imageUrl' to 'images' array to match the Product type.
    { id: 'prod1', storeOwnerId: 'user-organizer-1', name: 'Copo Oficial Universo Paralello', category: ProductCategory.ACCESSORY, price: 45, description: 'Copo ecológico oficial do UP 2025.', images: ['https://picsum.photos/400/400?random=prod1'], stock: 500, videos: [] },
    // FIX: Changed 'imageUrl' to 'images' array to match the Product type.
    { id: 'prod2', storeOwnerId: 'user-organizer-1', name: 'Camiseta XXXPerience 2024', category: ProductCategory.APPAREL, price: 90, description: 'Camiseta de algodão com estampa exclusiva.', images: ['https://picsum.photos/400/400?random=prod2'], stock: 200, videos: [] },
];
let allMessages: Message[] = [];
let allConversations: Conversation[] = [];
let allOrders: Order[] = [
    {
        id: 'order-1',
        storeOwnerId: 'user-organizer-1',
        buyerId: 'user-promoter-1',
        items: [
            { productId: 'prod2', productName: 'Camiseta XXXPerience 2024', quantity: 1, price: 90 },
            { productId: 'prod1', productName: 'Copo Oficial Universo Paralello', quantity: 2, price: 45 },
        ],
        total: 180,
        status: OrderStatus.PROCESSING,
        createdAt: new Date(Date.now() - 86400000).toISOString(),
    },
    {
        id: 'order-2',
        storeOwnerId: 'user-organizer-1',
        buyerId: 'user-dj-1',
        items: [
            { productId: 'prod2', productName: 'Camiseta XXXPerience 2024', quantity: 2, price: 90 },
        ],
        total: 180,
        status: OrderStatus.DELIVERED,
        createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
    }
];


// Export functions that return deep copies to simulate immutability
export const dataService = {
  getUsers: async (): Promise<User[]> => deepCopy(allUsers),
  getEvents: async (): Promise<RaveEvent[]> => deepCopy(allEvents),
  getTasks: async (): Promise<Task[]> => deepCopy(allTasks),
  getTracks: async (): Promise<Track[]> => deepCopy(allTracks),
  getGigProposals: async (): Promise<GigProposal[]> => deepCopy(allGigProposals),
  getCoverageRequests: async (): Promise<CoverageRequest[]> => deepCopy(allCoverageRequests),
  getCampaigns: async (): Promise<Campaign[]> => deepCopy(allCampaigns),
  getCampaignApplications: async (): Promise<CampaignApplication[]> => deepCopy(allCampaignApplications),
  getInvitations: async (): Promise<Invitation[]> => deepCopy(allInvitations),
  getExcursions: async (): Promise<Excursion[]> => deepCopy(allExcursions),
  getPassengers: async (): Promise<Passenger[]> => deepCopy(allPassengers),
  getExcursionApplications: async (): Promise<ExcursionApplication[]> => deepCopy(allExcursionApplications),
  getGigApplications: async (): Promise<GigApplication[]> => deepCopy(allGigApplications),
  getPerformanceApplications: async (): Promise<PerformanceApplication[]> => deepCopy(allPerformanceApplications),
  getTicketSales: async (): Promise<TicketSale[]> => deepCopy(allTicketSales),
  getNotifications: async (): Promise<Notification[]> => deepCopy(allNotifications),
  getRbTransactions: async (): Promise<RBTransaction[]> => deepCopy(allRbTransactions),
  getRealTransactions: async (): Promise<RealTransaction[]> => deepCopy(allRealTransactions),
  getDailyMissions: async (): Promise<DailyMission[]> => deepCopy(allDailyMissions),
  getRewardStoreItems: async (): Promise<RewardStoreItem[]> => deepCopy(allRewardStoreItems),
  getDecorationProjects: async (): Promise<DecorationProject[]> => deepCopy(allDecorationProjects),
  getEquipment: async (): Promise<Equipment[]> => deepCopy(allEquipment),
  getProducts: async (): Promise<Product[]> => deepCopy(allProducts),
  getMessages: async (): Promise<Message[]> => deepCopy(allMessages),
  getConversations: async (): Promise<Conversation[]> => deepCopy(allConversations),
  getOrders: async (): Promise<Order[]> => deepCopy(allOrders),

  
  login: async (email: string): Promise<User | undefined> => {
    const user = allUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    return user ? deepCopy(user) : undefined;
  },

  updateUser: async (updatedUser: User): Promise<User> => {
      allUsers = allUsers.map(u => u.id === updatedUser.id ? updatedUser : u);
      return deepCopy(updatedUser);
  },
  
  saveEvent: async (eventData: Omit<RaveEvent, 'id' | 'organizerId' | 'comments' | 'gallery' | 'videos' | 'services'> & { id?: string }): Promise<RaveEvent> => {
      if (eventData.id) {
          const index = allEvents.findIndex(e => e.id === eventData.id);
          if (index !== -1) {
              allEvents[index] = { ...allEvents[index], ...eventData };
              return deepCopy(allEvents[index]);
          }
      }
      const newEvent: RaveEvent = {
          organizerId: 'user-organizer-1', // Assuming a logged in user
          comments: [],
          gallery: [],
          videos: [],
          services: [],
          ...eventData,
          id: `event-${Date.now()}`,
      };
      allEvents.push(newEvent);
      return deepCopy(newEvent);
  },

   addPost: async (newPost: Post): Promise<Post> => {
    const userIndex = allUsers.findIndex(u => u.id === newPost.userId);
    if (userIndex > -1) {
        if (!allUsers[userIndex].posts) {
            allUsers[userIndex].posts = [];
        }
        allUsers[userIndex].posts!.unshift(newPost);
    }
    return deepCopy(newPost);
  },
  
  requestWithdrawal: async (userId: string, amountRB: number): Promise<{ user: User, transaction: RBTransaction }> => {
    const user = allUsers.find(u => u.id === userId);
    if (!user || user.rbBalance < amountRB) {
        throw new Error("Saldo insuficiente ou usuário não encontrado.");
    }
    user.rbBalance -= amountRB;
    const newTransaction: RBTransaction = {
        id: `rbtx-${Date.now()}`,
        userId,
        type: 'withdraw-request',
        description: `Solicitação de saque de ${amountRB} RB`,
        amountRB: -amountRB,
        timestamp: new Date().toISOString(),
        status: 'pending'
    };
    allRbTransactions.push(newTransaction);
    return { user: deepCopy(user), transaction: deepCopy(newTransaction) };
  },

  redeemReward: async (userId: string, itemId: string): Promise<{ user: User, transaction: RBTransaction }> => {
    const user = allUsers.find(u => u.id === userId);
    const item = allRewardStoreItems.find(i => i.id === itemId);
    if (!user || !item || user.rbBalance < item.priceRB) {
        throw new Error("Saldo insuficiente ou item/usuário não encontrado.");
    }
    user.rbBalance -= item.priceRB;
    const newTransaction: RBTransaction = {
        id: `rbtx-${Date.now()}`,
        userId,
        type: 'redeem-item',
        description: `Resgate: ${item.name}`,
        amountRB: -item.priceRB,
        timestamp: new Date().toISOString(),
        status: 'completed'
    };
    allRbTransactions.push(newTransaction);
    return { user: deepCopy(user), transaction: deepCopy(newTransaction) };
  },

  checkout: async (userId: string, cart: Cart): Promise<{ user: User, updatedEvents: RaveEvent[], newSales: TicketSale[], newTransaction: RealTransaction }> => {
    const user = allUsers.find(u => u.id === userId);
    if (!user) throw new Error("Usuário não encontrado.");
    if (user.realBalance < cart.total) throw new Error("Saldo insuficiente para completar a compra.");
    
    user.realBalance -= cart.total;
    
    const newSales: TicketSale[] = [];
    const updatedEvents: RaveEvent[] = [];
    const eventIdsToUpdate = new Set(cart.items.map(item => item.eventId));

    eventIdsToUpdate.forEach(eventId => {
        const event = allEvents.find(e => e.id === eventId);
        if (event) {
            const itemsForThisEvent = cart.items.filter(item => item.eventId === eventId);
            itemsForThisEvent.forEach(item => {
                const ticket = event.tickets.find(t => t.id === item.ticketId);
                if (ticket) {
                    ticket.sold = (ticket.sold || 0) + item.quantity;
                }
                const newSale: TicketSale = {
                    id: `sale-${Date.now()}-${Math.random()}`,
                    eventId: item.eventId,
                    buyerId: user.id,
                    ticketId: item.ticketId,
                    ticketName: item.ticketName,
                    quantity: item.quantity,
                    pricePerTicket: item.price,
                    soldAt: new Date().toISOString(),
                };
                newSales.push(newSale);
            });
            updatedEvents.push(event);
        }
    });

    const newTransaction: RealTransaction = {
        id: `realtx-${Date.now()}`,
        userId: user.id,
        type: 'purchase',
        description: `Compra de ${cart.items.length} tipo(s) de ingresso(s)`,
        amount: -cart.total,
        timestamp: new Date().toISOString(),
        status: 'completed',
    };
    allRealTransactions.push(newTransaction);
    allTicketSales.push(...newSales);

    // Clear user cart
    user.cart = { items: [], total: 0 };

    return {
        user: deepCopy(user),
        updatedEvents: deepCopy(updatedEvents),
        newSales: deepCopy(newSales),
        newTransaction: deepCopy(newTransaction),
    }
  },
  
  savePerformance: async (performanceData: Omit<Performance, 'id' | 'userId' | 'createdAt'> & {id?: string}, userId: string): Promise<Performance> => {
      let savedPerformance: Performance;
      const user = allUsers.find(u => u.id === userId);
      if (!user) throw new Error("Usuário não encontrado.");

      if (performanceData.id) {
           const index = (user.performances || []).findIndex(p => p.id === performanceData.id);
           if (index > -1) {
               user.performances![index] = { ...user.performances![index], ...performanceData };
               savedPerformance = user.performances![index];
           } else {
                throw new Error("Performance não encontrada.");
           }
      } else {
          savedPerformance = {
              ...performanceData,
              id: `perf-${Date.now()}`,
              userId: userId,
              createdAt: new Date().toISOString(),
          };
          if (!user.performances) user.performances = [];
          user.performances.push(savedPerformance);
      }
      return deepCopy(savedPerformance);
  },

  deletePerformance: async (performanceId: string, userId: string): Promise<boolean> => {
      const user = allUsers.find(u => u.id === userId);
      if (!user || !user.performances) return false;
      const initialLength = user.performances.length;
      user.performances = user.performances.filter(p => p.id !== performanceId);
      return user.performances.length < initialLength;
  },

  saveEquipment: async (equipmentData: Omit<Equipment, 'id' | 'ownerId'> & { id?: string }, userId: string): Promise<Equipment> => {
      let savedEquipment: Equipment;
       if (equipmentData.id) {
          const index = allEquipment.findIndex(e => e.id === equipmentData.id && e.ownerId === userId);
          if (index !== -1) {
              allEquipment[index] = { ...allEquipment[index], ...equipmentData };
              return deepCopy(allEquipment[index]);
          }
           throw new Error("Equipment not found or user mismatch.");
      } else {
          savedEquipment = {
              ...equipmentData,
              id: `equip-${Date.now()}`,
              ownerId: userId,
          };
          allEquipment.push(savedEquipment);
      }
      return deepCopy(savedEquipment);
  },
  
  deleteEquipment: async (equipmentId: string, userId: string): Promise<boolean> => {
      const initialLength = allEquipment.length;
      allEquipment = allEquipment.filter(e => !(e.id === equipmentId && e.ownerId === userId));
      return allEquipment.length < initialLength;
  },

  saveDecorationProject: async (projectData: Omit<DecorationProject, 'id' | 'userId'> & { id?: string }, userId: string): Promise<DecorationProject> => {
        let savedProject: DecorationProject;
        if (projectData.id) {
            const index = allDecorationProjects.findIndex(p => p.id === projectData.id && p.userId === userId);
            if (index !== -1) {
                allDecorationProjects[index] = { ...allDecorationProjects[index], ...projectData };
                return deepCopy(allDecorationProjects[index]);
            }
            throw new Error("Project not found or user mismatch.");
        } else {
            savedProject = {
                ...projectData,
                id: `deco-${Date.now()}`,
                userId: userId,
            };
            allDecorationProjects.push(savedProject);
        }
        return deepCopy(savedProject);
  },

    deleteDecorationProject: async (projectId: string, userId: string): Promise<boolean> => {
        const initialLength = allDecorationProjects.length;
        allDecorationProjects = allDecorationProjects.filter(p => !(p.id === projectId && p.userId === userId));
        return allDecorationProjects.length < initialLength;
    },
    
    updateOrder: async (orderId: string, newStatus: OrderStatus): Promise<Order | undefined> => {
        const orderIndex = allOrders.findIndex(o => o.id === orderId);
        if (orderIndex > -1) {
            allOrders[orderIndex].status = newStatus;
            return deepCopy(allOrders[orderIndex]);
        }
        return undefined;
    },
};