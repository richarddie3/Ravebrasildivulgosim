// FIX: Switched to Firebase v8 namespaced/compat imports to resolve errors with modular (v9+) syntax.
// FIX: Corrected Firebase imports to use the v9 compat layer, which provides the v8 namespaced API. This resolves errors where methods like `initializeApp` were not found.
import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";
import "firebase/compat/storage";

const firebaseConfig = {
  // FIX: Switched from import.meta.env to process.env to resolve typing errors and for consistency with other services in the project.
  apiKey: process.env.VITE_FIREBASE_API_KEY,
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.VITE_FIREBASE_APP_ID,
};

// FIX: Switched to Firebase v8 API calls for initialization and service access to match the v8 import style.
const app = firebase.initializeApp(firebaseConfig);
export const auth = firebase.auth();
export const db = firebase.firestore();
export const storage = firebase.storage();
