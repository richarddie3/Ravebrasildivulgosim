import React, { useState, useEffect, useMemo, useCallback } from 'react';

import Calendar from './components/Calendar.tsx';
import EventList from './components/calendar/EventList.tsx';
import Toast from './components/Toast.tsx';
import LoginModal from './components/modals/LoginModal.tsx';
import RegisterModal from './components/modals/RegisterModal.tsx';
import EventsDayModal from './components/modals/EventsDayModal.tsx';
import EventDetailModal from './components/modals/EventDetailModal.tsx';
import AllEventsModal from './components/modals/AllEventsModal.tsx';
import ProfileView from './components/ProfileView.tsx';
import MainMenu from './components/MainMenu.tsx';
import PublicProfileModal from './components/modals/PublicProfileModal.tsx';
import ChatView from './components/ChatView.tsx';
import { HeartIcon, UserIcon as UserIconDefault, CalendarPlusIcon, ShoppingCartIcon } from './components/Icons.tsx';
import EventModal from './components/modals/EventModal.tsx';
import { ProductModal } from './components/modals/ProductModal.tsx';
import TaskModal from './components/modals/TaskModal.tsx';
import { ManageEventModal } from './components/modals/ManageEventModal.tsx';
import { CreateCampaignModal } from './components/modals/CreateCampaignModal.tsx';
import InviteUserModal from './components/modals/InviteUserModal.tsx';
import { ManageGalleryModal } from './components/ManageGalleryModal.tsx';
import WithdrawalModal from './components/modals/WithdrawalModal.tsx';
import RewardStoreModal from './components/modals/RewardStoreModal.tsx';
import { FollowedEventsView } from './components/FollowedEventsView.tsx';
import DashboardView from './components/DashboardView.tsx';
import { FeedView } from './components/FeedView.tsx';
import { CartModal } from './components/modals/CartModal.tsx';
import ShopView from './components/ShopView.tsx';
import UploadTrackModal from './components/modals/UploadTrackModal.tsx';
import ExcursionsView from './components/TripOrganizerDashboard.tsx';
import DJDashboard from './components/DJDashboard.tsx';
import InfluencerDashboard from './components/InfluencerDashboard.tsx';
import StoreDashboard from './components/StoreDashboard.tsx';
import PhotographerDashboard from './components/PhotographerDashboard.tsx';
import ArtistDashboard from './components/ArtistDashboard.tsx';
import SoundLightingDashboard from './components/SoundLightingDashboard.tsx';
import DecorationDashboard from './components/DecorationDashboard.tsx';
import { CreatePerformanceModal } from './components/modals/CreatePerformanceModal.tsx';
import { ProductDetailModal } from './components/modals/InfluencerDashboard.tsx';
import { ChangePasswordModal } from './components/modals/ChangePasswordModal.tsx';
import { NotificationSettingsModal } from './components/modals/NotificationSettingsModal.tsx';
import { DeleteAccountModal } from './components/modals/DeleteAccountModal.tsx';


import { dataService } from '../services/dataService.ts';

import type { 
    AppView,
    ModalState, 
    RaveEvent, 
    User, 
    ToastMessage,
    CoverageRequest, Task, Campaign, CampaignApplication, Invitation, Excursion, Passenger, ExcursionApplication, GigApplication, PerformanceApplication, TicketSale, Notification, RBTransaction, DailyMission, Message, Conversation, RewardStoreItem, EventComment,
    Post,
    Product,
    Ticket,
    CartItem,
    RealTransaction,
    Track,
    GigProposal,
    Performance,
    Equipment,
    DecorationProject,
    Order,
    OrderStatus
} from '../types.ts';
// FIX: Imported ServiceType to resolve type error when approving coverage requests.
import { UserType, RBLevel, ServiceType } from '../types.ts';
import CreateExcursionModal from './components/modals/CreateExcursionModal.tsx';
import EquipmentModal from './components/modals/EquipmentModal.tsx';
import DecorationProjectModal from './components/modals/DecorationProjectModal.tsx';

export const App: React.FC = () => {
    const [currentDate, setCurrentDate] = useState(new Date());
    const [modalState, setModalState] = useState<ModalState>({ type: null });
    const [currentUser, setCurrentUser] = useState<User | null>(null);
    const [toasts, setToasts] = useState<ToastMessage[]>([]);
    const [activeView, setActiveView] = useState<AppView>('calendar');
    
    // State slices
    const [events, setEvents] = useState<RaveEvent[]>([]);
    const [users, setUsers] = useState<User[]>([]);
    const [coverageRequests, setCoverageRequests] = useState<CoverageRequest[]>([]);
    const [tasks, setTasks] = useState<Task[]>([]);
    const [campaigns, setCampaigns] = useState<Campaign[]>([]);
    const [applications, setApplications] = useState<CampaignApplication[]>([]);
    const [invitations, setInvitations] = useState<Invitation[]>([]);
    const [excursions, setExcursions] = useState<Excursion[]>([]);
    const [passengers, setPassengers] = useState<Passenger[]>([]);
    const [excursionApplications, setExcursionApplications] = useState<ExcursionApplication[]>([]);
    const [gigApplications, setGigApplications] = useState<GigApplication[]>([]);
    const [performanceApplications, setPerformanceApplications] = useState<PerformanceApplication[]>([]);
    const [ticketSales, setTicketSales] = useState<TicketSale[]>([]);
    const [notifications, setNotifications] = useState<Notification[]>([]);
    const [rbTransactions, setRbTransactions] = useState<RBTransaction[]>([]);
    const [realTransactions, setRealTransactions] = useState<RealTransaction[]>([]);
    const [rewardStoreItems, setRewardStoreItems] = useState<RewardStoreItem[]>([]);
    const [dailyMissions, setDailyMissions] = useState<DailyMission[]>([]);
    const [conversations, setConversations] = useState<Conversation[]>([]);
    const [messages, setMessages] = useState<Message[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [tracks, setTracks] = useState<Track[]>([]);
    const [proposals, setProposals] = useState<GigProposal[]>([]);
    const [equipment, setEquipment] = useState<Equipment[]>([]);
    const [decorationProjects, setDecorationProjects] = useState<DecorationProject[]>([]);
    const [orders, setOrders] = useState<Order[]>([]);


    const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
        const newToast: ToastMessage = { id: Date.now(), message, type };
        setToasts(prevToasts => [...prevToasts, newToast]);
    };

    const dismissToast = (id: number) => {
        setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    };

    const loadData = useCallback(async () => {
        try {
            setEvents(await dataService.getEvents());
            setUsers(await dataService.getUsers());
            setCoverageRequests(await dataService.getCoverageRequests());
            setTasks(await dataService.getTasks());
            setExcursions(await dataService.getExcursions());
            setPassengers(await dataService.getPassengers());
            setConversations(await dataService.getConversations());
            setMessages(await dataService.getMessages());
            setRbTransactions(await dataService.getRbTransactions());
            setRealTransactions(await dataService.getRealTransactions());
            setRewardStoreItems(await dataService.getRewardStoreItems());
            setTicketSales(await dataService.getTicketSales());
            setProducts(await dataService.getProducts());
            setTracks(await dataService.getTracks());
            setProposals(await dataService.getGigProposals());
            setEquipment(await dataService.getEquipment());
            setDecorationProjects(await dataService.getDecorationProjects());
            setOrders(await dataService.getOrders());
        } catch (error) {
            console.error("Failed to load initial data:", error);
            showToast("Falha ao carregar dados do servidor.", "error");
        }
    }, []);

    useEffect(() => {
        loadData();
    }, [loadData]);

    const eventsByDate = useMemo(() => {
        const map = new Map<string, RaveEvent[]>();
        events.forEach(event => {
            event.dates.forEach(dateStr => {
                const dateKey = dateStr.split('T')[0];
                if (!map.has(dateKey)) {
                    map.set(dateKey, []);
                }
                map.get(dateKey)!.push(event);
            });
        });
        return map;
    }, [events]);
    
    const handleAddPost = async (caption: string, mediaUrl?: string, mediaType?: 'image' | 'video') => {
        if (!currentUser) return;
        const newPost: Post = {
            id: `post-${Date.now()}`,
            userId: currentUser.id,
            caption,
            mediaUrl,
            mediaType,
            createdAt: new Date().toISOString(),
            likes: [],
            comments: [],
        };

        await dataService.addPost(newPost);
        await loadData();
        showToast('Publicação criada com sucesso!', 'success');
    };
    
    const handleShareProductToFeed = (product: Product) => {
        if (!currentUser) return;
        
        const caption = `✨ Novo produto na minha loja! ✨\n\n${product.name}\n\n${product.description}\n\nDisponível por R$ ${product.price.toFixed(2).replace('.', ',')}.`;
        
        // FIX: The 'Product' type uses an 'images' array, not 'imageUrl'. Using the first image.
        handleAddPost(caption, product.images?.[0], 'image');
        setActiveView('feed');
    };

    const handleLogin = async (email: string) => {
        const user = await dataService.login(email);
        if (user) {
            const loggedInUser = {
                ...user,
                followingEvents: user.followingEvents || [],
                followers: user.followers || [],
                following: user.following || [],
            };
            setCurrentUser(loggedInUser);
            setModalState({ type: null });
            setActiveView('calendar');
            showToast(`Bem-vindo(a) de volta, ${user.profile.personal.fullName.split(' ')[0]}!`, 'success');
        } else {
            showToast('Usuário não encontrado!', 'error');
        }
    };
    
    const handleLogout = () => {
        setCurrentUser(null);
        setActiveView('calendar');
        showToast('Você saiu da sua conta.');
    };
    
    const handleUpdateUser = async (user: User) => {
      const updatedUser = await dataService.updateUser(user);
      setCurrentUser(updatedUser);
      setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
      showToast('Perfil atualizado com sucesso!', 'success');
    };

    const handleSaveEvent = async (eventData: Omit<RaveEvent, 'id' | 'organizerId' | 'comments' | 'gallery' | 'videos' | 'services'> & { id?: string }) => {
        const savedEvent = await dataService.saveEvent(eventData);
        if(eventData.id){
            setEvents(events.map(e => e.id === savedEvent.id ? savedEvent : e));
            showToast("Evento atualizado com sucesso!", "success");
        } else {
            setEvents([...events, savedEvent]);
            showToast("Evento criado com sucesso!", "success");
        }
        setModalState({ type: null });
    };

    const handleSaveTask = (taskData: Omit<Task, 'id'>) => {
        const newTask: Task = {
            ...taskData,
            id: `task-${Date.now()}`,
            status: 'pending' // Default status
        };
        setTasks(prev => [...prev, newTask]);
        showToast("Nova tarefa criada com sucesso!", "success");
        setModalState({ type: null });
    };
    
    const handleSaveProduct = (productData: Omit<Product, 'id' | 'storeOwnerId'> & { id?: string }) => {
        if (!currentUser) return;

        const newOrUpdatedProduct: Product = {
            id: productData.id || `prod-${Date.now()}`,
            storeOwnerId: currentUser.id,
            ...productData,
        };

        if (productData.id) {
            setProducts(prev => prev.map(p => p.id === productData.id ? newOrUpdatedProduct : p));
            showToast('Produto atualizado com sucesso!', 'success');
        } else {
            setProducts(prev => [...prev, newOrUpdatedProduct]);
            showToast('Produto criado com sucesso!', 'success');
        }
        setModalState({ type: null });
    };

    const handleSaveTrack = (trackData: Omit<Track, 'id' | 'userId' | 'createdAt'> & { id?: string }) => {
        if (!currentUser) return;
        const newOrUpdatedTrack: Track = {
            id: trackData.id || `track-${Date.now()}`,
            userId: currentUser.id,
            createdAt: trackData.id ? tracks.find(t => t.id === trackData.id)!.createdAt : new Date().toISOString(),
            ...trackData,
        };

        if (trackData.id) {
            setTracks(prev => prev.map(t => t.id === trackData.id ? newOrUpdatedTrack : t));
            showToast('Faixa atualizada com sucesso!', 'success');
        } else {
            setTracks(prev => [...prev, newOrUpdatedTrack]);
            showToast('Faixa enviada com sucesso!', 'success');
        }
        setModalState({ type: null });
    };
    
    const handleDeleteTrack = (trackId: string) => {
        setTracks(prev => prev.filter(t => t.id !== trackId));
        showToast('Faixa excluída com sucesso.', 'success');
    };

    const handleUpdateProposal = (proposalId: string, status: 'accepted' | 'rejected') => {
        setProposals(prev => prev.map(p => p.id === proposalId ? { ...p, status } : p));
        showToast(`Proposta ${status === 'accepted' ? 'aceita' : 'recusada'}.`, 'success');
    };

    const handleToggleFollowEvent = (eventId: string) => {
        if (!currentUser) {
            setModalState({ type: 'LOGIN' });
            showToast('Você precisa estar logado para seguir um evento.', 'info');
            return;
        }

        const isFollowing = currentUser.followingEvents?.includes(eventId);
        let updatedUser: User;
        
        if (isFollowing) {
            // Unfollow
            updatedUser = {
                ...currentUser,
                followingEvents: currentUser.followingEvents?.filter(id => id !== eventId),
            };
            showToast('Você deixou de seguir este evento.', 'info');
        } else {
            // Follow
            updatedUser = {
                ...currentUser,
                followingEvents: [...(currentUser.followingEvents || []), eventId],
            };
            showToast('Você está seguindo este evento!', 'success');
        }
        
        // This is a simulation. In a real app, you would also update the event's follower count on the backend.
        setCurrentUser(updatedUser);
        handleUpdateUser(updatedUser);
    };

    const handleToggleUserFollow = (userIdToFollow: string) => {
        if (!currentUser || currentUser.id === userIdToFollow) return;
    
        const userToFollow = users.find(u => u.id === userIdToFollow);
        if (!userToFollow) return;
    
        const isFollowing = currentUser.following?.includes(userIdToFollow);
    
        let updatedCurrentUser: User;
        let updatedUserToFollow: User;
    
        if (isFollowing) {
            // --- Unfollow ---
            updatedCurrentUser = {
                ...currentUser,
                following: (currentUser.following || []).filter(id => id !== userIdToFollow),
            };
            updatedUserToFollow = {
                ...userToFollow,
                followers: (userToFollow.followers || []).filter(id => id !== currentUser.id),
            };
            showToast(`Você deixou de seguir ${userToFollow.profile.personal.fullName}.`, 'info');
        } else {
            // --- Follow ---
            updatedCurrentUser = {
                ...currentUser,
                following: [...(currentUser.following || []), userIdToFollow],
            };
            updatedUserToFollow = {
                ...userToFollow,
                followers: [...(userToFollow.followers || []), currentUser.id],
            };
            showToast(`Você começou a seguir ${userToFollow.profile.personal.fullName}!`, 'success');
        }
    
        // Update state
        setCurrentUser(updatedCurrentUser);
        setUsers(prevUsers => prevUsers.map(u => {
            if (u.id === currentUser.id) return updatedCurrentUser;
            if (u.id === userIdToFollow) return updatedUserToFollow;
            return u;
        }));
        
        // Also update the user inside the modal state if it's open
        if (modalState.type === 'PUBLIC_PROFILE' && modalState.user.id === userIdToFollow) {
            setModalState({ ...modalState, user: updatedUserToFollow });
        }
    };

    const handleUpdatePost = (updatedPost: Post) => {
        setUsers(prevUsers => {
            return prevUsers.map(user => {
                if (user.id === updatedPost.userId) {
                    const updatedPosts = (user.posts || []).map(p => 
                        p.id === updatedPost.id ? updatedPost : p
                    );
                    return { ...user, posts: updatedPosts };
                }
                return user;
            });
        });
    };
    
    const handleRequestWithdrawal = async (amountRB: number) => {
        if (!currentUser) return;
        try {
            const { user: updatedUser, transaction: newTransaction } = await dataService.requestWithdrawal(currentUser.id, amountRB);
            setCurrentUser(updatedUser);
            setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
            setRbTransactions(prev => [...prev, newTransaction]);
            showToast(`Solicitação de saque de ${amountRB} RB enviada!`, 'success');
            setModalState({ type: null });
        } catch (error) {
            console.error(error);
            showToast((error as Error).message, 'error');
        }
    };

    const handleRedeemReward = async (itemId: string) => {
        if (!currentUser) return;
        try {
            const item = rewardStoreItems.find(i => i.id === itemId);
            if (!item) throw new Error("Item não encontrado.");

            const { user: updatedUser, transaction: newTransaction } = await dataService.redeemReward(currentUser.id, itemId);
            setCurrentUser(updatedUser);
            setUsers(prev => prev.map(u => u.id === updatedUser.id ? updatedUser : u));
            setRbTransactions(prev => [...prev, newTransaction]);
            showToast(`'${item.name}' resgatado com sucesso!`, 'success');
        } catch (error) {
            console.error(error);
            showToast((error as Error).message, 'error');
        }
    };

    const handlePostComment = (eventId: string, text: string) => {
        if (!currentUser) return;
        const newComment: EventComment = {
            id: `comment-${Date.now()}`,
            userId: currentUser.id,
            userName: currentUser.profile.personal.fullName,
            userProfilePicture: currentUser.profile.personal.profilePicture,
            text,
            createdAt: new Date().toISOString(),
        };
        setEvents(prevEvents => prevEvents.map(event => 
            event.id === eventId 
                ? { ...event, comments: [...event.comments, newComment] } 
                : event
        ));
        showToast('Comentário adicionado!', 'success');
    };
    
    const handleUpdateComment = (eventId: string, commentId: string, text: string) => {
        setEvents(prevEvents => prevEvents.map(event => {
            if (event.id === eventId) {
                return {
                    ...event,
                    comments: event.comments.map(c => c.id === commentId ? { ...c, text } : c)
                };
            }
            return event;
        }));
        showToast('Comentário atualizado!', 'success');
    };

    const handleDeleteComment = (eventId: string, commentId: string) => {
        setEvents(prevEvents => prevEvents.map(event => {
            if (event.id === eventId) {
                return {
                    ...event,
                    comments: event.comments.filter(c => c.id !== commentId)
                };
            }
            return event;
        }));
        showToast('Comentário removido!', 'success');
    };

    const handleAddToCart = (event: RaveEvent, ticket: Ticket, quantity: number) => {
        if (!currentUser) return;

        const newItem: CartItem = {
            ticketId: ticket.id,
            eventId: event.id,
            eventName: event.name,
            ticketName: ticket.name,
            quantity: quantity,
            price: ticket.price,
        };

        const existingCart = currentUser.cart || { items: [], total: 0 };
        const existingItemIndex = existingCart.items.findIndex(item => item.ticketId === newItem.ticketId);

        let updatedItems: CartItem[];

        if (existingItemIndex > -1) {
            updatedItems = existingCart.items.map((item, index) => 
                index === existingItemIndex ? { ...item, quantity: item.quantity + newItem.quantity } : item
            );
        } else {
            updatedItems = [...existingCart.items, newItem];
        }
        
        const newTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        const updatedUser = { ...currentUser, cart: { items: updatedItems, total: newTotal } };
        setCurrentUser(updatedUser);
        showToast(`${quantity} x ${ticket.name} adicionado(s) ao carrinho!`, 'success');
    };

    const handleRemoveFromCart = (ticketId: string) => {
        if (!currentUser || !currentUser.cart) return;

        const updatedItems = currentUser.cart.items.filter(item => item.ticketId !== ticketId);
        const newTotal = updatedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        
        const updatedUser = { ...currentUser, cart: { items: updatedItems, total: newTotal } };
        setCurrentUser(updatedUser);
    };
    
    const handleCheckout = async () => {
        if (!currentUser || !currentUser.cart) return;

        try {
            const result = await dataService.checkout(currentUser.id, currentUser.cart);
            setCurrentUser(result.user);
            setEvents(prev => prev.map(e => {
                const updatedEvent = result.updatedEvents.find(ue => ue.id === e.id);
                return updatedEvent || e;
            }));
            setTicketSales(prev => [...prev, ...result.newSales]);
            setRealTransactions(prev => [...prev, result.newTransaction]);

            setModalState({ type: null });
            showToast('Compra realizada com sucesso!', 'success');
        } catch (error) {
            showToast((error as Error).message, 'error');
        }
    };

    const handleSavePerformance = async (performanceData: Omit<Performance, 'id' | 'userId' | 'createdAt'> & {id?: string}) => {
         if (!currentUser) return;
        
        const savedPerformance = await dataService.savePerformance(performanceData, currentUser.id);

        const userPerformances = currentUser.performances || [];

        let updatedPerformances: Performance[];

        if (performanceData.id) { // Editing
             updatedPerformances = userPerformances.map(p => p.id === savedPerformance.id ? savedPerformance : p);
             showToast("Performance atualizada com sucesso!", "success");
        } else { // Creating
            updatedPerformances = [...userPerformances, savedPerformance];
            showToast("Performance cadastrada com sucesso!", "success");
        }
        
        handleUpdateUser({ ...currentUser, performances: updatedPerformances });
        setModalState({ type: null });
    };

    const handleDeletePerformance = async (performanceId: string) => {
        if (!currentUser) return;

        const success = await dataService.deletePerformance(performanceId, currentUser.id);
        if (success) {
            const updatedPerformances = (currentUser.performances || []).filter(p => p.id !== performanceId);
            handleUpdateUser({ ...currentUser, performances: updatedPerformances });
            showToast("Performance excluída com sucesso.", "success");
        } else {
            showToast("Falha ao excluir performance.", "error");
        }
    };
    
    const handleSaveEquipment = async (equipmentData: Omit<Equipment, 'id' | 'ownerId'> & { id?: string }) => {
        if (!currentUser) return;
        const saved = await dataService.saveEquipment(equipmentData, currentUser.id);
        if (equipmentData.id) {
            setEquipment(prev => prev.map(e => e.id === saved.id ? saved : e));
            showToast("Equipamento atualizado!", "success");
        } else {
            setEquipment(prev => [...prev, saved]);
            showToast("Equipamento adicionado!", "success");
        }
        setModalState({ type: null });
    };

    const handleDeleteEquipment = async (equipmentId: string) => {
        if (!currentUser) return;
        const success = await dataService.deleteEquipment(equipmentId, currentUser.id);
        if (success) {
            setEquipment(prev => prev.filter(e => e.id !== equipmentId));
            showToast("Equipamento excluído.", "success");
        }
    };
    
    const handleSaveDecorationProject = async (projectData: Omit<DecorationProject, 'id' | 'userId'> & { id?: string }) => {
        if (!currentUser) return;
        const saved = await dataService.saveDecorationProject(projectData, currentUser.id);
         if (projectData.id) {
            setDecorationProjects(prev => prev.map(p => p.id === saved.id ? saved : p));
            showToast("Projeto atualizado!", "success");
        } else {
            setDecorationProjects(prev => [...prev, saved]);
            showToast("Projeto adicionado!", "success");
        }
        setModalState({ type: null });
    };

    const handleDeleteDecorationProject = async (projectId: string) => {
        if (!currentUser) return;
        const success = await dataService.deleteDecorationProject(projectId, currentUser.id);
        if (success) {
            setDecorationProjects(prev => prev.filter(p => p.id !== projectId));
            showToast("Projeto excluído.", "success");
        }
    };

    const handleUpdateOrder = async (orderId: string, newStatus: OrderStatus) => {
        const updatedOrder = await dataService.updateOrder(orderId, newStatus);
        if (updatedOrder) {
            setOrders(prev => prev.map(o => o.id === orderId ? updatedOrder : o));
            showToast(`Status do pedido #${orderId.slice(-6)} atualizado para "${newStatus}".`, 'success');
        }
    };


    const renderModal = () => {
        switch (modalState.type) {
            case 'LOGIN':
                return <LoginModal 
                    onClose={() => setModalState({ type: null })} 
                    onRegisterClick={() => setModalState({ type: 'REGISTER' })}
                    onLoginSubmit={handleLogin}
                />;
            case 'REGISTER':
                 return <RegisterModal 
                    onClose={() => setModalState({ type: null })} 
                    onLoginClick={() => setModalState({ type: 'LOGIN' })}
                    onRegisterSubmit={(data) => {
                        // This is a simulation
                        const newUser: User = {
                            id: `user-${Date.now()}`,
                            email: data.email,
                            roles: data.types,
                            profile: {
                                personal: { fullName: data.name, username: data.name.toLowerCase().replace(' ', ''), birthDate: '', phone: '', profilePicture: null, cpf: '', rg: '' },
                                address: { cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '', country: 'Brasil' },
                                social: { instagram: '', facebook: '', tiktok: '', linkedin: '', youtube: '', website: '' },
                                medical: { 
                                    bloodType: '', allergies: '', medications: '', conditions: '', 
                                    emergencyContacts: [{name: '', phone: '', relationship: ''}], 
                                    chronicDiseases: '', surgeries: '', recentTreatments: '', 
                                    primaryCarePhysician: { name: '', phone: '', email: '' }, 
                                    preferredHospital: '', 
                                    healthInsurance: { provider: '', policyNumber: '', validity: '', category: '', emergencyPhone: '' }, 
                                    religion: '', specialNeeds: '', medicalDevices: '', 
                                    lastUpdated: new Date().toISOString(), 
                                    attachedDocuments: [] 
                                }
                            },
                            realBalance: 0,
                            rbBalance: 0,
                            rbLevel: RBLevel.NOVATO,
                            followingEvents: [],
                            followers: [],
                            following: [],
                            cart: { items: [], total: 0 }
                        };
                        setUsers(prev => [...prev, newUser]);
                        setCurrentUser(newUser);
                        setModalState({ type: null });
                        showToast(`Bem-vindo(a), ${data.name}!`, 'success');
                    }}
                    defaultType={modalState.defaultType}
                />;
            case 'DAY_EVENTS':
                return <EventsDayModal 
                    date={modalState.date} 
                    events={modalState.events} 
                    onClose={() => setModalState({ type: null })}
                    onAddEvent={(date) => setModalState({ type: 'EVENT_FORM', date })}
                    onShowDetails={(event) => setModalState({ type: 'EVENT_DETAILS', event })}
                />;
            case 'EVENT_DETAILS':
                return <EventDetailModal
                    event={modalState.event}
                    currentUser={currentUser}
                    users={users}
                    officialExcursions={excursions.filter(ex => ex.eventId === modalState.event.id && ex.isOfficial)}
                    passengers={passengers}
                    coverageRequests={coverageRequests}
                    gigApplications={gigApplications}
                    performanceApplications={performanceApplications}
                    onClose={() => setModalState({ type: null })}
                    onManage={(event) => setModalState({ type: 'MANAGE_EVENT', event })}
                    onViewProfile={(user) => setModalState({ type: 'PUBLIC_PROFILE', user, event: modalState.event, from: 'EVENT_DETAILS' })}
                    canManage={!!currentUser && modalState.event.organizerId === currentUser.id}
                    onPostComment={handlePostComment}
                    onUpdateComment={handleUpdateComment}
                    onDeleteComment={handleDeleteComment}
                    onRequestCoverage={(eventId) => {
                        if (!currentUser) return;
                        const newRequest: CoverageRequest = {
                            id: `cov-${Date.now()}`,
                            eventId,
                            photographerId: currentUser.id,
                            status: 'pending'
                        };
                        setCoverageRequests(prev => [...prev, newRequest]);
                        showToast('Solicitação de cobertura enviada!', 'success');
                    }}
                    onApplyToGig={(eventId) => {
                        if (!currentUser) return;
                        const newApp: GigApplication = {
                            id: `gig-${Date.now()}`,
                            eventId,
                            djId: currentUser.id,
                            status: 'pending',
                        };
                        setGigApplications(prev => [...prev, newApp]);
                        showToast('Aplicação para tocar enviada!', 'success');
                    }}
                    onApplyForPerformance={(eventId) => {
                         if (!currentUser) return;
                        const newApp: PerformanceApplication = {
                            id: `perf-${Date.now()}`,
                            eventId,
                            artistId: currentUser.id,
                            status: 'pending',
                        };
                        setPerformanceApplications(prev => [...prev, newApp]);
                        showToast('Aplicação de performance enviada!', 'success');
                    }}
                    onManageGallery={(event) => setModalState({ type: 'MANAGE_EVENT_GALLERY', event })}
                    onBookExcursionSlot={(excursionId) => {
                        if (!currentUser) { setModalState({ type: 'LOGIN' }); return; }
                        // Mock logic
                        const excursion = excursions.find(ex => ex.id === excursionId);
                        if(excursion) {
                            showToast(`Vaga reservada na excursão ${excursion.name}!`, 'success');
                        }
                    }}
                     onNavigateToContextualDashboard={(view) => {
                        setActiveView(view);
                        setModalState({ type: null });
                    }}
                     onLoginOrRegister={() => setModalState({ type: 'LOGIN' })}
                     onAddToCart={handleAddToCart}
                />;
            case 'ALL_EVENTS':
                return <AllEventsModal 
                    events={events}
                    currentUser={currentUser}
                    tasks={tasks}
                    onClose={() => setModalState({ type: null })}
                    onShowDetails={(event) => setModalState({ type: 'EVENT_DETAILS', event })}
                    onToggleFollow={handleToggleFollowEvent}
                />;
            case 'EVENT_FORM':
                return <EventModal 
                    onClose={() => setModalState({ type: null })} 
                    onSave={handleSaveEvent}
                    eventToEdit={modalState.eventToEdit}
                    selectedDate={modalState.date}
                />;
            case 'TASK_FORM':
                return <TaskModal 
                    onClose={() => setModalState({ type: 'MANAGE_EVENT', event: events.find(e => e.id === modalState.eventId)! })}
                    onSave={handleSaveTask}
                    eventId={modalState.eventId}
                />
            case 'PRODUCT_FORM':
                return <ProductModal
                    onClose={() => setModalState({ type: null })}
                    onSave={handleSaveProduct}
                    productToEdit={modalState.productToEdit}
                />;
             case 'EQUIPMENT_FORM':
                return <EquipmentModal
                    onClose={() => setModalState({ type: null })}
                    onSave={handleSaveEquipment}
                    equipmentToEdit={modalState.equipmentToEdit}
                />;
             case 'DECORATION_PROJECT_FORM':
                return <DecorationProjectModal
                    onClose={() => setModalState({ type: null })}
                    onSave={handleSaveDecorationProject}
                    projectToEdit={modalState.projectToEdit}
                />;
            case 'UPLOAD_TRACK':
                return <UploadTrackModal
                    onClose={() => setModalState({ type: null })}
                    onSave={handleSaveTrack}
                    trackToEdit={modalState.trackToEdit}
                />;
            case 'CREATE_PERFORMANCE':
                 return <CreatePerformanceModal 
                    onClose={() => setModalState({ type: null })}
                    onCreate={handleSavePerformance}
                 />;
            case 'PUBLIC_PROFILE': {
                 const handleCloseProfile = () => {
                    if (modalState.from === 'MANAGE_EVENT' && modalState.event) {
                        setModalState({ type: 'MANAGE_EVENT', event: modalState.event });
                    } else if (modalState.from === 'EVENT_DETAILS' && modalState.event) {
                        setModalState({ type: 'EVENT_DETAILS', event: modalState.event });
                    } else {
                        setModalState({ type: null });
                    }
                };
                return <PublicProfileModal
                    user={modalState.user}
                    currentUser={currentUser}
                    event={modalState.event}
                    onClose={handleCloseProfile}
                    onToggleFollow={handleToggleUserFollow}
                />;
            }
            case 'MANAGE_EVENT':
                 return <ManageEventModal
                    event={modalState.event}
                    tasks={tasks.filter(t => t.eventId === modalState.event.id)}
                    coverageRequests={coverageRequests.filter(r => r.eventId === modalState.event.id)}
                    campaigns={campaigns.filter(c => c.eventId === modalState.event.id)}
                    applications={applications.filter(a => campaigns.some(c => c.id === a.campaignId))}
                    invitations={invitations.filter(i => i.eventId === modalState.event.id)}
                    excursionApplications={excursionApplications.filter(ea => ea.eventId === modalState.event.id)}
                    excursions={excursions.filter(ex => ex.eventId === modalState.event.id)}
                    gigApplications={gigApplications.filter(ga => ga.eventId === modalState.event.id)}
                    performanceApplications={performanceApplications.filter(pa => pa.eventId === modalState.event.id)}
                    ticketSales={ticketSales.filter(ts => ts.eventId === modalState.event.id)}
                    users={users}
                    onClose={() => setModalState({ type: null })}
                    onViewProfile={(user) => setModalState({ type: 'PUBLIC_PROFILE', user, event: modalState.event, from: 'MANAGE_EVENT' })}
                    onAddTask={(eventId) => setModalState({ type: 'TASK_FORM', eventId })}
                    onEdit={(event) => setModalState({ type: 'EVENT_FORM', eventToEdit: event })}
                    onDelete={(eventId) => {
                        if (window.confirm("Tem certeza que deseja excluir este evento? Esta ação não pode ser desfeita.")) {
                            setEvents(prev => prev.filter(e => e.id !== eventId));
                            setModalState({ type: null });
                            showToast("Evento excluído.", "success");
                        }
                    }}
                    onManageRequest={(requestId, status) => {
                        const request = coverageRequests.find(r => r.id === requestId);
                        if(request) {
                            setCoverageRequests(prev => prev.map(r => r.id === requestId ? { ...r, status } : r));
                            if(status === 'approved') {
                                const eventIndex = events.findIndex(e => e.id === request.eventId);
                                if(eventIndex > -1) {
                                    const updatedEvents = [...events];
                                    // FIX: Corrected type from UserType to ServiceType
                                    updatedEvents[eventIndex].services.push({ type: ServiceType.PHOTOGRAPHER, providerId: request.photographerId });
                                    setEvents(updatedEvents);
                                }
                            }
                            showToast(`Solicitação ${status === 'approved' ? 'aprovada' : 'rejeitada'}.`, 'success');
                        }
                    }}
                    onCreateCampaign={() => setModalState({ type: 'CREATE_CAMPAIGN', event: modalState.event })}
                    onManageApplication={() => {}}
                    onInviteUser={() => setModalState({ type: 'INVITE_USER', event: modalState.event })}
                    onManageExcursionApplication={(appId, status) => {
                        const app = excursionApplications.find(a => a.id === appId);
                        if (app) {
                            setExcursionApplications(prev => prev.map(a => a.id === appId ? { ...a, status } : a));
                            if (status === 'approved') {
                                setExcursions(prev => prev.map(ex => ex.id === app.excursionId ? { ...ex, isOfficial: true } : ex));
                            }
                        }
                    }}
                    onManageGigApplication={() => {}}
                    onManagePerformanceApplication={() => {}}
                    onManageGallery={(event) => setModalState({ type: 'MANAGE_EVENT_GALLERY', event })}
                    defaultTab={modalState.defaultTab}
                />;
            case 'CREATE_CAMPAIGN':
                return <CreateCampaignModal 
                    event={modalState.event}
                    onClose={() => setModalState({type: 'MANAGE_EVENT', event: modalState.event})}
                    onCreate={(campaignData) => {
                        const newCampaign: Campaign = {
                            ...campaignData,
                            id: `camp-${Date.now()}`,
                            organizerId: modalState.event.organizerId,
                            status: 'open'
                        };
                        setCampaigns(prev => [...prev, newCampaign]);
                        setModalState({ type: 'MANAGE_EVENT', event: modalState.event, defaultTab: 'campaigns' });
                        showToast('Campanha criada!', 'success');
                    }}
                />;
            case 'INVITE_USER':
                return <InviteUserModal 
                    event={modalState.event}
                    allUsers={users}
                    onClose={() => setModalState({type: 'MANAGE_EVENT', event: modalState.event})}
                    onInvite={(eventId, inviteeId, role) => {
                         const newInvite: Invitation = {
                            id: `inv-${Date.now()}`,
                            eventId,
                            organizerId: modalState.event.organizerId,
                            inviteeId,
                            role,
                            status: 'pending',
                            createdAt: new Date().toISOString()
                        };
                        setInvitations(prev => [...prev, newInvite]);
                        setModalState({ type: 'MANAGE_EVENT', event: modalState.event, defaultTab: 'campaigns' });
                        showToast('Convite enviado!', 'success');
                    }}
                />;
            case 'MANAGE_EVENT_GALLERY':
                return <ManageGalleryModal 
                    event={modalState.event}
                    onClose={() => setModalState({type: 'MANAGE_EVENT', event: modalState.event})}
                    onAddPhotos={(eventId, files) => {
                        const newPhotos = files.map(file => ({
                            id: `photo-${Date.now()}-${Math.random()}`,
                            userId: currentUser!.id,
                            url: URL.createObjectURL(file), // In real app, this would be an upload URL
                            name: file.name,
                            eventId: eventId,
                            isPublic: true,
                            createdAt: new Date().toISOString()
                        }));

                        setEvents(prevEvents => prevEvents.map(event => 
                            event.id === eventId 
                                ? { ...event, gallery: [...event.gallery, ...newPhotos] } 
                                : event
                        ));
                        showToast(`${files.length} foto(s) adicionada(s)!`, 'success');
                    }}
                    onAddVideos={() => {}}
                />
            case 'CREATE_EXCURSION':
                return <CreateExcursionModal 
                    eventId={modalState.eventId}
                    allEvents={modalState.allEvents || events}
                    excursionToEdit={modalState.excursionToEdit}
                    onClose={() => {
                        if(currentUser?.roles.includes(UserType.TRIP_ORGANIZER)) {
                            setActiveView('excursions');
                        }
                        setModalState({ type: null });
                    }}
                    onSave={(excursionData) => {
                        if(excursionData.id) { // Editing
                            setExcursions(prev => prev.map(ex => ex.id === excursionData.id ? { ...ex, ...excursionData } : ex));
                            showToast("Excursão atualizada!", "success");
                        } else { // Creating
                            const newExcursion: Excursion = {
                                ...excursionData,
                                id: `ex-${Date.now()}`,
                                tripOrganizerId: currentUser!.id,
                                isOfficial: false,
                            };
                            setExcursions(prev => [...prev, newExcursion]);
                            showToast("Excursão criada!", "success");
                        }
                        if(currentUser?.roles.includes(UserType.TRIP_ORGANIZER)) {
                            setActiveView('excursions');
                        }
                        setModalState({ type: null });
                    }}
                />
            case 'WITHDRAWAL':
                return <WithdrawalModal 
                    currentUser={currentUser!}
                    onClose={() => setModalState({type: null})}
                    onRequestWithdrawal={handleRequestWithdrawal}
                />;
            case 'REWARD_STORE':
                return <RewardStoreModal 
                    currentUser={currentUser!}
                    items={rewardStoreItems}
                    onClose={() => setModalState({type: null})}
                    onRedeem={handleRedeemReward}
                />;
            case 'CHANGE_PASSWORD':
                return <ChangePasswordModal onClose={() => setModalState({ type: null })} />;
            case 'NOTIFICATION_SETTINGS':
                return <NotificationSettingsModal onClose={() => setModalState({ type: null })} />;
            case 'DELETE_ACCOUNT':
                return <DeleteAccountModal onClose={() => setModalState({ type: null })} />;
            case 'CART':
                return <CartModal
                    cart={currentUser?.cart || { items: [], total: 0 }}
                    onClose={() => setModalState({ type: null })}
                    onRemoveItem={handleRemoveFromCart}
                    onCheckout={handleCheckout}
                />;
            case 'PRODUCT_DETAILS':
                return <ProductDetailModal
                    product={modalState.product}
                    onClose={() => setModalState({ type: null })}
                    onAddToCart={(product) => {
                        // This is a simulation, as product cart is separate from ticket cart.
                        showToast(`${product.name} adicionado ao carrinho!`, 'success');
                    }}
                />;
            case null:
                return null;
        }
    };
    
    const renderView = () => {
        if (!currentUser && !['calendar', 'shop'].includes(activeView)) {
             // Redirect to calendar if not logged in and trying to access a protected view
             setActiveView('calendar');
             return null;
        }

        switch (activeView) {
            case 'profile':
                if (!currentUser) return null;
                return <ProfileView 
                    user={currentUser}
                    allEvents={events}
                    ticketSales={ticketSales}
                    notifications={notifications}
                    rbTransactions={rbTransactions}
                    realTransactions={realTransactions}
                    onUpdateUser={handleUpdateUser}
                    onBack={() => setActiveView('calendar')}
                    onOpenWithdrawal={() => setModalState({ type: 'WITHDRAWAL' })}
                    onOpenRewardStore={() => setModalState({ type: 'REWARD_STORE' })}
                    onOpenChangePasswordModal={() => setModalState({ type: 'CHANGE_PASSWORD' })}
                    onOpenNotificationSettingsModal={() => setModalState({ type: 'NOTIFICATION_SETTINGS' })}
                    onOpenDeleteAccountModal={() => setModalState({ type: 'DELETE_ACCOUNT' })}
                    showToast={showToast}
                />;
            case 'messages':
                 if (!currentUser) return null;
                return <ChatView 
                    currentUser={currentUser}
                    allUsers={users}
                    conversations={conversations}
                    messages={messages}
                    onSendMessage={(convoId, text) => {
                        const newMessage: Message = {
                            id: `msg-${Date.now()}`,
                            conversationId: convoId,
                            senderId: currentUser.id,
                            text,
                            timestamp: new Date().toISOString(),
                            isRead: false,
                        };
                        setMessages(prev => [...prev, newMessage]);
                    }}
                    onBack={() => setActiveView('calendar')}
                />;
            case 'influencerDashboard':
                 if (!currentUser) return null;
                 const myTasks = tasks.filter(t => t.assigneeId === currentUser.id || !t.assigneeId);
                 return <InfluencerDashboard 
                    tasks={myTasks}
                    events={events}
                 />
            case 'storeDashboard':
                if (!currentUser) return null;
                return <StoreDashboard
                    user={currentUser}
                    products={products.filter(p => p.storeOwnerId === currentUser.id)}
                    orders={orders.filter(o => o.storeOwnerId === currentUser.id)}
                    onOpenProductModal={(product) => setModalState({ type: 'PRODUCT_FORM', productToEdit: product })}
                    onShareProduct={handleShareProductToFeed}
                    onUpdateOrder={handleUpdateOrder}
                />
            case 'photographerDashboard':
                 if (!currentUser) return null;
                 return <PhotographerDashboard 
                    user={currentUser}
                    events={events}
                    requests={coverageRequests}
                    onViewEventDetails={(event) => setModalState({ type: 'EVENT_DETAILS', event })}
                    onManageGallery={(event) => setModalState({ type: 'MANAGE_EVENT_GALLERY', event })}
                 />
            case 'artistDashboard':
                 if (!currentUser) return null;
                 return <ArtistDashboard 
                    user={currentUser}
                    performances={currentUser.performances || []}
                    onOpenPerformanceModal={() => setModalState({ type: 'CREATE_PERFORMANCE' })}
                 />
            case 'soundLightingDashboard':
                if (!currentUser) return null;
                return <SoundLightingDashboard 
                    user={currentUser} 
                    equipment={equipment.filter(e => e.ownerId === currentUser.id)}
                    onOpenEquipmentModal={(equip) => setModalState({ type: 'EQUIPMENT_FORM', equipmentToEdit: equip })}
                    onDeleteEquipment={handleDeleteEquipment}
                />;
            case 'decorationDashboard':
                if (!currentUser) return null;
                return <DecorationDashboard 
                    user={currentUser}
                    projects={decorationProjects.filter(p => p.userId === currentUser.id)}
                    onOpenProjectModal={(proj) => setModalState({ type: 'DECORATION_PROJECT_FORM', projectToEdit: proj })}
                    onDeleteProject={handleDeleteDecorationProject}
                />;
            case 'excursions':
                if (!currentUser) return null;
                return <ExcursionsView
                    user={currentUser}
                    excursions={excursions}
                    passengers={passengers}
                    events={events}
                    onCreateExcursion={() => setModalState({type: 'CREATE_EXCURSION', allEvents: events})}
                    onEditExcursion={(excursion) => setModalState({type: 'CREATE_EXCURSION', excursionToEdit: excursion, allEvents: events})}
                />;
            case 'djDashboard':
                if (!currentUser) return null;
                return <DJDashboard
                    user={currentUser}
                    tracks={tracks.filter(t => t.userId === currentUser.id)}
                    proposals={proposals.filter(p => p.djId === currentUser.id)}
                    allUsers={users}
                    allEvents={events}
                    onOpenUploadModal={(track) => setModalState({ type: 'UPLOAD_TRACK', trackToEdit: track })}
                    onDeleteTrack={handleDeleteTrack}
                    onUpdateProposal={handleUpdateProposal}
                />;
            case 'followedEvents':
                if (!currentUser) return null;
                 const followed = events.filter(e => currentUser.followingEvents?.includes(e.id));
                 return <FollowedEventsView 
                    events={followed}
                    currentUser={currentUser}
                    onPostComment={handlePostComment}
                    onUpdateComment={handleUpdateComment}
                    onDeleteComment={handleDeleteComment}
                 />;
            case 'mainDashboard':
                 if (!currentUser) return null;
                 return <DashboardView 
                    user={currentUser}
                    events={events.filter(e => e.organizerId === currentUser.id)}
                    tasks={tasks.filter(t => events.some(e => e.id === t.eventId && e.organizerId === currentUser.id))}
                    users={users}
                    ticketSales={ticketSales.filter(ts => events.some(e => e.id === ts.eventId && e.organizerId === currentUser.id))}
                    onAddEvent={() => setModalState({ type: 'EVENT_FORM' })}
                    onAddTask={() => {
                        const myEvents = events.filter(e => e.organizerId === currentUser.id);
                        if (myEvents.length > 0) {
                            setModalState({ type: 'TASK_FORM', eventId: myEvents[0].id }); // Default to first event
                        } else {
                            showToast("Crie um evento antes de adicionar tarefas.", "info");
                        }
                    }}
                    showToast={showToast}
                    onViewProfile={(user) => setModalState({ type: 'PUBLIC_PROFILE', user })}
                    onViewEvent={(event) => setModalState({ type: 'MANAGE_EVENT', event })}
                 />
            case 'feed':
                if (!currentUser) return null;
                return <FeedView 
                    currentUser={currentUser}
                    allUsers={users}
                    onUpdatePost={handleUpdatePost}
                    showToast={showToast}
                    onAddPost={handleAddPost}
                />;
            case 'shop':
                return <ShopView 
                    products={products}
                    onAddToCart={(product) => {
                        if (!currentUser) {
                            setModalState({ type: 'LOGIN' });
                            showToast('Você precisa estar logado para adicionar itens ao carrinho.', 'info');
                            return;
                        }
                        // This should eventually be a real add to cart function for products
                        showToast(`${product.name} adicionado ao carrinho!`, 'success');
                    }}
                    currentUser={currentUser}
                    onOpenProductModal={() => setModalState({ type: 'PRODUCT_FORM' })}
                    onViewProduct={(product) => setModalState({ type: 'PRODUCT_DETAILS', product })}
                />;
            case 'calendar':
            default:
                return (
                    <>
                        {currentUser?.roles.includes(UserType.ORGANIZER) && (
                            <div className="w-full max-w-7xl mb-6 text-right">
                                <button
                                    onClick={() => setModalState({ type: 'EVENT_FORM' })}
                                    className="btn bg-[var(--color-accent-secondary)] text-slate-900 font-bold py-2 px-5 rounded-lg hover:opacity-90 transition-colors shadow-md"
                                >
                                    <CalendarPlusIcon className="w-5 h-5"/>
                                    <span>Criar Novo Evento</span>
                                </button>
                            </div>
                        )}
                        <Calendar 
                            currentDate={currentDate}
                            setCurrentDate={setCurrentDate}
                            eventsByDate={eventsByDate}
                            onDayClick={(date, dayEvents) => setModalState({ type: 'DAY_EVENTS', date, events: dayEvents })}
                        />
                         <div className="mt-8 w-full max-w-7xl">
                             <div className="flex justify-between items-center mb-4">
                                <h2 className="text-2xl font-bold text-white">Próximos Eventos</h2>
                                <button 
                                    onClick={() => setModalState({ type: 'ALL_EVENTS' })} 
                                    className="text-yellow-400 font-semibold hover:underline"
                                >
                                    Ver Todos
                                </button>
                            </div>
                            <EventList 
                                events={events}
                                currentUser={currentUser}
                                tasks={tasks}
                                onEventClick={(event) => setModalState({ type: 'EVENT_DETAILS', event })}
                                onToggleFollow={handleToggleFollowEvent}
                            />
                        </div>
                    </>
                );
        }
    };

    return (
        <div className="min-h-screen w-full flex flex-col items-center p-4 sm:p-6 lg:p-8 relative overflow-hidden">
            <header className="w-full max-w-7xl flex justify-between items-center mb-6">
                <div className="flex items-center gap-3">
                    <h1 className="text-4xl sm:text-5xl font-bold font-montserrat text-[var(--color-accent-primary)]">Divulgosim</h1>
                </div>
                {currentUser ? (
                    <div className="flex items-center gap-4">
                         <button onClick={() => setModalState({type: 'CART'})} className="relative p-2 rounded-full hover:bg-white/10">
                            <ShoppingCartIcon className="w-6 h-6"/>
                            {(currentUser.cart?.items.length || 0) > 0 && (
                                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full">
                                    {currentUser.cart?.items.length}
                                </span>
                            )}
                        </button>
                        <span className="hidden sm:inline">Olá, {currentUser.profile.personal.fullName.split(' ')[0]}</span>
                        <button onClick={() => setActiveView('profile')} className="w-12 h-12 rounded-full bg-slate-700 border-2 border-slate-600 overflow-hidden">
                            {currentUser.profile.personal.profilePicture ? (
                                <img src={currentUser.profile.personal.profilePicture} alt="Perfil" className="w-full h-full object-cover"/>
                            ) : (
                                <UserIconDefault className="w-8 h-8 mx-auto my-1 text-white" />
                            )}
                        </button>
                        <button onClick={handleLogout} className="text-sm text-slate-400 hover:text-white">Sair</button>
                    </div>
                ) : (
                    <div className="flex items-center gap-2">
                        <button onClick={() => setModalState({ type: 'LOGIN' })} className="btn bg-[var(--color-accent-primary)] text-slate-900 font-bold py-2 px-5 rounded-lg hover:bg-[var(--color-accent-secondary)]">
                            Entrar
                        </button>
                    </div>
                )}
            </header>

            {currentUser && <MainMenu user={currentUser} activeView={activeView} onNavigate={setActiveView} />}
            
            <main className="flex-grow w-full flex flex-col items-center justify-center mt-8">
                {renderView()}
            </main>

            {modalState.type && renderModal()}

            <div className="toast-container">
                {toasts.map(toast => (
                    <Toast key={toast.id} message={toast} onDismiss={() => dismissToast(toast.id)} />
                ))}
            </div>

             <footer className="w-full text-center mt-12 text-slate-500 text-sm">
                <p>&copy; {new Date().getFullYear()} Divulgosim. Todos os direitos reservados.</p>
            </footer>
        </div>
    );
};