import React from 'react';
import { User, Equipment } from '../types.ts';
import { PlusIcon, SpeakerIcon, EditIcon, TrashIcon } from './Icons.tsx';

interface SoundLightingDashboardProps {
    user: User;
    equipment: Equipment[];
    onOpenEquipmentModal: (equipment?: Equipment) => void;
    onDeleteEquipment: (equipmentId: string) => void;
}

const SoundLightingDashboard: React.FC<SoundLightingDashboardProps> = ({ user, equipment, onOpenEquipmentModal, onDeleteEquipment }) => {
    
    const handleDelete = (equipmentId: string) => {
        if (window.confirm('Tem certeza que deseja excluir este equipamento?')) {
            onDeleteEquipment(equipmentId);
        }
    };

    return (
        <div className="w-full max-w-7xl">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)]">Painel de Som & Iluminação</h1>
                <button onClick={() => onOpenEquipmentModal()} className="btn bg-[var(--color-accent-secondary)] text-slate-900">
                    <PlusIcon className="w-5 h-5" /> Adicionar Equipamento
                </button>
            </div>

            {equipment.length > 0 ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    {equipment.map(item => (
                        <div key={item.id} className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)] flex flex-col group">
                            <div className="aspect-square w-full overflow-hidden rounded-md mb-3 bg-black/20">
                                <img src={item.images[0] || 'https://via.placeholder.com/400'} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            </div>
                            <div className="flex-grow">
                                <h3 className="font-bold truncate">{item.name}</h3>
                                <p className="text-xs text-slate-400 bg-slate-700/50 inline-block px-2 py-0.5 rounded-full my-1">{item.category}</p>
                                <p className="text-lg font-bold text-green-400">R$ {item.price.toFixed(2)}<span className="text-sm font-normal text-slate-400">/dia</span></p>
                            </div>
                            <div className="flex gap-2 mt-3">
                                <button onClick={() => onOpenEquipmentModal(item)} className="w-full btn bg-slate-600 text-white !text-xs">
                                    <EditIcon className="w-4 h-4" /> Editar
                                </button>
                                <button onClick={() => handleDelete(item.id)} className="btn bg-red-600/80 text-white !text-xs !px-2">
                                    <TrashIcon className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-black/10 rounded-lg">
                    <SpeakerIcon className="w-16 h-16 mx-auto text-slate-500 mb-4" />
                    <h3 className="text-xl font-semibold">Nenhum equipamento cadastrado</h3>
                    <p className="text-slate-400 mt-2">Clique em "Adicionar Equipamento" para começar a montar seu portfólio.</p>
                </div>
            )}
        </div>
    );
};

export default SoundLightingDashboard;