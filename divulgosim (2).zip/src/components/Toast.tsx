import React, { useEffect } from 'react';
import { ToastMessage } from '../../types.ts';
import { CheckCircleIcon, CloseIcon } from './Icons.tsx';

interface ToastProps {
    message: ToastMessage;
    onDismiss: () => void;
}

const Toast: React.FC<ToastProps> = ({ message, onDismiss }) => {
    useEffect(() => {
        const timer = setTimeout(() => {
            onDismiss();
        }, 5000); // Auto-dismiss after 5 seconds

        return () => {
            clearTimeout(timer);
        };
    }, [onDismiss]);

    const baseClasses = "toast";
    const typeClasses = {
        success: 'toast-success',
        error: 'toast-error',
        info: 'toast-info',
    };

    return (
        <div className={`${baseClasses} ${typeClasses[message.type]}`}>
            {/* You can add icons here based on message.type */}
            {/* <CheckCircleIcon className="w-6 h-6" /> */}
            <span className="font-semibold">{message.message}</span>
            <button onClick={onDismiss} className="ml-auto -mr-2 p-1 rounded-full hover:bg-white/20 transition-colors">
                <CloseIcon className="w-5 h-5" />
            </button>
        </div>
    );
};

export default Toast;