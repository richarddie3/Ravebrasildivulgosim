import React, { useState } from 'react';
// FIX: Imported UserType to resolve reference error.
import { RaveEvent, User, EventComment, UserType } from '../../types.ts';
import { CommentItem } from './CommentItem.tsx';
import { UserIcon as UserIconDefault } from './Icons.tsx';

interface FollowedEventsViewProps {
    events: RaveEvent[];
    currentUser: User | null;
    onPostComment: (eventId: string, text: string) => void;
    onUpdateComment: (eventId: string, commentId: string, text: string) => void;
    onDeleteComment: (eventId: string, commentId: string) => void;
}

const FollowedEventCard: React.FC<Omit<FollowedEventsViewProps, 'events' | 'onNavigate'> & { event: RaveEvent }> = ({
    event, currentUser, onPostComment, onUpdateComment, onDeleteComment
}) => {
    const [newComment, setNewComment] = useState('');

    const handlePostComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (newComment.trim() && currentUser) {
            onPostComment(event.id, newComment);
            setNewComment('');
        }
    };

    return (
        <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-3">
                <div className="md:col-span-1">
                    <img src={event.image || ''} alt={event.name} className="w-full h-48 md:h-full object-cover" />
                </div>
                <div className="md:col-span-2 p-6 flex flex-col">
                    <h3 className="text-2xl font-bold text-[var(--color-accent-primary)] font-poppins">{event.name}</h3>
                    <p className="text-sm text-[var(--color-text-secondary)] mt-1">{event.dateString} • {event.location}</p>
                    <p className="text-sm text-white/80 mt-4 whitespace-pre-wrap flex-grow">{event.description}</p>
                </div>
            </div>
            {/* Comments Section */}
            <div className="bg-black/20 p-6 border-t border-[var(--color-border)]">
                <h4 className="font-semibold text-lg mb-4 text-[var(--color-accent-primary)]">Comentários ({event.comments.length})</h4>
                <div className="space-y-4 max-h-60 overflow-y-auto pr-2 mb-4">
                    {event.comments.length > 0 ? event.comments.map(comment => (
                        <CommentItem 
                            key={comment.id}
                            comment={comment}
                            currentUser={currentUser}
                            canManageEvent={!!currentUser && currentUser.roles.includes(UserType.ORGANIZER) && currentUser.id === event.organizerId}
                            onUpdate={(commentId, text) => onUpdateComment(event.id, commentId, text)}
                            onDelete={(commentId) => onDeleteComment(event.id, commentId)}
                        />
                    )) : <p className="text-sm text-center text-slate-400 py-4">Seja o primeiro a comentar!</p>}
                </div>
                {currentUser && (
                    <form onSubmit={handlePostComment} className="mt-4 pt-4 border-t border-[var(--color-border)] flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-black/20 flex-shrink-0 flex items-center justify-center overflow-hidden">
                            {currentUser.profile.personal.profilePicture ? (
                                <img src={currentUser.profile.personal.profilePicture} alt={currentUser.profile.personal.fullName} className="w-full h-full object-cover"/>
                            ) : (
                                <UserIconDefault className="w-6 h-6 text-white"/>
                            )}
                        </div>
                        <textarea 
                            value={newComment}
                            onChange={(e) => setNewComment(e.target.value)}
                            placeholder="Adicione um comentário..."
                            className="w-full bg-white/5 rounded-md p-2 text-sm border border-white/20 focus:ring-1 focus:ring-[var(--color-accent-primary)] outline-none transition-colors"
                            rows={2}
                        ></textarea>
                        <button type="submit" className="btn bg-[var(--color-accent-secondary)] text-slate-900 !py-2 !px-4">Enviar</button>
                    </form>
                )}
            </div>
        </div>
    );
};

export const FollowedEventsView: React.FC<FollowedEventsViewProps> = (props) => {
    return (
        <div className="w-full max-w-7xl space-y-8">
            {props.events.map(event => (
                <FollowedEventCard key={event.id} event={event} {...props} />
            ))}
        </div>
    );
};