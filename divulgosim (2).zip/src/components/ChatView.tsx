import React, { useState, useMemo, useEffect, useRef } from 'react';
import { User, Conversation, Message, UserType } from '../../types.ts';
import { 
    ChevronLeftIcon, CogIcon, PaperAirplaneIcon, PaperClipIcon, CameraIcon, 
    BusIcon, MusicIcon, UserIcon as UserIconDefault 
} from './Icons.tsx';

// Helper to get user type icon
const getUserTypeIcon = (user: User) => {
    if (user.roles.includes(UserType.DJ)) return <MusicIcon className="w-5 h-5" />;
    if (user.roles.includes(UserType.TRIP_ORGANIZER)) return <BusIcon className="w-5 h-5" />;
    return <UserIconDefault className="w-5 h-5" />;
};


interface ChatViewProps {
    currentUser: User;
    allUsers: User[];
    conversations: Conversation[];
    messages: Message[];
    onSendMessage: (conversationId: string, text: string) => void;
    onBack: () => void;
}

const ChatView: React.FC<ChatViewProps> = ({ currentUser, allUsers, conversations, messages, onSendMessage, onBack }) => {
    const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
    const [newMessage, setNewMessage] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const conversationsWithDetails = useMemo(() => {
        return conversations.map(convo => {
            const otherParticipantId = convo.participants.find(pId => pId !== currentUser.id);
            const otherParticipant = allUsers.find(u => u.id === otherParticipantId);
            const convoMessages = messages.filter(m => m.conversationId === convo.id).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
            const lastMessage = convoMessages[convoMessages.length - 1];
            const unreadCount = convoMessages.filter(m => !m.isRead && m.senderId !== currentUser.id).length;

            return {
                ...convo,
                otherParticipant,
                lastMessage,
                unreadCount,
            };
        }).sort((a, b) => {
            if (!a.lastMessage) return 1;
            if (!b.lastMessage) return -1;
            return new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime();
        });
    }, [conversations, messages, allUsers, currentUser.id]);

    const selectedConversation = useMemo(() => {
        return conversationsWithDetails.find(c => c.id === selectedConversationId);
    }, [selectedConversationId, conversationsWithDetails]);

    const messagesForSelectedConvo = useMemo(() => {
        if (!selectedConversationId) return [];
        return messages.filter(m => m.conversationId === selectedConversationId).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
    }, [selectedConversationId, messages]);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if (newMessage.trim() && selectedConversationId) {
            onSendMessage(selectedConversationId, newMessage);
            setNewMessage('');
        }
    };
    
    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        scrollToBottom();
    }, [messagesForSelectedConvo]);

    const ConversationListItem: React.FC<{ convo: typeof conversationsWithDetails[0] }> = ({ convo }) => {
        const { otherParticipant, lastMessage, unreadCount } = convo;
        if (!otherParticipant) return null;

        return (
            <button
                onClick={() => setSelectedConversationId(convo.id)}
                className={`w-full text-left p-3 flex items-center gap-3 rounded-lg transition-colors ${selectedConversationId === convo.id ? 'bg-white/10' : 'hover:bg-white/5'}`}
            >
                <div className="relative flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-black/20 flex items-center justify-center overflow-hidden">
                        {otherParticipant.profile.personal.profilePicture ? (
                            <img src={otherParticipant.profile.personal.profilePicture} alt={otherParticipant.profile.personal.fullName} className="w-full h-full object-cover" />
                        ) : (
                            <div className="text-[var(--color-text-secondary)]">{getUserTypeIcon(otherParticipant)}</div>
                        )}
                    </div>
                     {/* Online status indicator */}
                    <span className="absolute bottom-0 right-0 block h-3 w-3 rounded-full bg-green-400 ring-2 ring-[var(--color-bg-secondary)]"></span>
                </div>
                <div className="flex-grow overflow-hidden">
                    <div className="flex justify-between items-center">
                        <p className="font-semibold truncate">{otherParticipant.profile.personal.fullName}</p>
                        {lastMessage && <p className="text-xs text-[var(--color-text-secondary)] flex-shrink-0">{new Date(lastMessage.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>}
                    </div>
                    <div className="flex justify-between items-start">
                        <p className="text-sm text-[var(--color-text-secondary)] truncate">{lastMessage?.text || 'Sem mensagens'}</p>
                        {unreadCount > 0 && <span className="flex-shrink-0 ml-2 bg-red-500 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full">{unreadCount}</span>}
                    </div>
                </div>
            </button>
        );
    };

    return (
        <div className="w-full max-w-7xl h-[calc(100vh-120px)] bg-[var(--color-bg-secondary)]/80 backdrop-blur-md rounded-2xl text-white shadow-2xl border border-[var(--color-border)] flex flex-col">
            <header className="p-4 flex items-center gap-4 border-b border-[var(--color-border)]">
                <button onClick={onBack} className="bg-black/20 p-2 rounded-full hover:bg-white/20 transition-colors">
                    <ChevronLeftIcon className="w-6 h-6"/>
                </button>
                <h1 className="text-2xl font-bold font-poppins">Mensagens</h1>
                <button className="ml-auto p-2 rounded-full hover:bg-white/10"><CogIcon className="w-6 h-6" /></button>
            </header>

            <div className="flex flex-grow overflow-hidden">
                {/* Conversations List (Sidebar) */}
                <div className={`w-full md:w-1/3 lg:w-1/4 border-r border-[var(--color-border)] flex-col overflow-y-auto p-2 ${selectedConversationId ? 'hidden md:flex' : 'flex'}`}>
                    <div className="p-2">
                         <input type="text" placeholder="Buscar conversas..." className="w-full bg-black/20 p-2 rounded-lg border border-[var(--color-border)] outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)]" />
                    </div>
                    {conversationsWithDetails.map(convo => <ConversationListItem key={convo.id} convo={convo} />)}
                </div>

                {/* Chat Window */}
                <div className={`w-full md:w-2/3 lg:w-3/4 flex-col ${selectedConversationId ? 'flex' : 'hidden md:flex'}`}>
                    {selectedConversation ? (
                        <>
                            <div className="flex items-center gap-3 p-3 border-b border-[var(--color-border)]">
                                <button onClick={() => setSelectedConversationId(null)} className="md:hidden p-2 rounded-full hover:bg-white/10">
                                    <ChevronLeftIcon className="w-5 h-5" />
                                </button>
                                <div className="w-10 h-10 rounded-full bg-black/20 flex-shrink-0 flex items-center justify-center overflow-hidden">
                                     {selectedConversation.otherParticipant?.profile.personal.profilePicture ? <img src={selectedConversation.otherParticipant.profile.personal.profilePicture} alt="" className="w-full h-full object-cover"/> : <UserIconDefault />}
                                </div>
                                <div>
                                    <p className="font-bold">{selectedConversation.otherParticipant?.profile.personal.fullName}</p>
                                    <p className="text-xs text-green-400">Online</p>
                                </div>
                            </div>
                            
                            <div className="flex-grow p-4 overflow-y-auto space-y-4">
                                {messagesForSelectedConvo.map(msg => (
                                    <div key={msg.id} className={`flex items-end gap-2 ${msg.senderId === currentUser.id ? 'justify-end' : 'justify-start'}`}>
                                        <div className={`max-w-xs lg:max-w-md p-3 rounded-2xl ${msg.senderId === currentUser.id ? 'bg-[#2E7D32] rounded-br-none' : 'bg-[#334155] rounded-bl-none'}`}>
                                            <p className="text-sm">{msg.text}</p>
                                            <p className="text-xs text-white/50 text-right mt-1">{new Date(msg.timestamp).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}</p>
                                        </div>
                                    </div>
                                ))}
                                <div ref={messagesEndRef} />
                            </div>

                            <form onSubmit={handleSendMessage} className="p-4 border-t border-[var(--color-border)] flex items-center gap-3 bg-black/10">
                                <button type="button" className="p-2 text-[var(--color-text-secondary)] hover:text-white"><PaperClipIcon className="w-6 h-6"/></button>
                                <button type="button" className="p-2 text-[var(--color-text-secondary)] hover:text-white"><CameraIcon className="w-6 h-6"/></button>
                                <input 
                                    type="text"
                                    value={newMessage}
                                    onChange={(e) => setNewMessage(e.target.value)}
                                    placeholder="Escreva uma mensagem..."
                                    className="flex-grow bg-black/20 p-3 rounded-full border border-[var(--color-border)] outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)]"
                                />
                                <button type="submit" className="p-3 rounded-full bg-[var(--color-accent-primary)] text-slate-900 disabled:opacity-50" disabled={!newMessage.trim()}>
                                    <PaperAirplaneIcon className="w-6 h-6"/>
                                </button>
                            </form>
                        </>
                    ) : (
                        <div className="flex-grow flex flex-col items-center justify-center text-center p-4">
                            <div className="text-6xl mb-4 text-[var(--color-text-secondary)]">💬</div>
                            <h2 className="text-xl font-bold">Selecione uma conversa</h2>
                            <p className="text-[var(--color-text-secondary)]">Ou inicie uma nova para começar a conversar.</p>
                             <button className="mt-6 btn-save bg-purple-600 text-white font-bold py-2 px-5 rounded-lg hover:bg-purple-700">+ Nova Conversa</button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ChatView;