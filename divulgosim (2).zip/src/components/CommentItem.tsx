import React, { useState } from 'react';
import { EventComment, User } from '../../types.ts';
import { EditIcon, TrashIcon, UserIcon as UserIconDefault } from './Icons.tsx';

interface CommentItemProps {
    comment: EventComment;
    currentUser: User | null;
    canManageEvent: boolean;
    onUpdate: (commentId: string, text: string) => void;
    onDelete: (commentId: string) => void;
}

const timeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + " anos";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + " meses";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + " dias";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + " horas";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + " minutos";
    return "agora";
};


export const CommentItem: React.FC<CommentItemProps> = ({ comment, currentUser, canManageEvent, onUpdate, onDelete }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editText, setEditText] = useState(comment.text);

    const canEditOrDelete = currentUser && (currentUser.id === comment.userId || canManageEvent);

    const handleUpdate = () => {
        if (editText.trim()) {
            onUpdate(comment.id, editText);
            setIsEditing(false);
        }
    };
    
    const handleDelete = () => {
        if (window.confirm('Tem certeza que deseja excluir este comentário?')) {
            onDelete(comment.id);
        }
    };

    return (
        <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-black/20 flex-shrink-0 flex items-center justify-center overflow-hidden">
                 {comment.userProfilePicture ? (
                    <img src={comment.userProfilePicture} alt={comment.userName} className="w-full h-full object-cover"/>
                 ) : (
                    <UserIconDefault className="w-6 h-6 text-white"/>
                 )}
            </div>
            <div className="flex-grow">
                <div className="flex items-center gap-2">
                    <span className="font-semibold text-[var(--color-accent-primary)]">{comment.userName}</span>
                    <span className="text-xs text-[var(--color-text-secondary)]">{timeAgo(comment.createdAt)} atrás</span>
                </div>
                {isEditing ? (
                    <div className="mt-1">
                        <textarea 
                            value={editText}
                            onChange={(e) => setEditText(e.target.value)}
                            className="w-full bg-white/10 rounded-md p-2 text-sm border border-white/20 focus:ring-1 focus:ring-[var(--color-accent-primary)] outline-none transition-colors"
                        />
                        <div className="flex gap-2 mt-1">
                            <button onClick={handleUpdate} className="bg-green-600 text-xs px-2 py-1 rounded-md hover:bg-green-500">Salvar</button>
                            <button onClick={() => setIsEditing(false)} className="bg-gray-600 text-xs px-2 py-1 rounded-md hover:bg-gray-500">Cancelar</button>
                        </div>
                    </div>
                ) : (
                    <p className="text-sm text-white/90 mt-1 whitespace-pre-wrap">{comment.text}</p>
                )}
            </div>
            {canEditOrDelete && !isEditing && (
                <div className="flex gap-2">
                    <button onClick={() => setIsEditing(true)} className="text-[var(--color-text-secondary)] hover:text-[var(--color-accent-primary)]"><EditIcon className="w-4 h-4" /></button>
                    <button onClick={handleDelete} className="text-[var(--color-text-secondary)] hover:text-[var(--color-danger)]"><TrashIcon className="w-4 h-4" /></button>
                </div>
            )}
        </div>
    );
};