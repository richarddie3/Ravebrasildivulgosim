import React, { useState, useRef, ChangeEvent, useEffect } from 'react';
import { RaveEvent } from '../../types.ts';
import { CloseIcon, PlusIcon, CameraIcon, VideoCameraIcon, TrashIcon } from './Icons.tsx';

interface ManageGalleryModalProps {
    event: RaveEvent;
    onClose: () => void;
    onAddPhotos: (eventId: string, files: File[]) => void;
    onAddVideos: (eventId: string, files: File[]) => void;
}

type ActiveTab = 'photos' | 'videos';

// Preview component for staged files
const StagedFilePreview: React.FC<{ file: File, previewUrl: string, onRemove: () => void }> = ({ file, previewUrl, onRemove }) => (
    <div className="relative group aspect-square bg-black rounded-lg overflow-hidden">
        {file.type.startsWith('image') ? (
            <img src={previewUrl} alt={file.name} className="w-full h-full object-cover" />
        ) : (
            <video src={previewUrl} className="w-full h-full object-cover" />
        )}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <button type="button" onClick={onRemove} className="btn-cancel !p-2">
                <TrashIcon className="w-5 h-5" />
            </button>
        </div>
        <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-1 text-xs text-white truncate">
            {file.name}
        </div>
    </div>
);


export const ManageGalleryModal: React.FC<ManageGalleryModalProps> = ({ event, onClose, onAddPhotos, onAddVideos }) => {
    const [activeTab, setActiveTab] = useState<ActiveTab>('photos');
    
    // Staging area for new files
    const [stagedPhotos, setStagedPhotos] = useState<File[]>([]);
    const [stagedVideos, setStagedVideos] = useState<File[]>([]);
    const [photoPreviews, setPhotoPreviews] = useState<string[]>([]);
    const [videoPreviews, setVideoPreviews] = useState<string[]>([]);

    const [isUploading, setIsUploading] = useState(false);

    const photoInputRef = useRef<HTMLInputElement>(null);
    const videoInputRef = useRef<HTMLInputElement>(null);

    // Clean up preview URLs on unmount
    useEffect(() => {
        return () => {
            [...photoPreviews, ...videoPreviews].forEach(url => URL.revokeObjectURL(url));
        };
    }, [photoPreviews, videoPreviews]);

    const handleFileSelect = (e: ChangeEvent<HTMLInputElement>, type: 'photo' | 'video') => {
        if (e.target.files) {
            const files = Array.from(e.target.files);
            if (type === 'photo') {
                setStagedPhotos(prev => [...prev, ...files]);
                const newPreviews = files.map((file: File) => URL.createObjectURL(file));
                setPhotoPreviews(prev => [...prev, ...newPreviews]);
            } else {
                setStagedVideos(prev => [...prev, ...files]);
                const newPreviews = files.map((file: File) => URL.createObjectURL(file));
                setVideoPreviews(prev => [...prev, ...newPreviews]);
            }
            // Reset input value to allow selecting the same file again
            e.target.value = '';
        }
    };

    const handleRemoveStaged = (index: number, type: 'photo' | 'video') => {
        if (type === 'photo') {
            const newFiles = [...stagedPhotos];
            const newPreviews = [...photoPreviews];
            URL.revokeObjectURL(newPreviews[index]); // Clean up memory
            newFiles.splice(index, 1);
            newPreviews.splice(index, 1);
            setStagedPhotos(newFiles);
            setPhotoPreviews(newPreviews);
        } else {
            const newFiles = [...stagedVideos];
            const newPreviews = [...videoPreviews];
            URL.revokeObjectURL(newPreviews[index]);
            newFiles.splice(index, 1);
            newPreviews.splice(index, 1);
            setStagedVideos(newFiles);
            setVideoPreviews(newPreviews);
        }
    };

    const handleUpload = () => {
        if (stagedPhotos.length === 0 && stagedVideos.length === 0) return;
        
        setIsUploading(true);

        if (stagedPhotos.length > 0) {
            onAddPhotos(event.id, stagedPhotos);
        }
        if (stagedVideos.length > 0) {
            onAddVideos(event.id, stagedVideos);
        }

        // Simulating upload time
        setTimeout(() => {
            setStagedPhotos([]);
            setStagedVideos([]);
            setPhotoPreviews([]);
            setVideoPreviews([]);
            setIsUploading(false);
        }, 1000);
    };

    const tabButtonClass = (tab: ActiveTab) => 
        `px-4 py-2 rounded-t-lg font-semibold transition-colors w-full text-center flex items-center justify-center gap-2
         ${activeTab === tab ? 'bg-black/20 border-b-2 border-[var(--color-accent-primary)] text-[var(--color-accent-primary)]' : 'bg-transparent text-white hover:bg-white/5'}`;

    const hasStagedFiles = stagedPhotos.length > 0 || stagedVideos.length > 0;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-[var(--color-text-primary)]">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <div>
                        <h2 className="text-2xl font-bold font-poppins">Gerenciar Galeria</h2>
                        <p className="text-[var(--color-text-secondary)]">{event.name}</p>
                    </div>
                    <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>

                <div className="border-b border-[var(--color-border)] px-6">
                    <div className="flex">
                       <button type="button" onClick={() => setActiveTab('photos')} className={tabButtonClass('photos')}>
                            <CameraIcon className="w-5 h-5"/> Fotos ({event.gallery.length})
                       </button>
                       <button type="button" onClick={() => setActiveTab('videos')} className={tabButtonClass('videos')}>
                           <VideoCameraIcon className="w-5 h-5"/> Vídeos ({event.videos?.length || 0})
                       </button>
                    </div>
                </div>

                <div className="p-6 overflow-y-auto flex-grow space-y-6">
                    {/* Staging Area */}
                    {(activeTab === 'photos' && stagedPhotos.length > 0) && (
                         <div>
                            <h3 className="text-xl font-semibold mb-2 text-[var(--color-accent-primary)]">Prontas para Enviar ({stagedPhotos.length})</h3>
                            <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 bg-black/20 p-4 rounded-lg">
                                {stagedPhotos.map((file, index) => (
                                    <StagedFilePreview key={index} file={file} previewUrl={photoPreviews[index]} onRemove={() => handleRemoveStaged(index, 'photo')} />
                                ))}
                            </div>
                        </div>
                    )}
                    {(activeTab === 'videos' && stagedVideos.length > 0) && (
                         <div>
                            <h3 className="text-xl font-semibold mb-2 text-[var(--color-accent-primary)]">Prontos para Enviar ({stagedVideos.length})</h3>
                            <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 bg-black/20 p-4 rounded-lg">
                                {stagedVideos.map((file, index) => (
                                    <StagedFilePreview key={index} file={file} previewUrl={videoPreviews[index]} onRemove={() => handleRemoveStaged(index, 'video')} />
                                ))}
                            </div>
                        </div>
                    )}
                    {/* Existing Media */}
                    {(activeTab === 'photos') && (
                        <div>
                            <h3 className="text-xl font-semibold mb-4">Galeria de Fotos</h3>
                            {!isUploading && (
                                <div className="text-center mb-4">
                                    <button
                                        type="button"
                                        onClick={() => photoInputRef.current?.click()}
                                        className="w-full btn bg-[var(--color-accent-secondary)] text-slate-900 flex items-center justify-center gap-2"
                                    >
                                        <PlusIcon className="w-5 h-5"/> Adicionar Fotos
                                    </button>
                                    <input type="file" multiple accept="image/*" ref={photoInputRef} className="hidden" onChange={(e) => handleFileSelect(e, 'photo')} />
                                </div>
                            )}

                            {event.gallery.length > 0 ? (
                                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                                    {event.gallery.map(photo => (
                                        <div key={photo.id} className="relative group aspect-square bg-black rounded-lg overflow-hidden">
                                            <img src={photo.url} alt={photo.name} className="w-full h-full object-cover" />
                                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                <button type="button" onClick={() => console.log('delete photo', photo.id)} className="btn-cancel !p-2">
                                                    <TrashIcon className="w-5 h-5" />
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (stagedPhotos.length === 0 &&
                                <div className="text-center py-10 text-[var(--color-text-secondary)]">
                                   <CameraIcon className="w-12 h-12 mx-auto mb-2" />
                                   <p>Nenhuma foto na galeria.</p>
                               </div>
                            )}
                        </div>
                    )}
                    {(activeTab === 'videos') && (
                        <div>
                           <h3 className="text-xl font-semibold mb-4">Galeria de Vídeos</h3>
                           {!isUploading && (
                               <div className="text-center mb-4">
                                   <button
                                       type="button"
                                       onClick={() => videoInputRef.current?.click()}
                                       className="w-full btn bg-[var(--color-accent-secondary)] text-slate-900 flex items-center justify-center gap-2"
                                   >
                                       <PlusIcon className="w-5 h-5"/> Adicionar Vídeos
                                   </button>
                                   <input type="file" multiple accept="video/*" ref={videoInputRef} className="hidden" onChange={(e) => handleFileSelect(e, 'video')} />
                               </div>
                           )}

                           {(event.videos && event.videos.length > 0) ? (
                                <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                                   {event.videos.map(video => (
                                       <div key={video.id} className="relative group aspect-video bg-black rounded-lg overflow-hidden">
                                           <video src={video.url} className="w-full h-full object-cover" />
                                           <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                                <button type="button" onClick={() => console.log('delete video', video.id)} className="btn-cancel !p-2">
                                                   <TrashIcon className="w-5 h-5" />
                                               </button>
                                           </div>
                                       </div>
                                   ))}
                               </div>
                           ) : (stagedVideos.length === 0 &&
                               <div className="text-center py-10 text-[var(--color-text-secondary)]">
                                   <VideoCameraIcon className="w-12 h-12 mx-auto mb-2" />
                                   <p>Nenhum vídeo na galeria.</p>
                               </div>
                           )}
                       </div>
                   )}
                </div>

                <footer className="p-4 border-t border-[var(--color-border)] flex justify-end gap-3">
                   <button type="button" onClick={onClose} className="btn-cancel">Fechar</button>
                   {hasStagedFiles && (
                       <button type="button" onClick={handleUpload} disabled={isUploading} className="btn-save flex items-center gap-2">
                            {isUploading ? (
                               <>
                                   <svg className="animate-spin -ml-1 mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                       <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                       <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                   </svg>
                                   Enviando...
                               </>
                           ) : `Enviar ${stagedPhotos.length + stagedVideos.length} Mídias`}
                       </button>
                   )}
               </footer>
            </div>
        </div>
    );
};