import React from 'react';
import { User, RaveEvent, CoverageRequest, Photo } from '../types.ts';
import { CameraIcon, CalendarIcon } from './Icons.tsx';

interface PhotographerDashboardProps {
    user: User;
    events: RaveEvent[];
    requests: CoverageRequest[];
    onViewEventDetails: (event: RaveEvent) => void;
    onManageGallery: (event: RaveEvent) => void;
}

const PhotographerDashboard: React.FC<PhotographerDashboardProps> = ({ user, events, requests, onViewEventDetails, onManageGallery }) => {
    
    const myRequestEventIds = new Set(requests.filter(r => r.photographerId === user.id).map(r => r.eventId));
    const approvedEventIds = new Set(requests.filter(r => r.photographerId === user.id && r.status === 'approved').map(r => r.eventId));

    const availableEvents = events.filter(e => !myRequestEventIds.has(e.id));
    const approvedEvents = events.filter(e => approvedEventIds.has(e.id));

    return (
        <div className="w-full max-w-7xl">
             <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)] mb-6">Painel de Fotógrafo</h1>

             <div className="mb-8">
                <h2 className="text-xl font-bold mb-4">Meus Eventos Aprovados</h2>
                 {approvedEvents.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {approvedEvents.map(event => {
                            const photoCount = event.gallery.filter(p => p.userId === user.id).length;
                            return (
                                <div key={event.id} className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)]">
                                    <h3 className="font-bold">{event.name}</h3>
                                    <p className="text-xs text-slate-400">{event.dateString}</p>
                                    <p className="text-sm font-bold mt-2">{photoCount} fotos enviadas</p>
                                    <button onClick={() => onManageGallery(event)} className="w-full btn-save mt-3 !text-sm">Gerenciar Galeria</button>
                                </div>
                            );
                        })}
                    </div>
                ) : <p className="text-center text-slate-400 py-8 bg-black/10 rounded-lg">Nenhum evento com cobertura aprovada.</p>}
             </div>
             <div>
                <h2 className="text-xl font-bold mb-4">Eventos Buscando Fotógrafos</h2>
                 {availableEvents.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {availableEvents.map(event => (
                            <div key={event.id} className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)]">
                                <img src={event.image || ''} alt={event.name} className="w-full h-32 object-cover rounded-md mb-2" />
                                <h3 className="font-bold truncate">{event.name}</h3>
                                <p className="text-xs text-slate-400">{event.location}</p>
                                <button onClick={() => onViewEventDetails(event)} className="w-full btn bg-blue-600 text-white mt-3 !text-sm">Ver Detalhes e Aplicar</button>
                            </div>
                        ))}
                    </div>
                 ): <p className="text-center text-slate-400 py-8 bg-black/10 rounded-lg">Nenhum evento novo disponível no momento.</p>}
             </div>
        </div>
    );
}

export default PhotographerDashboard;