import React from 'react';
import { GigProposal, RaveEvent, User } from '../../types.ts';
import { CheckCircleIcon, CloseIcon } from './Icons.tsx';

interface PropostaCardProps {
    proposal: GigProposal;
    event?: RaveEvent;
    organizer?: User;
    onUpdateProposal: (proposalId: string, status: 'accepted' | 'rejected') => void;
}

const PropostaCard: React.FC<PropostaCardProps> = ({ proposal, event, organizer, onUpdateProposal }) => {
    
    if (!event || !organizer) {
        return (
            <div style={{ backgroundColor: '#1E293B', borderRadius: '12px' }} className="border border-slate-700 p-4 text-sm text-slate-400">
                Carregando dados da proposta...
            </div>
        );
    }
    
    return (
        <div style={{ backgroundColor: '#1E293B', borderRadius: '12px' }} className="border border-slate-700 shadow-md p-4 flex flex-col gap-3">
            <div>
                <p className="text-xs text-slate-400">Você recebeu um convite para tocar em:</p>
                <h4 className="font-bold font-montserrat text-lg text-white">{event.name}</h4>
                <p className="text-sm text-slate-400">de <span className="font-semibold text-slate-300">{organizer.profile.personal.fullName}</span></p>
                <p className="text-sm text-slate-500 mt-1">{event.dateString}</p>
            </div>

            {proposal.status === 'pending' && (
                <div className="flex gap-2 mt-auto">
                    <button 
                        type="button"
                        onClick={() => onUpdateProposal(proposal.id, 'accepted')}
                        style={{ backgroundColor: '#FFD700', color: '#1E293B' }}
                        className="w-full btn font-bold"
                    >
                        <CheckCircleIcon className="w-5 h-5" /> Aceitar
                    </button>
                     <button 
                        type="button"
                        onClick={() => onUpdateProposal(proposal.id, 'rejected')}
                        style={{ backgroundColor: '#ef4444' }}
                        className="w-full btn text-white font-bold"
                    >
                        <CloseIcon className="w-5 h-5" /> Recusar
                    </button>
                </div>
            )}
        </div>
    );
};

export default PropostaCard;