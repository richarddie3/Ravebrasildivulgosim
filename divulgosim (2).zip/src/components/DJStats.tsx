import React from 'react';
import { DJStats, User } from '../../types.ts';
import { ChartBarIcon, MusicIcon, UsersIcon, WalletIcon } from './Icons.tsx';

interface DJStatsPanelProps {
    stats: DJStats;
    user: User;
}

const StatItem: React.FC<{ icon: React.ReactNode, label: string, value: string | number }> = ({ icon, label, value }) => (
    <div className="flex items-center gap-3">
        <div style={{ backgroundColor: '#9C27B0' }} className="p-2 rounded-lg text-white">
            {icon}
        </div>
        <div>
            <p className="font-bold text-lg text-white">{value}</p>
            <p className="text-xs text-slate-400">{label}</p>
        </div>
    </div>
);

const DJStatsPanel: React.FC<DJStatsPanelProps> = ({ stats, user }) => {

    const rbInReal = (user.rbBalance * 0.01).toFixed(2).replace('.', ',');

    return (
        <div style={{ backgroundColor: '#1E293B', borderRadius: '12px' }} className="border border-slate-700 p-6 space-y-6 sticky top-6">
            <h3 className="text-xl font-bold font-montserrat text-white">Estatísticas</h3>
            <div className="space-y-4">
                <StatItem 
                    icon={<MusicIcon className="w-5 h-5" />}
                    label="Faixas Publicadas"
                    value={stats.trackCount}
                />
                <StatItem 
                    icon={<UsersIcon className="w-5 h-5" />}
                    label="Ouvintes Mensais"
                    value={stats.monthlyListeners.toLocaleString('pt-BR')}
                />
                <StatItem 
                    icon={<ChartBarIcon className="w-5 h-5" />}
                    label="Eventos com Faixas"
                    value={stats.eventsPlayed}
                />
            </div>
            <div className="pt-6 border-t border-slate-700">
                 <h3 className="text-xl font-bold font-montserrat text-white mb-4">Saldo</h3>
                 <StatItem 
                    icon={<WalletIcon className="w-5 h-5" />}
                    label={`Equivalente a ~R$ ${rbInReal}`}
                    value={`${user.rbBalance.toLocaleString('pt-BR')} RB`}
                />
            </div>
        </div>
    );
};

export default DJStatsPanel;