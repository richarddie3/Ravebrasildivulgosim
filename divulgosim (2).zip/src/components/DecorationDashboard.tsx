import React from 'react';
import { User, DecorationProject } from '../types.ts';
import { PlusIcon, SparklesIcon, EditIcon, TrashIcon } from './Icons.tsx';

interface DecorationDashboardProps {
    user: User;
    projects: DecorationProject[];
    onOpenProjectModal: (project?: DecorationProject) => void;
    onDeleteProject: (projectId: string) => void;
}

const DecorationDashboard: React.FC<DecorationDashboardProps> = ({ user, projects, onOpenProjectModal, onDeleteProject }) => {
    
    const handleDelete = (projectId: string, projectName: string) => {
        if (window.confirm(`Tem certeza que deseja excluir o projeto "${projectName}"?`)) {
            onDeleteProject(projectId);
        }
    };

    return (
        <div className="w-full max-w-7xl">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)]">Painel de Decoração</h1>
                <button onClick={() => onOpenProjectModal()} className="btn bg-[var(--color-accent-secondary)] text-slate-900">
                    <PlusIcon className="w-5 h-5" /> Adicionar Projeto
                </button>
            </div>

            {projects.length > 0 ? (
                 <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {projects.map(project => (
                        <div key={project.id} className="bg-black/20 rounded-lg border border-[var(--color-border)] flex flex-col group overflow-hidden">
                            <div className="aspect-video w-full overflow-hidden">
                                <img src={project.coverImage} alt={project.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                            </div>
                            <div className="p-4 flex flex-col flex-grow">
                                <h3 className="font-bold text-lg truncate">{project.name}</h3>
                                <p className="text-sm text-slate-400 line-clamp-2 flex-grow mt-1">{project.description}</p>
                                <div className="flex gap-2 mt-4">
                                    <button onClick={() => onOpenProjectModal(project)} className="w-full btn bg-slate-600 text-white !text-sm">
                                        <EditIcon className="w-4 h-4" /> Editar
                                    </button>
                                    <button onClick={() => handleDelete(project.id, project.name)} className="btn bg-red-600/80 text-white !text-sm !px-3">
                                        <TrashIcon className="w-4 h-4" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-black/10 rounded-lg">
                    <SparklesIcon className="w-16 h-16 mx-auto text-slate-500 mb-4" />
                    <h3 className="text-xl font-semibold">Nenhum projeto cadastrado</h3>
                    <p className="text-slate-400 mt-2">Clique em "Adicionar Projeto" para começar a montar seu portfólio.</p>
                </div>
            )}
        </div>
    );
};

export default DecorationDashboard;