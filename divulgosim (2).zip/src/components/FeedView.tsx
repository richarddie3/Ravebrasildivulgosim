import React, { useState, useRef, ChangeEvent } from 'react';
import { User, Post, PostComment } from '../../types.ts';
import { HeartIcon, ChatBubbleLeftRightIcon, ShareIcon, UserIcon as UserIconDefault, PaperAirplaneIcon, CameraIcon, VideoCameraIcon, CloseIcon } from './Icons.tsx';


interface CreatePostFormProps {
    currentUser: User;
    onAddPost: (caption: string, mediaUrl?: string, mediaType?: 'image' | 'video') => void;
}

const CreatePostForm: React.FC<CreatePostFormProps> = ({ currentUser, onAddPost }) => {
    const [caption, setCaption] = useState('');
    const [imageFile, setImageFile] = useState<File | null>(null);
    const [imagePreview, setImagePreview] = useState<string | null>(null);
    const [videoFile, setVideoFile] = useState<File | null>(null);
    const [videoPreview, setVideoPreview] = useState<string | null>(null);
    const imageInputRef = useRef<HTMLInputElement>(null);
    const videoInputRef = useRef<HTMLInputElement>(null);

    const handleRemoveImage = () => {
        setImageFile(null);
        if (imagePreview) {
            URL.revokeObjectURL(imagePreview);
            setImagePreview(null);
        }
        if (imageInputRef.current) {
            imageInputRef.current.value = '';
        }
    };

    const handleRemoveVideo = () => {
        setVideoFile(null);
        if (videoPreview) {
            URL.revokeObjectURL(videoPreview);
            setVideoPreview(null);
        }
        if (videoInputRef.current) {
            videoInputRef.current.value = '';
        }
    };
    
    const handleImageChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            handleRemoveVideo(); // Clear video if image is selected
            const file = e.target.files[0];
            setImageFile(file);
            const preview = URL.createObjectURL(file);
            setImagePreview(preview);
        }
    };

    const handleVideoChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            handleRemoveImage(); // Clear image if video is selected
            const file = e.target.files[0];
            setVideoFile(file);
            const preview = URL.createObjectURL(file);
            setVideoPreview(preview);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!caption.trim() && !imageFile && !videoFile) return;

        if (imagePreview && imageFile) {
            onAddPost(caption, imagePreview, 'image');
        } else if (videoPreview && videoFile) {
            onAddPost(caption, videoPreview, 'video');
        } else if (caption.trim()) {
            onAddPost(caption);
        }

        setCaption('');
        handleRemoveImage();
        handleRemoveVideo();
    };
    
    return (
        <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl p-4 mb-8">
            <form onSubmit={handleSubmit}>
                <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-black/20 overflow-hidden flex-shrink-0">
                         {currentUser.profile.personal.profilePicture ? (
                            <img src={currentUser.profile.personal.profilePicture} alt={currentUser.profile.personal.fullName} className="w-full h-full object-cover"/>
                         ) : (
                            <UserIconDefault className="w-6 h-6 text-white m-auto mt-1.5"/>
                         )}
                    </div>
                    <textarea
                        value={caption}
                        onChange={(e) => setCaption(e.target.value)}
                        placeholder={`No que você está pensando, ${currentUser.profile.personal.fullName.split(' ')[0]}?`}
                        className="w-full bg-transparent text-lg resize-none outline-none text-white placeholder:text-slate-500"
                        rows={2}
                    />
                </div>

                {imagePreview && (
                    <div className="mt-4 pl-12 relative">
                        <img src={imagePreview} alt="Preview" className="rounded-lg max-h-80 w-auto" />
                        <button type="button" onClick={handleRemoveImage} className="absolute top-2 right-2 bg-black/50 p-1.5 rounded-full text-white hover:bg-black">
                            <CloseIcon className="w-5 h-5" />
                        </button>
                    </div>
                )}
                
                {videoPreview && (
                    <div className="mt-4 pl-12 relative">
                        <video src={videoPreview} controls className="rounded-lg max-h-80 w-auto" />
                        <button type="button" onClick={handleRemoveVideo} className="absolute top-2 right-2 bg-black/50 p-1.5 rounded-full text-white hover:bg-black">
                            <CloseIcon className="w-5 h-5" />
                        </button>
                    </div>
                )}


                <div className="mt-4 pl-12 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <input type="file" accept="image/*" ref={imageInputRef} className="hidden" onChange={handleImageChange} />
                        <button type="button" onClick={() => imageInputRef.current?.click()} className="flex items-center gap-2 text-sm font-semibold text-green-400 hover:text-green-300 p-2 rounded-lg hover:bg-green-500/10">
                            <CameraIcon className="w-5 h-5"/> Foto
                        </button>
                        <input type="file" accept="video/*" ref={videoInputRef} className="hidden" onChange={handleVideoChange} />
                        <button type="button" onClick={() => videoInputRef.current?.click()} className="flex items-center gap-2 text-sm font-semibold text-blue-400 hover:text-blue-300 p-2 rounded-lg hover:bg-blue-500/10">
                            <VideoCameraIcon className="w-5 h-5"/> Vídeo
                        </button>
                    </div>
                    <button type="submit" disabled={!caption.trim() && !imageFile && !videoFile} className="btn bg-[var(--color-accent-primary)] text-slate-900 disabled:opacity-50 disabled:cursor-not-allowed">
                        Publicar
                    </button>
                </div>
            </form>
        </div>
    );
};


// Sub-component for individual comments
const Comment: React.FC<{ comment: PostComment, author?: User }> = ({ comment, author }) => (
    <div className="flex items-start gap-2 text-sm">
        <div className="w-8 h-8 rounded-full bg-black/20 overflow-hidden flex-shrink-0">
            {author?.profile.personal.profilePicture ? (
                <img src={author.profile.personal.profilePicture} alt={author.profile.personal.username} className="w-full h-full object-cover" />
            ) : (
                <UserIconDefault className="w-5 h-5 text-white m-auto mt-1" />
            )}
        </div>
        <div className="bg-black/20 px-3 py-2 rounded-lg">
            <p><strong className="font-semibold">{author?.profile.personal.username || 'Usuário'}</strong> {comment.text}</p>
        </div>
    </div>
);

// The main Post Card component
const PostCard: React.FC<{ 
    post: Post; 
    author: User;
    currentUser: User;
    allUsers: User[];
    onUpdatePost: (updatedPost: Post) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}> = ({ post, author, currentUser, allUsers, onUpdatePost, showToast }) => {
    
    const [showComments, setShowComments] = useState(false);
    const [newComment, setNewComment] = useState('');

    const isLiked = post.likes.includes(currentUser.id);

    const handleLike = () => {
        const newLikes = isLiked 
            ? post.likes.filter(id => id !== currentUser.id)
            : [...post.likes, currentUser.id];
        onUpdatePost({ ...post, likes: newLikes });
    };

    const handleShare = () => {
        navigator.clipboard.writeText(`https://divulgosim.com/post/${post.id}`);
        showToast('Link da postagem copiado!', 'success');
    };

    const handleAddComment = (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim()) return;

        const comment: PostComment = {
            id: `comment-${Date.now()}`,
            userId: currentUser.id,
            text: newComment.trim(),
            createdAt: new Date().toISOString(),
        };

        onUpdatePost({ ...post, comments: [...post.comments, comment] });
        setNewComment('');
    };

    const getCommentAuthor = (userId: string) => allUsers.find(u => u.id === userId);

    return (
        <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl overflow-hidden">
            <div className="p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-black/20 overflow-hidden">
                    {author.profile.personal.profilePicture ? (
                        <img src={author.profile.personal.profilePicture} alt={author.profile.personal.fullName} className="w-full h-full object-cover" />
                    ) : (
                        <UserIconDefault className="w-6 h-6 text-white m-auto" />
                    )}
                </div>
                <div>
                    <p className="font-semibold">{author.profile.personal.fullName}</p>
                    <p className="text-xs text-[var(--color-text-secondary)]">@{author.profile.personal.username}</p>
                </div>
            </div>
            
            {post.mediaUrl && (
                post.mediaType === 'image' ? (
                    <img src={post.mediaUrl} alt={post.caption} className="w-full max-h-[70vh] object-contain bg-black" />
                ) : post.mediaType === 'video' ? (
                    <video src={post.mediaUrl} controls className="w-full max-h-[70vh] object-contain bg-black" />
                ) : null
            )}

            <div className="p-4">
                <div className="flex items-center gap-4 text-[var(--color-text-secondary)] mb-2">
                    <button type="button" onClick={handleLike} className={`flex items-center gap-1.5 transition-colors ${isLiked ? 'text-pink-500' : 'hover:text-pink-500'}`}>
                        <HeartIcon className="w-6 h-6" fill={isLiked ? 'currentColor' : 'none'} /> 
                        <span>{post.likes.length}</span>
                    </button>
                    <button type="button" onClick={() => setShowComments(!showComments)} className="flex items-center gap-1.5 hover:text-white">
                        <ChatBubbleLeftRightIcon className="w-6 h-6" /> 
                        <span>{post.comments.length}</span>
                    </button>
                    <button type="button" onClick={handleShare} className="flex items-center gap-1.5 hover:text-white ml-auto"><ShareIcon className="w-6 h-6" /></button>
                </div>

                <p className="text-sm"><strong className="font-semibold">{author.profile.personal.username}</strong> {post.caption}</p>
                <p className="text-xs text-[var(--color-text-secondary)] mt-2">{new Date(post.createdAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</p>
            </div>

            {/* Comments Section */}
            {showComments && (
                <div className="p-4 border-t border-[var(--color-border)] space-y-4">
                    <div className="max-h-48 overflow-y-auto space-y-3 pr-2">
                        {post.comments.length > 0 ? post.comments.map(c => <Comment key={c.id} comment={c} author={getCommentAuthor(c.userId)} />) : <p className="text-sm text-center text-slate-400">Nenhum comentário ainda.</p>}
                    </div>
                    
                    <form onSubmit={handleAddComment} className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-black/20 overflow-hidden flex-shrink-0">
                            {currentUser.profile.personal.profilePicture ? (
                                <img src={currentUser.profile.personal.profilePicture} alt={currentUser.profile.personal.username} className="w-full h-full object-cover" />
                            ) : (
                                <UserIconDefault className="w-5 h-5 text-white m-auto mt-1" />
                            )}
                        </div>
                        <input 
                            type="text"
                            value={newComment}
                            onChange={e => setNewComment(e.target.value)}
                            placeholder="Adicione um comentário..."
                            className="flex-grow bg-black/20 p-2 rounded-full border border-[var(--color-border)] outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)] text-sm"
                        />
                        <button type="submit" className="p-2 rounded-full bg-[var(--color-accent-primary)] text-slate-900 disabled:opacity-50" disabled={!newComment.trim()}>
                            <PaperAirplaneIcon className="w-5 h-5"/>
                        </button>
                    </form>
                </div>
            )}
        </div>
    );
};


// The main Feed View component
export const FeedView: React.FC<{
    currentUser: User;
    allUsers: User[];
    onUpdatePost: (updatedPost: Post) => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
    onAddPost: (caption: string, mediaUrl?: string, mediaType?: 'image' | 'video') => void;
}> = ({ currentUser, allUsers, onUpdatePost, showToast, onAddPost }) => {

    const feedPosts: { post: Post, author: User }[] = React.useMemo(() => {
        const followingIds = new Set(currentUser.following || []);
        
        const posts: { post: Post, author: User }[] = [];
        allUsers.forEach(user => {
            if ((followingIds.has(user.id) || user.id === currentUser.id) && user.posts) {
                user.posts.forEach(post => {
                    posts.push({ post, author: user });
                });
            }
        });

        const uniquePosts = Array.from(new Map(posts.map(p => [p.post.id, p])).values());

        return uniquePosts.sort((a, b) => new Date(b.post.createdAt).getTime() - new Date(a.post.createdAt).getTime());
    }, [currentUser, allUsers]);

    return (
        <div className="w-full max-w-2xl mx-auto">
             <h1 className="text-3xl sm:text-4xl font-bold font-montserrat text-[var(--color-accent-primary)] mb-6">Feed</h1>
             <CreatePostForm currentUser={currentUser} onAddPost={onAddPost} />
            <div className="space-y-8">
                {feedPosts.length > 0 ? (
                    feedPosts.map(({ post, author }) => (
                        <PostCard 
                            key={post.id} 
                            post={post} 
                            author={author}
                            currentUser={currentUser}
                            allUsers={allUsers}
                            onUpdatePost={onUpdatePost}
                            showToast={showToast}
                        />
                    ))
                ) : (
                    <div className="text-center py-16 bg-[var(--color-bg-secondary)] rounded-lg">
                        <h3 className="text-xl font-semibold">Seu feed está vazio</h3>
                        <p className="text-[var(--color-text-secondary)] mt-2">Siga outros usuários para ver as postagens deles aqui.</p>
                    </div>
                )}
            </div>
        </div>
    );
};