import React from 'react';
import { RaveEvent } from '../../types.ts';
import { ChevronLeftIcon, ChevronRightIcon } from './Icons.tsx';

interface CalendarProps {
  currentDate: Date;
  setCurrentDate: (date: Date) => void;
  eventsByDate: Map<string, RaveEvent[]>;
  onDayClick: (date: Date, dayEvents: RaveEvent[]) => void;
}

const Calendar: React.FC<CalendarProps> = ({ currentDate, setCurrentDate, eventsByDate, onDayClick }) => {
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const getMonthName = (monthIndex: number) => {
    const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    return months[monthIndex];
  };
  
  const today = new Date();
  const isToday = (day: number) => year === today.getFullYear() && month === today.getMonth() && day === today.getDate();

  const handleKeyDown = (e: React.KeyboardEvent, date: Date, dayEvents: RaveEvent[]) => {
    if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onDayClick(date, dayEvents);
    }
  };

  const renderDays = () => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();

    const days = [];

    for (let i = 0; i < startingDay; i++) {
      days.push(<div key={`empty-${i}`} className=""></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const date = new Date(year, month, day);
        const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

        const dayEvents = eventsByDate.get(dateString) || [];
        
        let dayClasses = "relative flex justify-center items-center aspect-square rounded-lg font-medium bg-[#161b22] transition-all duration-300 cursor-pointer hover:border-yellow-400 border border-transparent";

        if (dayEvents.length > 0) {
            dayClasses = `relative flex justify-center items-center aspect-square rounded-lg font-semibold transition-all duration-300 cursor-pointer bg-green-500 text-white shadow-md hover:opacity-90`;
        }
        
        if (isToday(day)) {
            dayClasses += ' border-2 border-yellow-400';
        }

      days.push(
        <div 
            key={day} 
            className={dayClasses} 
            onClick={() => onDayClick(date, dayEvents)}
            onKeyDown={(e) => handleKeyDown(e, date, dayEvents)}
            role="button"
            tabIndex={0}
            aria-label={`Eventos do dia ${day} de ${getMonthName(month)}`}
        >
          {day}
          {dayEvents.length > 0 && <div className="absolute bottom-1.5 w-1.5 h-1.5 bg-white rounded-full"></div>}
        </div>
      );
    }

    return days;
  };

  return (
    <div className="bg-slate-900/50 backdrop-blur-md rounded-2xl shadow-2xl p-4 sm:p-6 border border-[var(--color-border)] w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-white text-2xl font-bold font-poppins">{`${getMonthName(month)} ${year}`}</h2>
        <div className="flex gap-2">
          <button 
            onClick={() => setCurrentDate(new Date(year, month - 1))} 
            className="bg-black/20 border border-[var(--color-border)] text-white w-10 h-10 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 hover:bg-white/10"
            aria-label="Mês anterior"
          >
            <ChevronLeftIcon className="w-5 h-5"/>
          </button>
          <button 
            onClick={() => setCurrentDate(new Date(year, month + 1))} 
            className="bg-black/20 border border-[var(--color-border)] text-white w-10 h-10 rounded-full flex items-center justify-center cursor-pointer transition-all duration-300 hover:bg-white/10"
            aria-label="Próximo mês"
          >
            <ChevronRightIcon className="w-5 h-5"/>
          </button>
        </div>
      </div>
      <div className="grid grid-cols-7 gap-1.5 sm:gap-2.5">
        {['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'].map(day => (
          <div key={day} className="text-center font-bold text-gray-400 py-2 text-xs sm:text-sm">{day}</div>
        ))}
        {renderDays()}
      </div>
    </div>
  );
};

export default Calendar;