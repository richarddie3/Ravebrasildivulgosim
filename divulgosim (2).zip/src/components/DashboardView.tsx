import React, { useState, useMemo } from 'react';
import { RaveEvent, Task, TicketSale, User, UserType } from '../../types.ts';
// FIX: Added PaperClipIcon to the import list.
import { CalendarIcon, ClipboardIcon, UsersIcon, WalletIcon, SparklesIcon, CalendarPlusIcon, PlusIcon, CheckCircleIcon, ClockIcon, ChartBarIcon, FilterIcon, PaperClipIcon } from './Icons.tsx';

interface DashboardViewProps {
    user: User;
    events: RaveEvent[];
    tasks: Task[];
    users: User[];
    ticketSales: TicketSale[];
    onAddTask: () => void;
    onAddEvent: () => void;
    showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
    onViewProfile: (user: User) => void;
    onViewEvent: (event: RaveEvent) => void;
}

const SummaryCard: React.FC<{ icon: React.ReactNode; title: string; value: string | number; subtext?: string; }> = ({ icon, title, value, subtext }) => (
    <div className="bg-black/20 p-6 rounded-xl border border-[var(--color-border)] flex flex-col justify-between">
        <div className="flex justify-between items-center">
            <h3 className="text-sm font-semibold text-[var(--color-text-secondary)]">{title}</h3>
            <div className="text-[var(--color-accent-primary)]">{icon}</div>
        </div>
        <div>
            <p className="text-3xl font-bold mt-2">{value}</p>
            {subtext && <p className="text-xs text-[var(--color-text-secondary)]">{subtext}</p>}
        </div>
    </div>
);

const TaskProgressByEvent: React.FC<{ events: RaveEvent[], tasks: Task[], onViewEvent: (event: RaveEvent) => void }> = ({ events, tasks, onViewEvent }) => {
    const data = events.slice(0, 5).map(event => {
        const eventTasks = tasks.filter(t => t.eventId === event.id);
        const total = eventTasks.length;
        const completed = eventTasks.filter(t => t.status === 'approved' || t.status === 'completed').length;
        const percentage = total > 0 ? (completed / total) * 100 : 0;
        return { ...event, name: event.name, percentage };
    });

    return (
        <div className="bg-black/20 p-6 rounded-xl border border-[var(--color-border)]">
            <h3 className="text-lg font-bold mb-4">Progresso de Tarefas por Evento</h3>
            <div className="space-y-3">
                {data.map(item => (
                    <button key={item.id} onClick={() => onViewEvent(item)} className="w-full text-left group">
                        <div className="flex justify-between text-sm mb-1 group-hover:text-[var(--color-accent-primary)] transition-colors">
                            <span className="truncate pr-2">{item.name}</span>
                            <span className="font-semibold">{Math.round(item.percentage)}%</span>
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2">
                            <div className="bg-gradient-to-r from-yellow-400 to-amber-500 h-2 rounded-full" style={{ width: `${item.percentage}%` }}></div>
                        </div>
                    </button>
                ))}
            </div>
        </div>
    );
};

const PromoterRanking: React.FC<{ users: User[], tasks: Task[], onViewProfile: (user: User) => void }> = ({ users, tasks, onViewProfile }) => {
    const promoters = users.filter(u => u.roles.includes(UserType.PROMOTER));
    const rankedPromoters = promoters.map(promoter => {
        const completedTasks = tasks.filter(t => t.assigneeId === promoter.id && (t.status === 'completed' || t.status === 'approved')).length;
        return { ...promoter, completedTasks };
    }).sort((a, b) => b.completedTasks - a.completedTasks).slice(0, 5);

    return (
        <div className="bg-black/20 p-6 rounded-xl border border-[var(--color-border)]">
            <h3 className="text-lg font-bold mb-4">Ranking de Divulgadores</h3>
            <ul className="space-y-3">
                {rankedPromoters.map((promoter, index) => (
                    <li key={promoter.id}>
                        <button onClick={() => onViewProfile(promoter)} className="w-full flex items-center justify-between text-sm group transition-colors hover:bg-white/5 p-1 rounded-md">
                            <div className="flex items-center gap-3">
                                <span className="font-bold text-slate-400 w-4">{index + 1}.</span>
                                <span className="group-hover:text-white">{promoter.profile.personal.fullName}</span>
                            </div>
                            <span className="font-bold bg-green-500/20 text-green-300 px-2 py-0.5 rounded-full">{promoter.completedTasks} tarefas</span>
                        </button>
                    </li>
                ))}
            </ul>
        </div>
    );
};

const RecentActivity: React.FC<{ tasks: Task[], ticketSales: TicketSale[], users: User[] }> = ({ tasks, ticketSales, users }) => {
    const combinedActivities = useMemo(() => {
        const taskActivities = tasks.map(task => ({
            id: `task-${task.id}`,
            type: 'task',
            date: new Date(task.deadline), // Using deadline for sorting
            data: task,
        }));
        const saleActivities = ticketSales.map(sale => ({
            id: `sale-${sale.id}`,
            type: 'sale',
            date: new Date(sale.soldAt),
            data: sale,
        }));

        return [...taskActivities, ...saleActivities]
            .sort((a, b) => b.date.getTime() - a.date.getTime())
            .slice(0, 7);
    }, [tasks, ticketSales]);

    const getStatusIcon = (status: Task['status']) => {
        switch (status) {
            case 'approved': return <CheckCircleIcon className="w-5 h-5 text-green-400" />;
            case 'completed': return <CheckCircleIcon className="w-5 h-5 text-blue-400" />;
            case 'pending': return <ClockIcon className="w-5 h-5 text-yellow-400" />;
        }
    };
    
    return (
        <div className="bg-black/20 p-6 rounded-xl border border-[var(--color-border)] md:col-span-2">
            <h3 className="text-lg font-bold mb-4">Atividades Recentes</h3>
            <div className="space-y-3">
                {combinedActivities.map(activity => (
                    <div key={activity.id} className="flex items-center justify-between text-sm border-b border-slate-800 pb-2 last:border-b-0">
                        {activity.type === 'task' ? (
                            <>
                                <div className="flex items-center gap-3">
                                    {getStatusIcon((activity.data as Task).status)}
                                    <div>
                                        <p className="font-semibold">Tarefa criada: {(activity.data as Task).title}</p>
                                        <p className="text-xs text-slate-400">
                                            {(activity.data as Task).assigneeId ? `Para: ${users.find(u => u.id === (activity.data as Task).assigneeId)?.profile.personal.fullName}` : 'Tarefa aberta'}
                                        </p>
                                    </div>
                                </div>
                                <span className="text-xs text-slate-500">{activity.date.toLocaleDateString('pt-BR')}</span>
                            </>
                        ) : (
                             <>
                                <div className="flex items-center gap-3">
                                    <WalletIcon className="w-5 h-5 text-green-400" />
                                    <div>
                                        <p className="font-semibold">Venda de ingresso: {(activity.data as TicketSale).ticketName}</p>
                                        <p className="text-xs text-slate-400">
                                            Valor: R$ {((activity.data as TicketSale).pricePerTicket * (activity.data as TicketSale).quantity).toFixed(2).replace('.', ',')}
                                        </p>
                                    </div>
                                </div>
                                <span className="text-xs text-slate-500">{activity.date.toLocaleDateString('pt-BR')}</span>
                            </>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

const SalesChart: React.FC<{ sales: TicketSale[] }> = ({ sales }) => {
    const salesByDay = useMemo(() => {
        const data = sales.reduce((acc, sale) => {
            const day = new Date(sale.soldAt).toLocaleDateString('pt-BR');
            const revenue = sale.quantity * sale.pricePerTicket;
            acc[day] = (acc[day] || 0) + revenue;
            return acc;
        }, {} as Record<string, number>);
        return Object.entries(data).slice(-7); // Last 7 days with sales
    }, [sales]);

    const maxSale = Math.max(...salesByDay.map(([, revenue]) => revenue), 0);

    return (
        <div className="bg-black/20 p-6 rounded-xl border border-[var(--color-border)]">
            <h3 className="text-lg font-bold mb-4">Vendas nos Últimos Dias</h3>
            <div className="flex justify-around items-end h-48 gap-2">
                {salesByDay.map(([day, revenue]) => (
                    <div key={day} className="flex-1 flex flex-col items-center justify-end gap-1 group">
                        <div className="text-xs font-bold text-white bg-black/40 px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 transition-opacity">
                            R${revenue.toFixed(2)}
                        </div>
                        <div className="w-full bg-gradient-to-t from-yellow-500 to-amber-400 rounded-t-md hover:opacity-80 transition-opacity" 
                             style={{ height: maxSale > 0 ? `${(revenue / maxSale) * 100}%` : '0%' }}>
                        </div>
                        <div className="text-xs text-slate-400">{day.substring(0, 5)}</div>
                    </div>
                ))}
            </div>
        </div>
    )
}

const DashboardView: React.FC<DashboardViewProps> = ({ user, events, tasks, users, ticketSales, onAddEvent, onAddTask, showToast, onViewEvent, onViewProfile }) => {
    const [filters, setFilters] = useState({ eventId: 'all', startDate: '', endDate: '' });

    const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
        setFilters(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    const filteredData = useMemo(() => {
        let filteredEvents = events;
        let filteredTasks = tasks;
        let filteredSales = ticketSales;

        if (filters.eventId !== 'all') {
            filteredEvents = events.filter(e => e.id === filters.eventId);
            filteredTasks = tasks.filter(t => t.eventId === filters.eventId);
            filteredSales = ticketSales.filter(ts => ts.eventId === filters.eventId);
        }

        if (filters.startDate) {
            const start = new Date(filters.startDate).getTime();
            filteredSales = filteredSales.filter(ts => new Date(ts.soldAt).getTime() >= start);
            filteredTasks = filteredTasks.filter(t => new Date(t.deadline).getTime() >= start);
        }
        if (filters.endDate) {
            const end = new Date(filters.endDate).getTime();
            filteredSales = filteredSales.filter(ts => new Date(ts.soldAt).getTime() <= end);
            filteredTasks = filteredTasks.filter(t => new Date(t.deadline).getTime() <= end);
        }

        return { events: filteredEvents, tasks: filteredTasks, ticketSales: filteredSales };
    }, [events, tasks, ticketSales, filters]);


    const totalRevenue = filteredData.ticketSales.reduce((sum, sale) => sum + (sale.quantity * sale.pricePerTicket), 0);
    const totalPromoters = users.filter(u => u.roles.includes(UserType.PROMOTER)).length;
    const taskStats = filteredData.tasks.reduce((acc, task) => {
        acc[task.status] = (acc[task.status] || 0) + 1;
        return acc;
    }, {} as Record<Task['status'], number>);
    const totalLinks = filteredData.tasks.filter(t => t.link).length;

    const handleAIAnalysis = () => {
        showToast("Iniciando análise com IA... (Funcionalidade simulada)", "info");
    };

    return (
        <div className="w-full max-w-7xl">
            <header className="mb-8">
                <h1 className="text-3xl font-bold font-poppins">Dashboard Principal</h1>
                <p className="text-[var(--color-text-secondary)]">Bem-vindo(a), {user.profile.personal.fullName.split(' ')[0]}. Aqui está um resumo do seu sistema.</p>
            </header>

             <div className="bg-black/20 p-4 rounded-xl border border-[var(--color-border)] mb-8 flex flex-col md:flex-row items-center gap-4">
                <FilterIcon className="w-5 h-5 text-[var(--color-accent-primary)]" />
                <select name="eventId" value={filters.eventId} onChange={handleFilterChange} className="form-control !py-2 flex-grow">
                    <option value="all">Todos os Eventos</option>
                    {events.map(event => <option key={event.id} value={event.id}>{event.name}</option>)}
                </select>
                <input type="date" name="startDate" value={filters.startDate} onChange={handleFilterChange} className="form-control !py-2" />
                <input type="date" name="endDate" value={filters.endDate} onChange={handleFilterChange} className="form-control !py-2" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <SummaryCard icon={<CalendarIcon className="w-6 h-6"/>} title="Eventos Ativos" value={filteredData.events.length} subtext="Eventos no filtro atual" />
                <SummaryCard icon={<ClipboardIcon className="w-6 h-6"/>} title="Tarefas Totais" value={filteredData.tasks.length} subtext={`${taskStats.approved || 0} aprovadas`} />
                <SummaryCard icon={<ClockIcon className="w-6 h-6"/>} title="Tarefas Pendentes" value={taskStats.pending || 0} subtext="Aguardando envio ou aprovação" />
                <SummaryCard icon={<WalletIcon className="w-6 h-6"/>} title="Receita no Período" value={`R$ ${totalRevenue.toFixed(2).replace('.', ',')}`} subtext="Vendas de ingressos" />
                <SummaryCard icon={<UsersIcon className="w-6 h-6"/>} title="Divulgadores" value={totalPromoters} subtext="Total de divulgadores" />
                <SummaryCard icon={<PaperClipIcon className="w-6 h-6"/>} title="Links Enviados" value={totalLinks} subtext="Comprovações de tarefas" />
            </div>

            <div className="flex flex-col lg:flex-row gap-6 mb-8">
                 <div className="flex flex-row lg:flex-col gap-4">
                     <button onClick={onAddEvent} className="btn bg-[var(--color-accent-secondary)] text-slate-900 w-full text-base py-3"><CalendarPlusIcon className="w-5 h-5"/> Criar Evento</button>
                     <button onClick={onAddTask} className="btn bg-blue-600 text-white w-full text-base py-3"><PlusIcon className="w-5 h-5"/> Criar Tarefa</button>
                     <button onClick={handleAIAnalysis} className="btn bg-purple-600 text-white w-full text-base py-3"><SparklesIcon className="w-5 h-5"/> Analisar Resultados</button>
                 </div>
                 <div className="flex-grow grid grid-cols-1 md:grid-cols-2 gap-6">
                    <TaskProgressByEvent events={filteredData.events} tasks={filteredData.tasks} onViewEvent={onViewEvent} />
                    <PromoterRanking users={users} tasks={filteredData.tasks} onViewProfile={onViewProfile} />
                    <div className="md:col-span-2">
                        <SalesChart sales={filteredData.ticketSales} />
                    </div>
                 </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <RecentActivity tasks={filteredData.tasks} ticketSales={filteredData.ticketSales} users={users} />
            </div>
        </div>
    );
};

export default DashboardView;