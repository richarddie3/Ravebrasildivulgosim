import React from 'react';
import { RaveEvent, Ticket } from '../../types.ts';
import { CloseIcon, PlusIcon, EyeIcon, LocationIcon, TagIcon, CalendarPlusIcon } from '../Icons.tsx';

interface EventsDayModalProps {
  date: Date;
  events: RaveEvent[];
  onClose: () => void;
  onAddEvent: (date: Date) => void;
  onShowDetails: (event: RaveEvent) => void;
}

const getStartingPrice = (tickets: Ticket[]): string => {
    if (!tickets || tickets.length === 0) {
        return "Consulte";
    }
    const minPrice = Math.min(...tickets.map(t => t.price));
    return `A partir de R$ ${minPrice.toFixed(2).replace('.', ',')}`;
};

const EventsDayModal: React.FC<EventsDayModalProps> = ({ date, events, onClose, onAddEvent, onShowDetails }) => {
  const getMonthName = (monthIndex: number) => {
    const months = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];
    return months[monthIndex];
  };

  const title = `Eventos do dia ${date.getDate()} de ${getMonthName(date.getMonth())}`;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
        <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
          <h2 className="text-2xl font-bold font-poppins">{title}</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
            <CloseIcon className="w-7 h-7" />
          </button>
        </header>
        
        <div className="p-6 overflow-y-auto flex-grow">
          {events.length === 0 ? (
            <div className="text-center py-10">
                <CalendarPlusIcon className="w-16 h-16 mx-auto text-[var(--color-accent-primary)] mb-4" />
                <h3 className="text-xl font-semibold mb-2">Nenhum Evento Neste Dia</h3>
                <p className="text-[var(--color-text-secondary)]">Clique em "Adicionar Evento" para criar um novo.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {events.map(event => (
                <div key={event.id} className="bg-black/20 p-4 rounded-xl border border-[var(--color-border)] transition-all hover:border-[var(--color-accent-primary)] hover:shadow-lg flex items-start gap-4">
                  <img src={event.image || `https://picsum.photos/200/200?random=${event.id}`} alt={event.name} className="w-24 h-24 object-cover rounded-lg flex-shrink-0" />
                  <div className="flex-grow">
                    <h3 className="text-2xl font-bold text-[var(--color-accent-primary)] mb-1 text-shadow-glow">{event.name}</h3>
                    <div className="flex flex-col gap-1 text-sm text-[var(--color-text-secondary)] mb-3">
                      <span className="flex items-center gap-1.5"><LocationIcon className="w-4 h-4" /> {event.location}</span>
                      <span className="font-bold text-md text-green-400 flex items-center gap-1.5"><TagIcon className="w-4 h-4 text-[var(--color-accent-primary)]" /> {getStartingPrice(event.tickets)}</span>
                    </div>
                  </div>
                   <button onClick={() => onShowDetails(event)} className="bg-[var(--color-accent-secondary)] text-slate-900 font-bold py-2 px-4 rounded-lg flex items-center gap-2 text-sm hover:opacity-90 transition-colors self-end">
                    <EyeIcon className="w-5 h-5"/> Ver Detalhes
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <footer className="p-6 border-t border-[var(--color-border)]">
          <button onClick={() => onAddEvent(date)} className="w-full bg-[var(--color-accent-secondary)] text-slate-900 font-bold py-3 px-6 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-all">
            <PlusIcon className="w-6 h-6" />
            Adicionar Evento
          </button>
        </footer>
      </div>
    </div>
  );
};

export default EventsDayModal;