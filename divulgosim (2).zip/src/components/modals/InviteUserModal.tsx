import React, { useState, useMemo } from 'react';
import { RaveEvent, User, UserType } from '../../types.ts';
import { CloseIcon } from '../Icons.tsx';

interface InviteUserModalProps {
    event: RaveEvent;
    allUsers: User[];
    onClose: () => void;
    onInvite: (eventId: string, inviteeId: string, role: UserType) => void;
}

const InviteUserModal: React.FC<InviteUserModalProps> = ({ event, allUsers, onClose, onInvite }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedUser, setSelectedUser] = useState<User | null>(null);
    const [selectedRole, setSelectedRole] = useState<UserType | null>(null);
    
    const teamIds = useMemo(() => event.services.map(s => s.providerId), [event.services]);
    const filteredUsers = useMemo(() => {
        if (!searchTerm) return [];
        return allUsers.filter(user => 
            user.profile.personal.fullName.toLowerCase().includes(searchTerm.toLowerCase()) &&
            !teamIds.includes(user.id) // Exclude users already on the team
        );
    }, [searchTerm, allUsers, teamIds]);

    const handleInvite = () => {
        if (selectedUser && selectedRole) {
            onInvite(event.id, selectedUser.id, selectedRole);
            setSelectedUser(null);
            setSelectedRole(null);
            setSearchTerm('');
        } else {
            alert('Por favor, selecione um usuário e um papel.');
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">Convidar para: {event.name}</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>

                <div className="p-8 space-y-6 overflow-y-auto">
                    {selectedUser ? (
                        <div className="bg-black/20 p-4 rounded-lg">
                            <p>Convidando: <strong>{selectedUser.profile.personal.fullName}</strong></p>
                            <p className="text-sm text-[var(--color-text-secondary)]">{selectedUser.email}</p>
                            <button onClick={() => { setSelectedUser(null); setSearchTerm(''); }} className="text-xs text-[var(--color-accent-primary)] mt-2 hover:underline">Alterar usuário</button>
                        </div>
                    ) : (
                        <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="user-search">Buscar Usuário</label>
                            <input type="text" id="user-search" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} placeholder="Digite o nome..." className="form-control" />
                            {filteredUsers.length > 0 && (
                                <div className="mt-2 bg-black/20 rounded-lg max-h-40 overflow-y-auto">
                                    {filteredUsers.map(user => (
                                        <button key={user.id} onClick={() => setSelectedUser(user)} className="w-full text-left p-3 hover:bg-black/40">
                                            {user.profile.personal.fullName}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    )}
                    
                    {selectedUser && (
                         <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">Convidar como:</label>
                             <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                {Object.values(UserType).filter(r => r !== UserType.USER && r !== UserType.ORGANIZER).map((role) => ( // Filter out non-assignable roles
                                    <button
                                        type="button"
                                        key={role}
                                        onClick={() => setSelectedRole(role)}
                                        className={`p-3 rounded-lg text-center transition-all border-2 ${selectedRole === role ? 'bg-[var(--color-accent-primary)] border-[var(--color-accent-secondary)] text-slate-900 font-bold' : 'bg-black/20 border-[var(--color-border)] hover:bg-black/40'}`}
                                    >
                                        {role}
                                    </button>
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                <footer className="p-6 border-t border-[var(--color-border)] flex justify-end gap-3">
                    <button type="button" onClick={onClose} className="btn-cancel">Cancelar</button>
                    <button onClick={handleInvite} disabled={!selectedUser || !selectedRole} className="btn-save disabled:opacity-50 disabled:cursor-not-allowed">
                        Enviar Convite
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default InviteUserModal;