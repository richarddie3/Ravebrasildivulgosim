import React, { useState } from 'react';
import { Performance } from '../../types.ts';
import { CloseIcon, CheckCircleIcon } from '../Icons.tsx';

interface CreatePerformanceModalProps {
    onClose: () => void;
    onCreate: (performanceData: Omit<Performance, 'id' | 'userId' | 'createdAt'>) => void;
}

export const CreatePerformanceModal: React.FC<CreatePerformanceModalProps> = ({ onClose, onCreate }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [duration, setDuration] = useState(0);
    const [category, setCategory] = useState('');
    const [technicalNeeds, setTechnicalNeeds] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !description || !category || duration <= 0) {
            alert('Por favor, preencha todos os campos obrigatórios.');
            return;
        }
        onCreate({ name, description, duration, category, technicalNeeds });
    };

    const commonInputClass = "form-control";
    const commonLabelClass = "block text-sm font-medium text-[var(--color-text-secondary)] mb-2";

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-[var(--color-text-primary)]">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">Cadastrar Nova Performance</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                <form onSubmit={handleSubmit} className="p-8 space-y-4 overflow-y-auto">
                    <div>
                        <label className={commonLabelClass} htmlFor="perf-name">Nome da Performance</label>
                        <input type="text" id="perf-name" value={name} onChange={e => setName(e.target.value)} className={commonInputClass} required />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className={commonLabelClass} htmlFor="perf-category">Categoria</label>
                            <input type="text" id="perf-category" value={category} onChange={e => setCategory(e.target.value)} className={commonInputClass} placeholder="Ex: Dança, Pintura ao Vivo" required />
                        </div>
                        <div>
                            <label className={commonLabelClass} htmlFor="perf-duration">Duração (minutos)</label>
                            <input type="number" id="perf-duration" value={duration} onChange={e => setDuration(parseInt(e.target.value) || 0)} className={commonInputClass} required />
                        </div>
                    </div>
                    <div>
                        <label className={commonLabelClass} htmlFor="perf-desc">Descrição</label>
                        <textarea id="perf-desc" value={description} onChange={e => setDescription(e.target.value)} rows={3} className={commonInputClass} required></textarea>
                    </div>
                     <div>
                        <label className={commonLabelClass} htmlFor="perf-tech">Necessidades Técnicas</label>
                        <textarea id="perf-tech" value={technicalNeeds} onChange={e => setTechnicalNeeds(e.target.value)} rows={3} className={commonInputClass} placeholder="Ex: Espaço de 5x5m, ponto de energia 220v..."></textarea>
                    </div>
                     <footer className="pt-4 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="btn-cancel">Cancelar</button>
                        <button type="submit" className="btn-save">
                            <CheckCircleIcon className="w-5 h-5"/> Cadastrar
                        </button>
                    </footer>
                </form>
            </div>
        </div>
    );
};