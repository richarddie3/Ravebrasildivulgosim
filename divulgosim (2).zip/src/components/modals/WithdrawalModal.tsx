import React, { useState, useMemo } from 'react';
import { User } from '../../types.ts';
import { CloseIcon, WalletIcon } from '../Icons.tsx';

interface WithdrawalModalProps {
    currentUser: User;
    onClose: () => void;
    onRequestWithdrawal: (amountRB: number) => void;
}

const MIN_WITHDRAWAL = 500;
const WITHDRAWAL_FEE = 0.10; // 10%

const rbToCurrency = (rb: number) => (rb * 0.01);

const WithdrawalModal: React.FC<WithdrawalModalProps> = ({ currentUser, onClose, onRequestWithdrawal }) => {
    const userBalance = currentUser.rbBalance || 0;
    const [amountRB, setAmountRB] = useState(MIN_WITHDRAWAL);
    const [selectedMethod, setSelectedMethod] = useState<'pix' | 'paypal' | 'transfer'>('pix');

    const amountToReceive = useMemo(() => {
        const valueInReais = rbToCurrency(amountRB);
        return valueInReais * (1 - WITHDRAWAL_FEE);
    }, [amountRB]);

    const canWithdraw = userBalance >= amountRB && amountRB >= MIN_WITHDRAWAL;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (canWithdraw) {
            onRequestWithdrawal(amountRB);
        }
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-md max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins flex items-center gap-2">
                        <WalletIcon className="w-6 h-6 text-green-400" /> Solicitar Saque
                    </h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                <form onSubmit={handleSubmit} className="p-8 space-y-6">
                    <div className="text-center bg-black/20 p-4 rounded-lg">
                        <p className="text-sm text-[var(--color-text-secondary)]">Saldo Disponível para Saque</p>
                        <p className="text-3xl font-bold text-yellow-300">💎 {userBalance.toLocaleString('pt-BR')} RB</p>
                        <p className="text-sm text-white/70">→ R$ {rbToCurrency(userBalance).toFixed(2).replace('.', ',')}</p>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="amount">Valor do Saque (em RB)</label>
                        <input
                            type="number"
                            id="amount"
                            value={amountRB}
                            onChange={(e) => setAmountRB(parseInt(e.target.value) || 0)}
                            min={MIN_WITHDRAWAL}
                            max={userBalance}
                            step="10"
                            className="form-control"
                        />
                        <p className="text-xs text-[var(--color-text-secondary)] mt-1">Mínimo: {MIN_WITHDRAWAL} RB</p>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">Método de Saque</label>
                        <div className="grid grid-cols-3 gap-2">
                            {['pix', 'paypal', 'transfer'].map(method => (
                                <button type="button" key={method} onClick={() => setSelectedMethod(method as any)} className={`p-3 rounded-lg text-center uppercase font-bold text-sm border-2 transition-colors ${selectedMethod === method ? 'bg-green-500 border-green-400 text-white' : 'bg-black/20 border-[var(--color-border)] hover:bg-black/40'}`}>
                                    {method}
                                </button>
                            ))}
                        </div>
                     </div>
                     <div className="bg-black/20 p-3 rounded-lg text-sm text-center text-[var(--color-text-secondary)]">
                        <p>Taxa de saque: 10% aplicada.</p>
                        <p>Você receberá <strong className="text-green-400">R$ {amountToReceive.toFixed(2).replace('.', ',')}</strong> por {amountRB.toLocaleString('pt-BR')} RB.</p>
                     </div>
                    <p className="text-xs text-center text-yellow-400">⚠️ Primeiro saque? A transação pode levar até 24h para ser processada após a verificação de segurança.</p>
                    <button type="submit" disabled={!canWithdraw} className="w-full btn bg-green-600 hover:bg-green-500 text-white disabled:bg-gray-600 disabled:cursor-not-allowed">
                        Solicitar Saque
                    </button>
                </form>
            </div>
        </div>
    );
};

export default WithdrawalModal;