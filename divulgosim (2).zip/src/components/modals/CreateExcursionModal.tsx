import React, { useState, ChangeEvent, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Excursion, RaveEvent } from '../../types.ts';
import { CloseIcon, CloudUploadIcon, PlusIcon, TrashIcon, CheckCircleIcon } from '../Icons.tsx';

interface CreateExcursionModalProps {
    eventId?: string;
    allEvents?: RaveEvent[];
    onClose: () => void;
    onSave: (excursionData: Omit<Excursion, 'id' | 'tripOrganizerId' | 'isOfficial'> & { id?: string }) => void;
    excursionToEdit?: Excursion;
}

const CreateExcursionModal: React.FC<CreateExcursionModalProps> = ({ eventId, allEvents, onClose, onSave, excursionToEdit }) => {
    const [name, setName] = useState('');
    const [selectedEventId, setSelectedEventId] = useState(eventId || excursionToEdit?.eventId || '');
    const [meetingPoints, setMeetingPoints] = useState<string[]>(['']);
    const [departureTime, setDepartureTime] = useState('');
    const [returnTime, setReturnTime] = useState('');
    const [price, setPrice] = useState('');
    const [capacity, setCapacity] = useState(15);
    const [vehicleType, setVehicleType] = useState<'Ônibus' | 'Van' | 'Micro-ônibus' | 'Carro'>('Van');
    const [description, setDescription] = useState('');
    const [imageUrl, setImageUrl] = useState<string | null>(null);

    const isEditing = !!excursionToEdit;

    useEffect(() => {
        if (excursionToEdit) {
            setName(excursionToEdit.name);
            setSelectedEventId(excursionToEdit.eventId);
            setMeetingPoints(excursionToEdit.meetingPoints.length > 0 ? excursionToEdit.meetingPoints : ['']);
            setDepartureTime(excursionToEdit.departureTime);
            setReturnTime(excursionToEdit.returnTime);
            setPrice(String(excursionToEdit.price));
            setCapacity(excursionToEdit.capacity);
            setVehicleType(excursionToEdit.vehicleType);
            setDescription(excursionToEdit.description);
            setImageUrl(excursionToEdit.imageUrl || null);
        }
    }, [excursionToEdit]);

    const onDrop = useCallback((acceptedFiles: File[]) => {
        if (acceptedFiles && acceptedFiles[0]) {
            const file = acceptedFiles[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setImageUrl(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: { 'image/*': ['.jpeg', '.png', '.webp'] },
        multiple: false,
    });


    const handlePointChange = (index: number, value: string) => {
        const newPoints = [...meetingPoints];
        newPoints[index] = value;
        setMeetingPoints(newPoints);
    };

    const handleAddPoint = () => {
        if (meetingPoints.length < 5) {
            setMeetingPoints([...meetingPoints, '']);
        }
    };

    const handleRemovePoint = (index: number) => {
        if (meetingPoints.length > 1) {
            const newPoints = meetingPoints.filter((_, i) => i !== index);
            setMeetingPoints(newPoints);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const finalMeetingPoints = meetingPoints.filter(p => p.trim() !== '');
        if(!name || !selectedEventId || finalMeetingPoints.length === 0 || !departureTime || !returnTime) {
            alert('Por favor, preencha todos os campos obrigatórios (*).');
            return;
        }
        onSave({ 
            id: excursionToEdit?.id,
            eventId: selectedEventId, 
            name, 
            meetingPoints: finalMeetingPoints, 
            departureTime, 
            returnTime, 
            price: parseFloat(price) || 0, 
            capacity, 
            vehicleType, 
            description, 
            status: excursionToEdit?.status || 'ativo',
            imageUrl: imageUrl || undefined,
        });
    };

    const commonInputClass = "form-control";
    const commonLabelClass = "block text-sm font-bold text-[var(--color-text-secondary)] mb-1";

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl text-[var(--color-text-primary)] border border-[var(--color-border)]">
                <header className="flex justify-between items-center p-5 border-b border-[var(--color-border)]">
                    <h2 className="text-xl font-bold font-poppins">{isEditing ? 'Editar Excursão' : 'Adicionar Nova Excursão'}</h2>
                    <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Left Column */}
                        <div className="space-y-4">
                             <div>
                                <label className={commonLabelClass} htmlFor="exc-name">📌 Nome da Excursão <span className="text-red-500">*</span></label>
                                <input type="text" id="exc-name" value={name} onChange={e => setName(e.target.value)} className={commonInputClass} required />
                            </div>
                            <div>
                                <label className={commonLabelClass} htmlFor="exc-event">🏷️ Evento Relacionado <span className="text-red-500">*</span></label>
                                <select id="exc-event" value={selectedEventId} onChange={e => setSelectedEventId(e.target.value)} className={commonInputClass} required disabled={!!eventId || isEditing}>
                                    <option value="" disabled>Selecione um evento</option>
                                    {allEvents?.map(event => (<option key={event.id} value={event.id}>{event.name}</option>))}
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className={commonLabelClass} htmlFor="exc-departure">📅 Saída <span className="text-red-500">*</span></label>
                                    <input type="datetime-local" id="exc-departure" value={departureTime} onChange={e => setDepartureTime(e.target.value)} className={commonInputClass} required />
                                </div>
                                <div>
                                    <label className={commonLabelClass} htmlFor="exc-return">🕒 Retorno <span className="text-red-500">*</span></label>
                                    <input type="datetime-local" id="exc-return" value={returnTime} onChange={e => setReturnTime(e.target.value)} className={commonInputClass} required />
                                </div>
                             </div>
                        </div>
                        {/* Right Column */}
                        <div>
                             <label className={commonLabelClass}>🖼️ Imagem da Excursão</label>
                            <div {...getRootProps()} className={`relative p-4 h-full min-h-[150px] flex flex-col items-center justify-center border-2 border-dashed rounded-lg text-center cursor-pointer transition-colors ${isDragActive ? 'border-green-400 bg-green-500/10' : 'border-[var(--color-border)] hover:bg-black/20'}`}>
                                <input {...getInputProps()} />
                                {imageUrl ? (
                                    <>
                                        <img src={imageUrl} alt="Preview" className="absolute inset-0 w-full h-full object-cover rounded-lg"/>
                                        <div className="relative bg-black/50 text-white p-2 rounded-md">Alterar Imagem</div>
                                    </>
                                ) : (
                                    <>
                                        <CloudUploadIcon className="w-10 h-10 mx-auto text-[var(--color-text-secondary)] mb-1"/>
                                        <p className="font-semibold text-sm">Arraste uma imagem ou clique para selecionar</p>
                                    </>
                                )}
                            </div>
                        </div>
                     </div>
                     <div>
                        <label className={commonLabelClass}>📍 Pontos de Encontro <span className="text-red-500">*</span></label>
                        <div className="space-y-2">
                            {meetingPoints.map((point, index) => (
                                <div key={index} className="flex items-center gap-2">
                                    <input type="text" placeholder={`Ponto ${index + 1}`} value={point} onChange={(e) => handlePointChange(index, e.target.value)} className={commonInputClass} />
                                    <button type="button" onClick={() => handleRemovePoint(index)} className="p-2 text-[var(--color-text-secondary)] hover:text-[var(--color-danger)] hover:bg-red-500/10 rounded-md disabled:opacity-50" disabled={meetingPoints.length <= 1}>
                                        <TrashIcon className="w-5 h-5" />
                                    </button>
                                </div>
                            ))}
                        </div>
                        <button type="button" onClick={handleAddPoint} className="mt-2 text-sm font-semibold text-blue-400 hover:text-blue-300 flex items-center gap-1" disabled={meetingPoints.length >= 5}>
                            <PlusIcon className="w-4 h-4"/> Adicionar Ponto
                        </button>
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                         <div>
                            <label className={commonLabelClass} htmlFor="exc-price">💰 Preço (R$)</label>
                            <input type="number" id="exc-price" value={price} onChange={e => setPrice(e.target.value)} className={commonInputClass} placeholder="0.00" />
                        </div>
                         <div>
                            <label className={commonLabelClass} htmlFor="exc-capacity">🎫 Vagas</label>
                            <input type="number" id="exc-capacity" value={capacity} onChange={e => setCapacity(parseInt(e.target.value) || 0)} className={commonInputClass} />
                        </div>
                         <div>
                            <label className={commonLabelClass} htmlFor="exc-vehicle">🚗 Veículo</label>
                            <select id="exc-vehicle" value={vehicleType} onChange={e => setVehicleType(e.target.value as any)} className={commonInputClass}>
                                <option>Van</option>
                                <option>Ônibus</option>
                                <option>Micro-ônibus</option>
                                <option>Carro</option>
                            </select>
                        </div>
                     </div>
                      <div>
                        <label className={commonLabelClass} htmlFor="exc-desc">📝 Descrição Adicional</label>
                        <textarea id="exc-desc" value={description} onChange={e => setDescription(e.target.value)} rows={3} className={commonInputClass} placeholder="Ex: inclui cooler, som, brinde..."></textarea>
                    </div>
                     <footer className="pt-5 flex justify-end gap-3 border-t border-[var(--color-border)]">
                        <button type="button" onClick={onClose} className="btn-cancel">
                           <CloseIcon className="w-5 h-5"/> Cancelar
                        </button>
                        <button type="submit" className="btn-save">
                            <CheckCircleIcon className="w-5 h-5"/> {isEditing ? 'Salvar Alterações' : 'Criar Excursão'}
                        </button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default CreateExcursionModal;