import React from 'react';

// This component is not in use and its logic has been moved to the unified Dashboard.
const PromoterDashboard: React.FC = () => {
  return null;
};

export default PromoterDashboard;