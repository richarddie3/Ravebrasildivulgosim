import React, { useState, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { RaveEvent, Ticket, EventCategory } from '../../types.ts';
import { analyzeEvent } from '../../services/geminiService.ts';
import { CloseIcon, PlusIcon, TrashIcon, CheckCircleIcon, CloudUploadIcon, SparklesIcon, RobotIcon } from '../Icons.tsx';

interface EventModalProps {
  onClose: () => void;
  onSave: (event: Omit<RaveEvent, 'id' | 'organizerId' | 'comments' | 'gallery' | 'videos' | 'services'> & { id?: string }) => void;
  eventToEdit?: RaveEvent;
  selectedDate?: Date;
}

const getInitialEventData = (eventToEdit?: RaveEvent, selectedDate?: Date) => {
    if (eventToEdit) {
        return {
            name: eventToEdit.name,
            category: eventToEdit.category,
            dateString: eventToEdit.dateString,
            location: eventToEdit.location,
            description: eventToEdit.description,
            image: eventToEdit.image,
            commissionRate: eventToEdit.commissionRate,
            rbPool: eventToEdit.rbPool,
            dates: eventToEdit.dates
        };
    }
    const initialDate = selectedDate || new Date();
    return {
        name: '',
        category: EventCategory.RAVE,
        dateString: initialDate.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' }),
        location: '',
        description: '',
        image: null,
        commissionRate: 0.1,
        rbPool: 0,
        dates: [initialDate.toISOString().split('T')[0]]
    };
};

const EventModal: React.FC<EventModalProps> = ({ onClose, onSave, eventToEdit, selectedDate }) => {
    const [eventData, setEventData] = useState(() => getInitialEventData(eventToEdit, selectedDate));
    const [tickets, setTickets] = useState<Ticket[]>(() => 
        eventToEdit?.tickets || [{ id: `new_${Date.now()}`, name: 'Lote 1', price: 0, quantity: 100, sold: 0 }]
    );
    const [imageFile, setImageFile] = useState<File | null>(null);

    const [aiText, setAiText] = useState('');
    const [aiFlyer, setAiFlyer] = useState<File | null>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);

    const onImageDrop = useCallback((acceptedFiles: File[]) => {
        if (acceptedFiles && acceptedFiles[0]) {
            const file = acceptedFiles[0];
            setImageFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setEventData(prev => ({ ...prev, image: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    }, []);

    const { getRootProps: getImageRootProps, getInputProps: getImageInputProps } = useDropzone({ onDrop: onImageDrop, accept: {'image/*': []}, multiple: false });

    const onFlyerDrop = useCallback((acceptedFiles: File[]) => {
        if (acceptedFiles && acceptedFiles[0]) {
            setAiFlyer(acceptedFiles[0]);
        }
    }, []);
    
    const { getRootProps: getFlyerRootProps, getInputProps: getFlyerInputProps } = useDropzone({ onDrop: onFlyerDrop, accept: {'image/*': []}, multiple: false });

    const handleAnalyzeWithAI = async () => {
        if (!aiText && !aiFlyer) {
            alert('Forneça um texto ou uma imagem do flyer para análise.');
            return;
        }
        setIsAnalyzing(true);
        try {
            const result = await analyzeEvent(aiText, aiFlyer || undefined);
            const updatedEventData: Partial<RaveEvent> = {};
            if (result.name) updatedEventData.name = result.name;
            if (result.category) updatedEventData.category = result.category;
            if (result.dateString) updatedEventData.dateString = result.dateString;
            if (result.location) updatedEventData.location = result.location;
            if (result.description) updatedEventData.description = result.description;
            
            setEventData(prev => ({ ...prev, ...updatedEventData }));
            if (result.tickets && result.tickets.length > 0) {
                setTickets(result.tickets.map(t => ({...t, id: t.id || `ai_${Date.now()}_${Math.random()}`, sold: 0})));
            }
        } catch (error) {
            console.error(error);
            alert('Falha ao analisar os dados com a IA. Verifique o console para mais detalhes.');
        } finally {
            setIsAnalyzing(false);
        }
    };
    
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setEventData(prev => ({ ...prev, [name]: value }));
    };

    const handleTicketChange = (id: string, field: keyof Omit<Ticket, 'id'>, value: string | number) => {
        setTickets(prevTickets => prevTickets.map(ticket => 
            ticket.id === id ? { ...ticket, [field]: value } : ticket
        ));
    };

    const addTicket = () => {
        const newTicket: Ticket = {
            id: `new_${Date.now()}`,
            name: `Lote ${tickets.length + 1}`,
            price: 0,
            quantity: 100,
            sold: 0
        };
        setTickets([...tickets, newTicket]);
    };

    const removeTicket = (id: string) => {
        if (tickets.length > 1) {
            setTickets(tickets.filter(ticket => ticket.id !== id));
        }
    };


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const finalData = {
            ...eventData,
            tickets: tickets.map(({ id, ...rest }) => ({
                ...rest,
                id: id.startsWith('new_') ? `ticket_${Date.now()}_${Math.random()}` : id,
            })),
        };
        onSave({ id: eventToEdit?.id, ...finalData });
    };

    return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl text-white">
            <header className="flex-shrink-0 flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                <h2 className="text-2xl font-bold font-poppins">{eventToEdit ? 'Editar Evento' : 'Criar Novo Evento'}</h2>
                <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-white/10"><CloseIcon className="w-7 h-7" /></button>
            </header>
            <form onSubmit={handleSubmit} className="flex-grow overflow-y-auto p-6 space-y-6">
                 {/* AI Section */}
                <details className="bg-black/20 rounded-lg border border-[var(--color-border)]" open>
                    <summary className="p-3 cursor-pointer font-semibold flex items-center gap-2 text-[var(--color-accent-primary)]">
                        <SparklesIcon className="w-5 h-5"/> Preencher com IA
                    </summary>
                    <div className="p-4 border-t border-[var(--color-border)] space-y-4">
                        <textarea value={aiText} onChange={e => setAiText(e.target.value)} placeholder="Cole aqui as informações do evento ou a descrição do flyer..." rows={3} className="form-control" />
                        <div className="flex items-center gap-4">
                            <div {...getFlyerRootProps()} className="flex-grow p-4 border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/30">
                                <input {...getFlyerInputProps()} />
                                <p className="text-sm">{aiFlyer ? aiFlyer.name : 'Arraste ou clique para enviar o flyer'}</p>
                            </div>
                            <button type="button" onClick={handleAnalyzeWithAI} disabled={isAnalyzing} className="btn bg-purple-600 hover:bg-purple-500 disabled:bg-slate-500">
                                {isAnalyzing ? <RobotIcon className="w-5 h-5 animate-spin" /> : <SparklesIcon className="w-5 h-5" />}
                                {isAnalyzing ? 'Analisando...' : 'Analisar'}
                            </button>
                        </div>
                    </div>
                </details>
                
                {/* Main Form */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <div>
                            <label className="form-label">Nome do Evento</label>
                            <input type="text" name="name" value={eventData.name} onChange={handleChange} className="form-control" required/>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="form-label">Categoria</label>
                                <select name="category" value={eventData.category} onChange={handleChange} className="form-control">
                                    {Object.values(EventCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="form-label">Data (texto)</label>
                                <input type="text" name="dateString" value={eventData.dateString} onChange={handleChange} className="form-control" required/>
                            </div>
                        </div>
                        <div>
                            <label className="form-label">Localização</label>
                            <input type="text" name="location" value={eventData.location} onChange={handleChange} className="form-control" required/>
                        </div>
                        <div>
                            <label className="form-label">Descrição</label>
                            <textarea name="description" value={eventData.description} onChange={handleChange} rows={5} className="form-control" />
                        </div>
                    </div>
                    <div>
                        <label className="form-label">Imagem Principal</label>
                        <div {...getImageRootProps()} className="p-4 h-48 flex items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/20">
                            <input {...getImageInputProps()} />
                            {eventData.image ? <img src={eventData.image} alt="Preview" className="max-h-full max-w-full rounded-md"/> : <p>Arraste uma imagem ou clique</p>}
                        </div>
                    </div>
                </div>

                {/* Tickets Section */}
                <div>
                    <h3 className="text-lg font-semibold mb-2">Lotes de Ingressos</h3>
                    <div className="space-y-3">
                        {tickets.map((ticket) => (
                            <div key={ticket.id} className="grid grid-cols-10 gap-2 items-center">
                                <input type="text" placeholder="Nome do Lote" value={ticket.name} onChange={e => handleTicketChange(ticket.id, 'name', e.target.value)} className="form-control col-span-4" />
                                <input type="number" placeholder="Preço" value={ticket.price} onChange={e => handleTicketChange(ticket.id, 'price', parseFloat(e.target.value) || 0)} className="form-control col-span-2" />
                                <input type="number" placeholder="Qtd." value={ticket.quantity} onChange={e => handleTicketChange(ticket.id, 'quantity', parseInt(e.target.value) || 0)} className="form-control col-span-2" />
                                <input type="number" placeholder="Vend." value={ticket.sold} onChange={e => handleTicketChange(ticket.id, 'sold', parseInt(e.target.value) || 0)} className="form-control col-span-1" />
                                <button type="button" onClick={() => removeTicket(ticket.id)} className="p-2 text-red-400 hover:bg-red-400/10 rounded" disabled={tickets.length === 1}><TrashIcon className="w-5 h-5"/></button>
                            </div>
                        ))}
                    </div>
                    <button type="button" onClick={addTicket} className="mt-3 text-sm flex items-center gap-1 text-blue-400 hover:text-blue-300"><PlusIcon className="w-4 h-4"/> Adicionar Lote</button>
                </div>

                <footer className="flex-shrink-0 pt-4 flex justify-end gap-3 border-t border-[var(--color-border)]">
                    <button type="button" onClick={onClose} className="btn bg-black/20 text-white hover:bg-white/10">Cancelar</button>
                    <button type="submit" className="btn bg-[var(--color-accent-primary)] text-slate-900"><CheckCircleIcon className="w-5 h-5"/> Salvar Evento</button>
                </footer>
            </form>
        </div>
    </div>
  );
};

export default EventModal;