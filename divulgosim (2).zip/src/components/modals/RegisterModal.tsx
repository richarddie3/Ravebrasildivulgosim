import React, { useState } from 'react';
import { UserType } from '../../types.ts';
import { CloseIcon, UserIcon, MailIcon, LockClosedIcon } from '../Icons.tsx';

interface RegisterModalProps {
    onClose: () => void;
    onLoginClick: () => void;
    onRegisterSubmit: (data: {email: string, name: string, types: UserType[]}) => void;
    defaultType?: UserType;
}

const RegisterModal: React.FC<RegisterModalProps> = ({ onClose, onLoginClick, onRegisterSubmit, defaultType }) => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [userTypes, setUserTypes] = useState<UserType[]>(() => {
        const initialTypes = [UserType.USER];
        if (defaultType && !initialTypes.includes(defaultType)) {
            initialTypes.push(defaultType);
        }
        return initialTypes;
    });

    const handleTypeToggle = (type: UserType) => {
        if (type === UserType.USER) return; // Cannot deselect User

        setUserTypes(prev => 
            prev.includes(type)
            ? prev.filter(t => t !== type)
            : [...prev, type]
        );
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !email || !password || userTypes.length === 0) {
            alert("Por favor, preencha todos os campos e selecione pelo menos um tipo de conta.");
            return;
        }
        onRegisterSubmit({ email, name, types: userTypes });
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="relative bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <div className="absolute top-4 right-4 z-10">
                    <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </div>
                <div className="p-8 pt-12 overflow-y-auto">
                     <div className="flex justify-center mb-6">
                        <h1 className="text-5xl font-bold font-montserrat text-center text-[var(--color-accent-primary)]">Divulgosim</h1>
                    </div>
                    <h2 className="text-3xl font-bold font-poppins text-center mb-8">Cadastrar-se</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                         <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">Tipo de Conta</label>
                            <p className="text-xs text-[var(--color-text-secondary)] mb-3">'Usuário' é selecionado por padrão. Adicione outros perfis se desejar.</p>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                {Object.values(UserType).map((type) => (
                                    <button
                                        type="button"
                                        key={type}
                                        onClick={() => handleTypeToggle(type)}
                                        className={`p-3 rounded-lg text-center transition-all border-2 text-sm ${userTypes.includes(type) ? 'bg-[var(--color-accent-primary)] border-[var(--color-accent-secondary)] text-slate-900 font-bold' : 'bg-black/20 border-[var(--color-border)] hover:bg-black/40'} ${type === UserType.USER ? 'cursor-default opacity-80' : ''}`}
                                    >
                                        {type}
                                    </button>
                                ))}
                            </div>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="name">Nome</label>
                            <div className="relative">
                                <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                    <UserIcon className="h-5 w-5 text-gray-400" />
                                </span>
                                <input
                                    type="text"
                                    id="name"
                                    value={name}
                                    onChange={(e) => setName(e.target.value)}
                                    className="form-control pl-10"
                                    placeholder="Seu nome"
                                    required
                                />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="email">Email</label>
                            <div className="relative">
                                <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                    <MailIcon className="h-5 w-5 text-gray-400" />
                                </span>
                                <input
                                    type="email"
                                    id="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="form-control pl-10"
                                    placeholder="voce@exemplo.com"
                                    required
                                />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="password">Senha</label>
                             <div className="relative">
                                <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                    <LockClosedIcon className="h-5 w-5 text-gray-400" />
                                </span>
                                <input
                                    type="password"
                                    id="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="form-control pl-10"
                                    required
                                />
                            </div>
                        </div>
                        <button type="submit" className="w-full bg-[var(--color-accent-primary)] text-slate-900 font-semibold py-3 px-5 rounded-lg hover:bg-[var(--color-accent-secondary)] transition-colors shadow-md hover:shadow-lg">
                            Criar conta
                        </button>
                         <p className="text-center text-sm text-[var(--color-text-secondary)]">
                            Já tem uma conta?{' '}
                            <button type="button" onClick={onLoginClick} className="font-semibold text-[var(--color-accent-primary)] hover:text-[var(--color-accent-secondary)]">
                                Faça login
                            </button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default RegisterModal;