import React from 'react';
import { CloseIcon, LockClosedIcon } from '../Icons.tsx';

interface ChangePasswordModalProps {
    onClose: () => void;
}

export const ChangePasswordModal: React.FC<ChangePasswordModalProps> = ({ onClose }) => {
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-md max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins flex items-center gap-2">
                        <LockClosedIcon className="w-6 h-6 text-[var(--color-accent-primary)]" />
                        Alterar Senha
                    </h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                <div className="p-8 text-center">
                    <p className="text-[var(--color-text-secondary)]">Esta funcionalidade está em desenvolvimento.</p>
                </div>
            </div>
        </div>
    );
};