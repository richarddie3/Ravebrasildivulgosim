import React, { useState, ChangeEvent } from 'react';
import { Task, TaskMedia, SocialPlatform, Placement } from '../../types.ts';
import { CloseIcon, CheckCircleIcon, CloudUploadIcon, PaperClipIcon } from '../Icons.tsx';

interface TaskModalProps {
  onClose: () => void;
  onSave: (task: Omit<Task, 'id'>) => void;
  eventId: string;
}

const placementsByPlatform: Record<SocialPlatform, Placement[]> = {
    [SocialPlatform.INSTAGRAM]: [Placement.STORY, Placement.FEED, Placement.REELS],
    [SocialPlatform.FACEBOOK]: [Placement.STORY, Placement.POST, Placement.REELS],
    [SocialPlatform.TIKTOK]: [Placement.POST],
    [SocialPlatform.X]: [Placement.POST]
};

const TaskModal: React.FC<TaskModalProps> = ({ onClose, onSave, eventId }) => {
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [deadline, setDeadline] = useState('');
    const [media, setMedia] = useState<TaskMedia | null>(null);
    const [platform, setPlatform] = useState<SocialPlatform | ''>('');
    const [placement, setPlacement] = useState<Placement | ''>('');
    const [rewardRB, setRewardRB] = useState('');
    const [link, setLink] = useState('');

    const handlePlatformChange = (e: ChangeEvent<HTMLSelectElement>) => {
        const newPlatform = e.target.value as SocialPlatform;
        setPlatform(newPlatform);
        setPlacement(''); // Reset placement when platform changes
    };

    const handleMediaUpload = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            const reader = new FileReader();
            reader.onloadend = () => {
                setMedia({
                    url: reader.result as string,
                    type: file.type.startsWith('video') ? 'video' : 'image',
                    name: file.name
                });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || !deadline) {
            alert('Título e prazo são obrigatórios.');
            return;
        }
        const numericReward = parseInt(rewardRB);
        onSave({
            eventId,
            title,
            description,
            deadline,
            media: media || undefined,
            platform: platform || undefined,
            placement: placement || undefined,
            rewardRB: numericReward > 0 ? numericReward : undefined,
            link: link || undefined,
            status: 'pending', 
        });
    };
    
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">Adicionar Nova Tarefa</h2>
                    <button type="button" className="p-1 rounded-full hover:bg-white/10" onClick={onClose}><CloseIcon className="w-7 h-7" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div>
                        <label htmlFor="task-title" className="form-label">Título da Tarefa</label>
                        <input type="text" className="form-control" id="task-title" placeholder="Ex: Divulgar evento no Instagram" value={title} onChange={(e) => setTitle(e.target.value)} required />
                    </div>
                    <div>
                        <label htmlFor="task-desc" className="form-label">Descrição (para o Divulgador copiar)</label>
                        <textarea className="form-control" id="task-desc" rows={3} placeholder="Descreva o que deve ser feito" value={description} onChange={(e) => setDescription(e.target.value)}></textarea>
                    </div>

                    <div>
                        <label htmlFor="task-link" className="form-label">Link da Tarefa (Opcional)</label>
                        <div className="relative">
                             <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                <PaperClipIcon className="h-5 w-5 text-gray-400" />
                            </span>
                            <input type="url" className="form-control pl-10" id="task-link" placeholder="https://instagram.com/p/..." value={link} onChange={(e) => setLink(e.target.value)} />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="task-platform" className="form-label">Rede Social (Opcional)</label>
                            <select id="task-platform" value={platform} onChange={handlePlatformChange} className="form-control">
                                <option value="">Nenhuma</option>
                                {Object.values(SocialPlatform).map(p => <option key={p} value={p}>{p}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="task-placement" className="form-label">Formato (Opcional)</label>
                            <select id="task-placement" value={placement} onChange={e => setPlacement(e.target.value as Placement)} className="form-control" disabled={!platform}>
                                <option value="">Selecione...</option>
                                {platform && placementsByPlatform[platform].map(p => <option key={p} value={p}>{p}</option>)}
                            </select>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="form-label">Mídia da Tarefa (Opcional)</label>
                             <label htmlFor="task-media" className="w-full h-full p-4 flex flex-col items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg cursor-pointer hover:bg-black/20">
                                <CloudUploadIcon className="w-8 h-8 text-[var(--color-text-secondary)] mb-1" />
                                <span className="text-sm font-semibold">Enviar imagem/vídeo</span>
                            </label>
                            <input type="file" id="task-media" accept="image/*,video/*" className="hidden" onChange={handleMediaUpload} />
                        </div>
                         {media && (
                            <div className="text-center">
                                <p className="form-label text-left mb-2">Preview:</p>
                                {media.type === 'image' ? (
                                    <img src={media.url} alt="Preview" className="max-h-32 mx-auto rounded-lg" />
                                ) : (
                                    <video src={media.url} controls className="max-h-32 mx-auto rounded-lg" />
                                )}
                                <p className="text-xs mt-1 text-[var(--color-text-secondary)] truncate">{media.name}</p>
                            </div>
                        )}
                    </div>

                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="task-deadline" className="form-label">Prazo</label>
                            <input type="date" className="form-control" id="task-deadline" value={deadline} onChange={(e) => setDeadline(e.target.value)} required />
                        </div>
                         <div>
                            <label htmlFor="task-reward" className="form-label">Recompensa (RB 💎)</label>
                            <input type="number" className="form-control" id="task-reward" value={rewardRB} onChange={(e) => setRewardRB(e.target.value)} />
                        </div>
                    </div>

                    <footer className="pt-4 flex justify-end gap-3 border-t border-[var(--color-border)]">
                        <button type="button" className="btn-cancel" onClick={onClose}>Cancelar</button>
                        <button type="submit" className="btn-save"><CheckCircleIcon className="w-5 h-5"/> Salvar Tarefa</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default TaskModal;