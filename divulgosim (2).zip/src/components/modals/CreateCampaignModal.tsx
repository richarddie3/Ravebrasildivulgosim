import React, { useState } from 'react';
import { RaveEvent, Campaign } from '../../types.ts';
import { CloseIcon, CheckCircleIcon } from '../Icons.tsx';

interface CreateCampaignModalProps {
    event: RaveEvent;
    onClose: () => void;
    onCreate: (campaignData: Omit<Campaign, 'id' | 'organizerId' | 'status'>) => void;
}

export const CreateCampaignModal: React.FC<CreateCampaignModalProps> = ({ event, onClose, onCreate }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [payment, setPayment] = useState(0);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!name || !description) {
            alert('Nome e descrição são obrigatórios.');
            return;
        }
        onCreate({ eventId: event.id, name, description, payment });
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-[var(--color-text-primary)]">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">Criar Campanha para: {event.name}</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                <form onSubmit={handleSubmit} className="p-8 space-y-4 overflow-y-auto flex-grow flex flex-col">
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="campaign-name" className="form-label">Nome da Campanha</label>
                            <input id="campaign-name" type="text" value={name} onChange={e => setName(e.target.value)} className="form-control" placeholder="Ex: Divulgação no Instagram" required />
                        </div>
                        <div>
                            <label htmlFor="campaign-desc" className="form-label">Descrição</label>
                            <textarea id="campaign-desc" value={description} onChange={e => setDescription(e.target.value)} rows={4} className="form-control" placeholder="Descreva os objetivos e requisitos da campanha." required />
                        </div>
                        <div>
                            <label htmlFor="campaign-payment" className="form-label">Pagamento (R$)</label>
                            <input id="campaign-payment" type="number" value={payment} onChange={e => setPayment(Number(e.target.value))} className="form-control" />
                        </div>
                    </div>
                    <footer className="pt-6 mt-auto flex justify-end gap-3 border-t border-[var(--color-border)]">
                        <button type="button" onClick={onClose} className="btn-cancel">Cancelar</button>
                        <button type="submit" className="btn-save"><CheckCircleIcon className="w-5 h-5"/> Criar Campanha</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};