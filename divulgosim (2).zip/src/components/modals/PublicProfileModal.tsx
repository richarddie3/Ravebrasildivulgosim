import React, { useState, useRef, ChangeEvent, useMemo } from 'react';
import { User, UserType, RaveEvent, Photo, Video } from '../../types.ts';
// FIX: Corrected the import path for icons.
import { CloseIcon, UserIcon as UserIconDefault, PlusIcon, CameraIcon, VideoCameraIcon, ChevronLeftIcon, ChevronRightIcon, SaveIcon, UserPlusIcon, UserMinusIcon } from '../Icons.tsx';

interface PublicProfileModalProps {
  user: User;
  currentUser?: User | null;
  event?: RaveEvent;
  onAddPhotos?: (eventId: string, files: File[]) => void;
  onAddVideos?: (eventId: string, files: File[]) => void;
  onClose: () => void;
  onToggleFollow?: (userId: string) => void;
}

const PublicProfileModal: React.FC<PublicProfileModalProps> = ({ user, currentUser, event, onAddPhotos, onAddVideos, onClose, onToggleFollow }) => {
  const { personal, social } = user.profile;
  const isPhotographer = user.roles.includes(UserType.PHOTOGRAPHER);
  const isInfluencer = user.roles.includes(UserType.INFLUENCER);
  const isDj = user.roles.includes(UserType.DJ);
  const isArtist = user.roles.includes(UserType.ARTIST);

  const photoInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const isOwnProfile = currentUser?.id === user.id;

  const eventPhotos = event?.gallery.filter(p => p.userId === user.id) || [];
  const eventVideos = event?.videos?.filter(v => v.userId === user.id) || [];
  
  const mediaItems = useMemo(() => [
    ...eventPhotos.map(p => ({ type: 'photo', item: p as Photo | Video })),
    ...eventVideos.map(v => ({ type: 'video', item: v as Photo | Video }))
  ], [eventPhotos, eventVideos]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);

  const handleNext = () => {
    if (mediaItems.length === 0) return;
    setCurrentIndex(prev => (prev + 1) % mediaItems.length);
  };
  const handlePrev = () => {
    if (mediaItems.length === 0) return;
    setCurrentIndex(prev => (prev - 1 + mediaItems.length) % mediaItems.length);
  };
  
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
    touchEndX.current = e.targetTouches[0].clientX; // Reset on new touch
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };
  
  const handleTouchEnd = () => {
    if (touchStartX.current - touchEndX.current > 50) {
      handleNext();
    }

    if (touchStartX.current - touchEndX.current < -50) {
      handlePrev();
    }
  };

  const handleFileSelect = (e: ChangeEvent<HTMLInputElement>, type: 'photo' | 'video') => {
    if (e.target.files && event) {
        const files = Array.from(e.target.files);
        if (type === 'photo' && onAddPhotos) {
            onAddPhotos(event.id, files);
        } else if (type === 'video' && onAddVideos) {
            onAddVideos(event.id, files);
        }
    }
  };

  const isFollowing = currentUser?.following?.includes(user.id) ?? false;
  const followerCount = user.followers?.length || 0;
  const followingCount = user.following?.length || 0;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
        <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
          <h2 className="text-2xl font-bold font-poppins">Perfil Público</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
            <CloseIcon className="w-7 h-7" />
          </button>
        </header>

        <div className="p-8 overflow-y-auto flex-grow">
            <div className="text-center">
                <div className="w-32 h-32 rounded-full bg-black/20 border-4 border-[var(--color-border)] flex items-center justify-center overflow-hidden mx-auto mb-4">
                    {personal.profilePicture ? (
                        <img src={personal.profilePicture} alt={personal.fullName} className="w-full h-full object-cover" />
                    ) : (
                        <UserIconDefault className="w-20 h-20 text-white" />
                    )}
                </div>
                <h3 className="text-3xl font-bold text-[var(--color-accent-primary)] font-poppins">{personal.fullName}</h3>
                <p className="text-sm text-gray-400">@{personal.username}</p>
                <p className="text-[var(--color-text-secondary)] mt-2">{user.roles.join(' | ')}</p>

                <div className="mt-4 flex justify-center items-center gap-6 text-sm">
                    <div><strong className="text-white">{followerCount}</strong> <span className="text-gray-400">Seguidores</span></div>
                    <div><strong className="text-white">{followingCount}</strong> <span className="text-gray-400">Seguindo</span></div>
                </div>
            </div>
            
             {/* Event-specific gallery */}
            {isPhotographer && event && (
                <div className="mt-8">
                    <h4 className="text-xl font-bold text-[var(--color-accent-primary)] mb-4 text-center">Galeria Neste Evento: {event.name}</h4>
                    
                    {mediaItems.length > 0 ? (
                        <div 
                            className="relative bg-black/20 p-2 rounded-lg"
                            onTouchStart={handleTouchStart}
                            onTouchMove={handleTouchMove}
                            onTouchEnd={handleTouchEnd}
                        >
                            <div className="aspect-video w-full flex items-center justify-center overflow-hidden rounded-md bg-black relative group">
                                {mediaItems[currentIndex].type === 'photo' ? (
                                    <img src={mediaItems[currentIndex].item.url} alt={mediaItems[currentIndex].item.name} className="max-h-full max-w-full object-contain" />
                                ) : (
                                    <video src={mediaItems[currentIndex].item.url} className="max-h-full max-w-full" controls />
                                )}
                                <a
                                    href={mediaItems[currentIndex].item.url}
                                    download={mediaItems[currentIndex].item.name || 'download'}
                                    className="absolute top-2 right-2 btn bg-[var(--color-accent-secondary)] text-slate-900 !p-2 opacity-0 group-hover:opacity-100 transition-opacity z-20"
                                    title="Baixar Mídia"
                                >
                                    <SaveIcon className="w-5 h-5" />
                                </a>
                            </div>
                            
                            {mediaItems.length > 1 && (
                                <>
                                    <button onClick={handlePrev} className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full hover:bg-black/80 transition-colors z-10">
                                        <ChevronLeftIcon className="w-6 h-6" />
                                    </button>
                                    <button onClick={handleNext} className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full hover:bg-black/80 transition-colors z-10">
                                        <ChevronRightIcon className="w-6 h-6" />
                                    </button>
                                    <div className="absolute bottom-2 right-2 bg-black/50 text-xs px-2 py-1 rounded-md">
                                        {currentIndex + 1} / {mediaItems.length}
                                    </div>
                                </>
                            )}
                        </div>
                    ) : (
                         <div className="bg-black/20 p-3 rounded-lg min-h-[80px] text-center flex items-center justify-center">
                            <p className="text-sm text-[var(--color-text-secondary)]">Nenhuma mídia enviada para este evento.</p>
                        </div>
                    )}

                    {isOwnProfile && (onAddPhotos || onAddVideos) && (
                        <div className="flex justify-center gap-4 mt-4">
                            {onAddPhotos && (
                                <>
                                    <input type="file" multiple accept="image/*" ref={photoInputRef} className="hidden" onChange={(e) => handleFileSelect(e, 'photo')} />
                                    <button onClick={() => photoInputRef.current?.click()} className="btn bg-[var(--color-accent-secondary)] text-slate-900 !text-sm"><PlusIcon className="w-4 h-4" /> Adicionar Fotos</button>
                                </>
                            )}
                            {onAddVideos && (
                                <>
                                    <input type="file" multiple accept="video/*" ref={videoInputRef} className="hidden" onChange={(e) => handleFileSelect(e, 'video')} />
                                    <button onClick={() => videoInputRef.current?.click()} className="btn bg-[var(--color-accent-secondary)] text-slate-900 !text-sm"><PlusIcon className="w-4 h-4" /> Adicionar Vídeos</button>
                                </>
                            )}
                        </div>
                    )}
                </div>
            )}
            
            <div className="mt-8 text-left space-y-4">
                {social.instagram && (
                    <div className="bg-black/20 p-4 rounded-lg flex items-center gap-4">
                        <i className="fab fa-instagram text-2xl text-pink-400"></i>
                        <div>
                            <p className="font-semibold">Instagram</p>
                            <a href={social.instagram} target="_blank" rel="noopener noreferrer" className="text-sm text-[var(--color-accent-primary)] hover:underline break-all">
                                {social.instagram}
                            </a>
                        </div>
                    </div>
                )}
                 {social.website && (
                    <div className="bg-black/20 p-4 rounded-lg flex items-center gap-4">
                        <i className="fas fa-globe text-2xl text-blue-400"></i>
                        <div>
                            <p className="font-semibold">Website</p>
                            <a href={social.website} target="_blank" rel="noopener noreferrer" className="text-sm text-[var(--color-accent-primary)] hover:underline break-all">
                                {social.website}
                            </a>
                        </div>
                    </div>
                )}
            </div>
            
            {isPhotographer && user.portfolio && user.portfolio.length > 0 && (
                <div className="mt-8">
                    <h4 className="text-xl font-bold text-[var(--color-accent-primary)] mb-4 text-center">Portfólio Geral</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 bg-black/20 p-3 rounded-lg">
                        {user.portfolio.map(photo => (
                            <div key={photo.id} className="relative aspect-square rounded-md overflow-hidden group">
                                <img src={photo.url} alt={photo.name} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                                    <p className="text-xs text-white truncate">{photo.name}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
             {isInfluencer && user.posts && user.posts.length > 0 && (
                <div className="mt-8">
                    <h4 className="text-xl font-bold text-[var(--color-accent-primary)] mb-4 text-center">Postagens Recentes</h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 bg-black/20 p-3 rounded-lg">
                        {user.posts.filter(p => p.mediaType === 'image' && p.mediaUrl).map(post => (
                            <div key={post.id} className="relative aspect-square rounded-md overflow-hidden group">
                                <img src={post.mediaUrl} alt={post.caption} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                                    <p className="text-xs text-white line-clamp-2">{post.caption}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
            {isDj && user.tracks && user.tracks.length > 0 && (
                <div className="mt-8">
                    <h4 className="text-xl font-bold text-[var(--color-accent-primary)] mb-4 text-center">Músicas e Mixes</h4>
                    <div className="space-y-3 bg-black/20 p-3 rounded-lg">
                        {user.tracks.map(track => (
                            <div key={track.id} className="bg-black/20 p-3 rounded-md">
                                <p className="font-semibold">{track.title}</p>
                                {track.genre && <p className="text-xs text-[var(--color-text-secondary)]">{track.genre}</p>}
                                <audio controls src={track.url} className="w-full mt-2 h-10"></audio>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {isArtist && user.performances && user.performances.length > 0 && (
                <div className="mt-8">
                    <h4 className="text-xl font-bold text-[var(--color-accent-primary)] mb-4 text-center">Performances</h4>
                    <div className="space-y-3 bg-black/20 p-3 rounded-lg">
                        {user.performances.map(perf => (
                            <div key={perf.id} className="bg-black/20 p-3 rounded-md">
                                <p className="font-bold">{perf.name} <span className="text-xs text-[var(--color-text-secondary)] font-normal">({perf.category} - {perf.duration} min)</span></p>
                                <p className="text-sm text-white/90 mt-1">{perf.description}</p>
                                <p className="text-xs text-[var(--color-accent-primary)]/80 mt-2"><strong>Necessidades Técnicas:</strong> {perf.technicalNeeds}</p>
                            </div>
                        ))}
                    </div>
                </div>
            )}

        </div>

        <footer className="p-4 border-t border-[var(--color-border)] flex gap-3">
          <button onClick={onClose} className="w-full bg-black/20 text-white font-bold py-3 px-6 rounded-lg hover:bg-black/40 transition-colors">
            Fechar
          </button>
          {currentUser && !isOwnProfile && onToggleFollow && (
            isFollowing ? (
                <button onClick={() => onToggleFollow(user.id)} className="w-full btn-cancel flex items-center justify-center">
                    <UserMinusIcon className="w-5 h-5" /> Deixar de Seguir
                </button>
            ) : (
                <button onClick={() => onToggleFollow(user.id)} className="w-full btn-save flex items-center justify-center">
                    <UserPlusIcon className="w-5 h-5" /> Seguir
                </button>
            )
          )}
        </footer>
      </div>
    </div>
  );
};

export default PublicProfileModal;