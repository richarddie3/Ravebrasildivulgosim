import React from 'react';
// FIX: Correctly imported Cart from the types file.
import { Cart, CartItem } from '../../types.ts';
import { CloseIcon, TrashIcon, ShoppingCartIcon, CheckCircleIcon } from '../Icons.tsx';

interface CartModalProps {
    cart: Cart;
    onClose: () => void;
    onRemoveItem: (ticketId: string) => void;
    onCheckout: () => void;
}

export const CartModal: React.FC<CartModalProps> = ({ cart, onClose, onRemoveItem, onCheckout }) => {

    const hasItems = cart.items.length > 0;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins flex items-center gap-2">
                        <ShoppingCartIcon className="w-6 h-6 text-[var(--color-accent-primary)]" />
                        Meu Carrinho
                    </h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>

                <div className="p-6 overflow-y-auto flex-grow">
                    {hasItems ? (
                        <div className="space-y-4">
                            {cart.items.map(item => (
                                <div key={item.ticketId} className="bg-black/20 p-4 rounded-lg flex justify-between items-center border border-[var(--color-border)]">
                                    <div>
                                        <p className="font-bold">{item.ticketName}</p>
                                        <p className="text-sm text-slate-400">{item.eventName}</p>
                                        <p className="text-sm text-white/80">{item.quantity} x R$ {item.price.toFixed(2).replace('.', ',')}</p>
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <p className="font-bold text-lg text-green-400">R$ {(item.quantity * item.price).toFixed(2).replace('.', ',')}</p>
                                        <button onClick={() => onRemoveItem(item.ticketId)} className="p-2 text-red-400 hover:bg-red-500/10 rounded-full">
                                            <TrashIcon className="w-5 h-5" />
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 text-slate-400">
                            <ShoppingCartIcon className="w-16 h-16 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-white">Seu carrinho está vazio</h3>
                            <p>Adicione ingressos de eventos para vê-los aqui.</p>
                        </div>
                    )}
                </div>

                {hasItems && (
                    <footer className="p-6 border-t border-[var(--color-border)] space-y-4">
                        <div className="flex justify-between items-center text-xl font-bold">
                            <span>TOTAL:</span>
                            <span className="text-[var(--color-success)] text-2xl">R$ {cart.total.toFixed(2).replace('.', ',')}</span>
                        </div>
                        <button 
                            onClick={onCheckout}
                            className="w-full btn btn-save flex items-center justify-center gap-2 text-lg py-3"
                        >
                            <CheckCircleIcon className="w-6 h-6" /> Finalizar Compra
                        </button>
                    </footer>
                )}
            </div>
        </div>
    );
};
