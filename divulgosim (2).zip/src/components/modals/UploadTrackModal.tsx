import React, { useState, ChangeEvent, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Track } from '../../types.ts';
import { CloseIcon, CloudUploadIcon, CheckCircleIcon, TrashIcon, MusicIcon } from '../Icons.tsx';

interface UploadTrackModalProps {
    onClose: () => void;
    onSave: (trackData: Omit<Track, 'id' | 'userId' | 'createdAt'> & { id?: string }) => void;
    trackToEdit?: Track;
}

const UploadTrackModal: React.FC<UploadTrackModalProps> = ({ onClose, onSave, trackToEdit }) => {
    const [title, setTitle] = useState('');
    const [genre, setGenre] = useState('');
    const [description, setDescription] = useState('');
    const [audioFile, setAudioFile] = useState<File | null>(null);
    const [coverFile, setCoverFile] = useState<File | null>(null);
    const [coverPreview, setCoverPreview] = useState<string | null>(null);
    
    const [progress, setProgress] = useState(0);
    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        if (trackToEdit) {
            setTitle(trackToEdit.title);
            setGenre(trackToEdit.genre || '');
            setDescription(trackToEdit.description || '');
            setCoverPreview(trackToEdit.coverUrl || null);
            // Note: We don't pre-fill file inputs for security reasons. User must re-select.
        }
    }, [trackToEdit]);

    const onCoverDrop = useCallback((acceptedFiles: File[]) => {
        if (acceptedFiles && acceptedFiles[0]) {
            const file = acceptedFiles[0];
            setCoverFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setCoverPreview(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    }, []);

    const { getRootProps: getCoverRootProps, getInputProps: getCoverInputProps } = useDropzone({ onDrop: onCoverDrop, accept: {'image/*': []}, multiple: false });

    const handleAudioFileChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setAudioFile(e.target.files[0]);
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title || (!audioFile && !trackToEdit)) { // Audio file is required for new tracks
            alert('Título e arquivo de áudio são obrigatórios.');
            return;
        }

        setIsUploading(true);
        // Simulate upload progress
        const interval = setInterval(() => {
            setProgress(prev => {
                if (prev >= 100) {
                    clearInterval(interval);
                    
                    const saveData: Omit<Track, 'id' | 'userId' | 'createdAt'> & { id?: string } = {
                        id: trackToEdit?.id,
                        title,
                        genre,
                        description,
                        url: trackToEdit?.url || (audioFile ? URL.createObjectURL(audioFile) : ''), // Placeholder
                        coverUrl: coverPreview || undefined
                    };
                    onSave(saveData);

                    return 100;
                }
                return prev + 10;
            });
        }, 100);
    };

    const commonInputClass = "form-control";
    const commonLabelClass = "block text-sm font-medium text-[var(--color-text-secondary)] mb-1";

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div style={{ backgroundColor: '#1E293B' }} className="rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-700 text-white">
                <header className="flex justify-between items-center p-6 border-b border-slate-700">
                    <h2 className="text-2xl font-bold font-montserrat">{trackToEdit ? 'Editar Faixa' : 'Enviar Nova Faixa/Mix'}</h2>
                    <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                <form onSubmit={handleSubmit} className="p-8 space-y-4 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Left: Cover Art */}
                        <div>
                             <label className={commonLabelClass}>Capa (Opcional)</label>
                             {coverPreview ? (
                                <div className="relative">
                                    <img src={coverPreview} alt="Preview" className="w-full aspect-square object-cover rounded-lg"/>
                                    <button type="button" onClick={() => { setCoverFile(null); setCoverPreview(null); }} className="absolute top-2 right-2 bg-black/60 p-1.5 rounded-full hover:bg-red-500">
                                        <TrashIcon className="w-5 h-5"/>
                                    </button>
                                </div>
                             ) : (
                                <div {...getCoverRootProps()} className="aspect-square w-full p-8 flex flex-col items-center justify-center border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:bg-black/20">
                                    <input {...getCoverInputProps()} />
                                    <CloudUploadIcon className="w-10 h-10 text-slate-500 mb-2" />
                                    <span className="text-sm font-semibold text-center">Clique ou arraste a imagem da capa</span>
                                </div>
                             )}
                        </div>
                        {/* Right: Details */}
                        <div className="space-y-4">
                            <div>
                                <label className={commonLabelClass} htmlFor="track-title">Título *</label>
                                <input type="text" id="track-title" value={title} onChange={e => setTitle(e.target.value)} className={commonInputClass} required />
                            </div>
                            <div>
                                <label className={commonLabelClass} htmlFor="track-genre">Gênero</label>
                                <input type="text" id="track-genre" value={genre} onChange={e => setGenre(e.target.value)} className={commonInputClass} placeholder="Ex: Psytrance, Techno" />
                            </div>
                             <div>
                                <label className={commonLabelClass} htmlFor="track-description">Descrição</label>
                                <textarea id="track-description" value={description} onChange={e => setDescription(e.target.value)} rows={3} className={commonInputClass}></textarea>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label className={commonLabelClass}>Arquivo de Áudio *</label>
                        <label htmlFor="track-file" className="w-full p-4 flex items-center justify-center gap-3 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:bg-black/20">
                            <MusicIcon className="w-6 h-6 text-slate-400" />
                            <span className="text-sm font-semibold text-center">{audioFile ? audioFile.name : (trackToEdit ? 'Selecione para alterar o áudio' : 'Clique para selecionar o arquivo')}</span>
                        </label>
                        <input type="file" id="track-file" accept=".mp3,.wav,.flac" className="hidden" onChange={handleAudioFileChange} />
                        <p className="text-xs text-slate-500 mt-1">Formatos: .mp3, .wav, .flac (Max: 500MB)</p>
                    </div>

                     {isUploading && (
                         <div className="w-full bg-slate-700 rounded-full h-2.5 mt-2">
                            <div style={{ width: `${progress}%`, backgroundColor: '#FFD700' }} className="h-2.5 rounded-full transition-all duration-300"></div>
                        </div>
                    )}
                     <footer className="pt-4 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="btn-cancel">Cancelar</button>
                        <button type="submit" disabled={isUploading} style={{ backgroundColor: '#FFD700', color: '#1E293B' }} className="btn font-bold disabled:opacity-50">
                            <CheckCircleIcon className="w-5 h-5"/> {isUploading ? 'Enviando...' : (trackToEdit ? 'Salvar Alterações' : 'Enviar Faixa')}
                        </button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default UploadTrackModal;