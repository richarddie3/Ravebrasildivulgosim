import React, { useState } from 'react';
import { RaveEvent, Ticket, User, Task, UserType } from '../../types.ts';
import { CloseIcon, EyeIcon, LocationIcon, TagIcon, CalendarIcon, CalendarPlusIcon, HeartIcon, ClipboardIcon } from '../Icons.tsx';

interface AllEventsModalProps {
  events: RaveEvent[];
  currentUser: User | null;
  tasks: Task[];
  onClose: () => void;
  onShowDetails: (event: RaveEvent) => void;
  onToggleFollow: (eventId: string) => void;
}

const getStartingPrice = (tickets: Ticket[]): string => {
    if (!tickets || tickets.length === 0) {
        return "Consulte";
    }
    const minPrice = Math.min(...tickets.map(t => t.price));
    return `A partir de R$ ${minPrice.toFixed(2).replace('.', ',')}`;
};

const AllEventsModal: React.FC<AllEventsModalProps> = ({ events, currentUser, tasks, onClose, onShowDetails, onToggleFollow }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const EVENTS_PER_PAGE = 9;

  const sortedEvents = [...events].sort((a, b) => {
    const aIsFollowed = currentUser?.followingEvents?.includes(a.id) ?? false;
    const bIsFollowed = currentUser?.followingEvents?.includes(b.id) ?? false;

    if (aIsFollowed && !bIsFollowed) return -1;
    if (!aIsFollowed && bIsFollowed) return 1;

    // secondary sort by date
    return new Date(a.dates[0]).getTime() - new Date(b.dates[0]).getTime();
  });

  const totalPages = Math.ceil(sortedEvents.length / EVENTS_PER_PAGE);
  const paginatedEvents = sortedEvents.slice(
      (currentPage - 1) * EVENTS_PER_PAGE,
      currentPage * EVENTS_PER_PAGE
  );

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-6xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-[var(--color-text-primary)]">
        <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
          <h2 className="text-2xl font-bold font-poppins">Lista Completa de Eventos</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
            <CloseIcon className="w-7 h-7" />
          </button>
        </header>
        
        <div className="p-6 overflow-y-auto flex-grow">
          {sortedEvents.length === 0 ? (
            <div className="text-center py-10">
              <CalendarPlusIcon className="w-16 h-16 mx-auto text-[var(--color-accent-primary)] mb-4" />
              <h3 className="text-xl font-semibold mb-2">Nenhum Evento Cadastrado</h3>
              <p className="text-[var(--color-text-secondary)]">Adicione eventos para vê-los listados aqui.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginatedEvents.map(event => {
                  const isFollowed = currentUser?.followingEvents?.includes(event.id) ?? false;
                  const isPromoter = currentUser?.roles.includes(UserType.PROMOTER);
                  const taskCount = tasks.filter(t => t.eventId === event.id).length;
                  
                  return (
                      <button 
                        key={event.id} 
                        onClick={() => onShowDetails(event)}
                        className="relative bg-black/20 rounded-xl overflow-hidden border border-[var(--color-border)] transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 group aspect-[3/4] cursor-pointer"
                      >
                          <img src={event.image || `https://picsum.photos/800/600?random=${event.id}`} alt={event.name} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />

                          {isPromoter && taskCount > 0 && (
                            <span className="absolute top-3 left-3 z-10 text-xs font-bold px-2 py-1 rounded-full bg-blue-500 text-white backdrop-blur-sm bg-opacity-80 flex items-center gap-1">
                                <ClipboardIcon className="w-3 h-3" /> {taskCount} {taskCount > 1 ? 'Tarefas' : 'Tarefa'}
                            </span>
                          )}
                          {currentUser && (
                              <button
                                  onClick={(e) => { e.stopPropagation(); onToggleFollow(event.id); }}
                                  className={`absolute top-3 right-3 z-10 p-2 rounded-full transition-colors ${isFollowed ? 'text-pink-500 bg-black/50' : 'text-white bg-black/50 hover:text-pink-400'}`}
                                  aria-label={isFollowed ? 'Deixar de seguir' : 'Seguir evento'}
                              >
                                  <HeartIcon className="w-6 h-6" fill={isFollowed ? 'currentColor' : 'none'} />
                              </button>
                          )}

                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent"></div>
                          <div className="absolute bottom-0 left-0 right-0 p-4 text-white text-left">
                              <h3 className="text-xl font-bold text-[var(--color-accent-primary)] font-poppins mb-2 text-shadow-glow">{event.name}</h3>
                              
                              <div className="pt-2 mt-2 border-t border-yellow-400/20 max-h-0 opacity-0 group-hover:max-h-40 group-hover:opacity-100 transition-all duration-300 ease-in-out">
                                  <div className="space-y-1 text-sm text-gray-200">
                                      <p className="flex items-center gap-2"><CalendarIcon className="w-4 h-4 flex-shrink-0" /> {event.dateString}</p>
                                      <p className="flex items-center gap-2"><LocationIcon className="w-4 h-4 flex-shrink-0" /> {event.location}</p>
                                      <p className="font-bold text-md text-green-400 flex items-center gap-2"><TagIcon className="w-4 h-4 flex-shrink-0 text-[var(--color-accent-primary)]" /> {getStartingPrice(event.tickets)}</p>
                                  </div>
                              </div>
                          </div>
                      </button>
                  );
              })}
            </div>
          )}
        </div>
        {totalPages > 1 && (
            <footer className="p-4 border-t border-[var(--color-border)] flex items-center justify-center gap-4">
                <button 
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="bg-black/20 text-white font-bold py-2 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    Anterior
                </button>
                <span className="font-semibold">
                    Página {currentPage} de {totalPages}
                </span>
                <button
                     onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                     disabled={currentPage === totalPages}
                     className="bg-black/20 text-white font-bold py-2 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    Próximo
                </button>
            </footer>
        )}
      </div>
    </div>
  );
};

export default AllEventsModal;