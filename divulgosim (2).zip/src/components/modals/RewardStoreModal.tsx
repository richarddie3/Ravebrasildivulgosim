import React from 'react';
import { RewardStoreItem, User } from '../../types.ts';
import { CloseIcon, WalletIcon } from '../Icons.tsx';

interface RewardStoreModalProps {
    currentUser: User;
    items: RewardStoreItem[];
    onClose: () => void;
    onRedeem: (itemId: string) => void;
}

const rbToCurrency = (rb: number) => (rb * 0.01).toFixed(2).replace('.', ',');

const RewardStoreModal: React.FC<RewardStoreModalProps> = ({ currentUser, items, onClose, onRedeem }) => {
    const userBalance = currentUser.rbBalance || 0;

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">💎 Loja de Recompensas</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                
                <div className="p-6 overflow-y-auto flex-grow">
                    {items.length > 0 ? (
                        <div className="space-y-4">
                            {items.map(item => {
                                const canAfford = userBalance >= item.priceRB;
                                return (
                                    <div key={item.id} className="bg-black/20 p-4 rounded-lg flex justify-between items-center border border-[var(--color-border)]">
                                        <div className="flex items-center gap-4">
                                            <span className="text-3xl">{item.icon}</span>
                                            <div>
                                                <p className="font-bold">{item.name}</p>
                                                <p className="text-sm text-white/70">{item.description}</p>
                                            </div>
                                        </div>
                                        <div className="text-right">
                                            <p className="font-bold text-lg text-yellow-300">💎 {item.priceRB}</p>
                                            <button 
                                                onClick={() => onRedeem(item.id)} 
                                                disabled={!canAfford}
                                                className="mt-1 text-sm font-bold py-1 px-3 rounded-md bg-green-600 text-white hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed"
                                            >
                                                Resgatar
                                            </button>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        <p className="text-center text-white/70">A loja de recompensas está vazia no momento.</p>
                    )}
                </div>

                <footer className="p-4 border-t border-[var(--color-border)] flex items-center justify-end gap-3 bg-black/20">
                    <p className="text-sm font-semibold">Seu Saldo:</p>
                    <p className="font-bold text-xl text-yellow-300">💎 {userBalance.toLocaleString('pt-BR')}</p>
                </footer>
            </div>
        </div>
    );
};

export default RewardStoreModal;