import React, { useState, useMemo, useRef } from 'react';
import { RaveEvent, Service, ServiceType, Ticket, User, EventComment, UserType, Photo, EventCategory, Excursion, Passenger, Video, GigApplication, PerformanceApplication, CoverageRequest, AppView } from '../../types.ts';
import { CloseIcon, EditIcon, CalendarIcon, LocationIcon, TagIcon, InfoIcon, UserIcon as UserIconDefault, CameraIcon, BusIcon, MusicIcon, TheaterIcon, SaveIcon, VideoCameraIcon, ChevronLeftIcon, ChevronRightIcon, PlusIcon } from '../Icons.tsx';
import { CommentItem } from '../CommentItem.tsx';

const ServiceProviderMediaCarousel: React.FC<{ photos: Photo[], videos: Video[] }> = ({ photos, videos }) => {
    const mediaItems = useMemo(() => [
        ...photos.map(p => ({ type: 'photo', item: p as Photo | Video })),
        ...videos.map(v => ({ type: 'video', item: v as Photo | Video }))
    ], [photos, videos]);

    const [currentIndex, setCurrentIndex] = useState(0);
    const touchStartX = useRef(0);
    const touchEndX = useRef(0);

    const handleNext = () => {
        setCurrentIndex(prev => (prev + 1) % mediaItems.length);
    };
    const handlePrev = () => {
        setCurrentIndex(prev => (prev - 1 + mediaItems.length) % mediaItems.length);
    };
    
    const handleTouchStart = (e: React.TouchEvent) => {
        touchStartX.current = e.targetTouches[0].clientX;
        touchEndX.current = e.targetTouches[0].clientX;
    };
    const handleTouchMove = (e: React.TouchEvent) => {
        touchEndX.current = e.targetTouches[0].clientX;
    };
    const handleTouchEnd = () => {
        if (touchStartX.current - touchEndX.current > 50) handleNext();
        if (touchStartX.current - touchEndX.current < -50) handlePrev();
    };

    if (mediaItems.length === 0) return null;

    return (
        <div className="pl-16 mt-2">
            <div 
                className="relative bg-black/20 p-2 rounded-lg"
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
            >
                <div className="aspect-video w-full flex items-center justify-center overflow-hidden rounded-md bg-black relative group">
                    {mediaItems[currentIndex].type === 'photo' ? (
                        <img src={mediaItems[currentIndex].item.url} alt={mediaItems[currentIndex].item.name} className="max-h-full max-w-full object-contain" />
                    ) : (
                        <video src={mediaItems[currentIndex].item.url} className="max-h-full max-w-full" controls />
                    )}
                     <a
                        href={mediaItems[currentIndex].item.url}
                        download={mediaItems[currentIndex].item.name || 'download'}
                        className="absolute top-2 right-2 btn bg-[var(--color-accent-secondary)] text-slate-900 !p-2 opacity-0 group-hover:opacity-100 transition-opacity z-20"
                        title="Baixar Mídia"
                    >
                        <SaveIcon className="w-5 h-5" />
                    </a>
                </div>
                
                {mediaItems.length > 1 && (
                    <>
                        <button onClick={handlePrev} className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full hover:bg-black/80 transition-colors z-10">
                            <ChevronLeftIcon className="w-6 h-6" />
                        </button>
                        <button onClick={handleNext} className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full hover:bg-black/80 transition-colors z-10">
                            <ChevronRightIcon className="w-6 h-6" />
                        </button>
                        <div className="absolute bottom-4 right-4 bg-black/50 text-xs px-2 py-1 rounded-md">
                            {currentIndex + 1} / {mediaItems.length}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};


interface EventDetailModalProps {
  event: RaveEvent;
  currentUser: User | null;
  users: User[];
  officialExcursions: Excursion[];
  passengers: Passenger[];
  coverageRequests: CoverageRequest[];
  gigApplications: GigApplication[];
  performanceApplications: PerformanceApplication[];
  onClose: () => void;
  onManage: (event: RaveEvent) => void;
  onViewProfile: (user: User) => void;
  canManage: boolean;
  onPostComment: (eventId: string, text: string) => void;
  onUpdateComment: (eventId: string, commentId: string, text: string) => void;
  onDeleteComment: (eventId: string, commentId: string) => void;
  onRequestCoverage: (eventId: string) => void;
  onApplyToGig: (eventId: string) => void;
  onApplyForPerformance: (eventId: string) => void;
  onManageGallery: (event: RaveEvent) => void;
  onBookExcursionSlot: (excursionId: string) => void;
  onNavigateToContextualDashboard: (view: AppView) => void;
  onLoginOrRegister: () => void;
  onAddToCart: (event: RaveEvent, ticket: Ticket, quantity: number) => void;
}

const categoryStyles: { [key in EventCategory]: string } = {
    [EventCategory.FESTIVAL]: 'bg-purple-500 text-white',
    [EventCategory.RAVE]: 'bg-pink-500 text-white',
    [EventCategory.PVT]: 'bg-orange-500 text-white',
    [EventCategory.AFTER]: 'bg-cyan-500 text-white',
};


const EventDetailModal: React.FC<EventDetailModalProps> = ({ 
    event, 
    currentUser,
    users,
    officialExcursions,
    passengers,
    coverageRequests,
    gigApplications,
    performanceApplications,
    onClose, 
    onManage,
    onViewProfile,
    canManage,
    onPostComment,
    onUpdateComment,
    onDeleteComment,
    onRequestCoverage,
    onApplyToGig,
    onApplyForPerformance,
    onManageGallery,
    onBookExcursionSlot,
    onNavigateToContextualDashboard,
    onLoginOrRegister,
    onAddToCart,
}) => {
    const [newComment, setNewComment] = useState('');
    const [ticketQuantities, setTicketQuantities] = useState<{ [key: string]: number | undefined }>({});

    const userRoles = currentUser?.roles || [];
    
    const isPhotographerApproved = useMemo(() => {
        return event.services.some(s => s.providerId === currentUser?.id && s.type === ServiceType.PHOTOGRAPHER);
    }, [event.services, currentUser]);

    const hasRequestedCoverage = useMemo(() => {
        if (!currentUser || !userRoles.includes(UserType.PHOTOGRAPHER)) return false;
        return coverageRequests.some(req => req.eventId === event.id && req.photographerId === currentUser.id);
    }, [coverageRequests, event.id, currentUser, userRoles]);
    
    const hasAppliedToGig = useMemo(() => {
        if (!currentUser || !userRoles.includes(UserType.DJ)) return false;
        return gigApplications.some(app => app.eventId === event.id && app.djId === currentUser.id);
    }, [gigApplications, event.id, currentUser, userRoles]);

    const hasAppliedForPerformance = useMemo(() => {
        if (!currentUser || !userRoles.includes(UserType.ARTIST)) return false;
        return performanceApplications.some(app => app.eventId === event.id && app.artistId === currentUser.id);
    }, [performanceApplications, event.id, currentUser, userRoles]);

    const { groupedServices, organizerPhotos, organizerVideos } = useMemo(() => {
        const services = event.services.reduce((acc: Record<ServiceType, User[]>, service: Service) => {
            const provider = users.find(u => u.id === service.providerId);
            if (provider) {
                if (!acc[service.type]) {
                    acc[service.type] = [];
                }
                acc[service.type].push(provider);
            }
            return acc;
        }, {} as Record<ServiceType, User[]>);

        const serviceProviderIds = new Set(event.services.map(s => s.providerId));

        const photos = event.gallery.filter(p => !serviceProviderIds.has(p.userId));
        const videos = event.videos?.filter(v => !serviceProviderIds.has(v.userId)) || [];

        return { groupedServices: services, organizerPhotos: photos, organizerVideos: videos };
    }, [event.services, event.gallery, event.videos, users]);

    const photosByProvider = useMemo(() => {
        return event.gallery.reduce((acc, photo) => {
            if (photo.userId) { // Ensure userId exists
                if (!acc[photo.userId]) {
                    acc[photo.userId] = [];
                }
                acc[photo.userId].push(photo);
            }
            return acc;
        }, {} as Record<string, Photo[]>);
    }, [event.gallery]);

    const videosByProvider = useMemo(() => {
        return (event.videos || []).reduce((acc, video) => {
            if (video.userId) {
                if (!acc[video.userId]) {
                    acc[video.userId] = [];
                }
                acc[video.userId].push(video);
            }
            return acc;
        }, {} as Record<string, Video[]>);
    }, [event.videos]);

    const isFollowing = useMemo(() => 
        currentUser?.followingEvents?.includes(event.id), 
        [currentUser, event.id]
    );

    const formatDate = (dateStr: string) => {
        return new Date(dateStr).toLocaleDateString('pt-BR', {
            day: '2-digit', month: 'long', year: 'numeric', timeZone: 'UTC'
        });
    }

  const dateString = event.dates.length > 1
    ? `${formatDate(event.dates[0])} a ${formatDate(event.dates[event.dates.length - 1])}`
    : formatDate(event.dates[0]);

  const handleQuantityChange = (ticketId: string, value: string) => {
        if (value === '') {
            setTicketQuantities(prev => ({ ...prev, [ticketId]: undefined }));
            return;
        }
        const quantity = parseInt(value, 10);
        if (!isNaN(quantity)) {
            setTicketQuantities(prev => ({
                ...prev,
                [ticketId]: Math.max(1, quantity)
            }));
        }
  };
    
  const handleAddToCartClick = (ticket: Ticket) => {
    if (!currentUser) {
        onLoginOrRegister();
        return;
    }
    const quantity = ticketQuantities[ticket.id] || 1;
    onAddToCart(event, ticket, quantity);
  };

  const handlePostComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
        onPostComment(event.id, newComment);
        setNewComment('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
        <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
          <div>
            <h2 className="text-3xl font-bold font-poppins text-[var(--color-accent-primary)] text-shadow-glow">{event.name}</h2>
            <div className={`mt-2 inline-block text-sm font-bold px-3 py-1 rounded-full ${categoryStyles[event.category]}`}>
                {event.category}
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
            <CloseIcon className="w-7 h-7" />
          </button>
        </header>

        <div className="p-6 overflow-y-auto flex-grow space-y-6">
          {event.image && (
            <img src={event.image} alt={event.name} className="w-full h-64 object-cover rounded-lg shadow-lg" />
          )}
          
          <div className="bg-black/20 p-4 rounded-lg">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2 text-[var(--color-accent-primary)]"><CalendarIcon className="w-5 h-5" /> Data(s)</h3>
            <p className="pl-7">{dateString}</p>
          </div>
          
          <div className="bg-black/20 p-4 rounded-lg">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2 text-[var(--color-accent-primary)]"><LocationIcon className="w-5 h-5" /> Local</h3>
            <p className="pl-7">{event.location}</p>
          </div>
          
          <div className="bg-black/20 p-4 rounded-lg">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2 text-[var(--color-accent-primary)]"><TagIcon className="w-5 h-5" /> Ingressos</h3>
             <div className="space-y-2">
                {Array.isArray(event.tickets) && event.tickets.length > 0 ? (
                    (() => {
                        let activeLotFound = false;
                        return event.tickets.map((ticket: Ticket) => {
                            const sold = ticket.sold || 0;
                            const quantity = ticket.quantity; // Can be undefined
                            const isSoldOut = typeof quantity === 'number' && sold >= quantity;
                            let isLocked = false;
                            let isDisabled = false;
                            let buttonText = "Adicionar ao Carrinho";
                            let buttonClass = "bg-[var(--color-accent-secondary)] text-slate-900 font-bold py-2 px-4 rounded-lg text-sm hover:opacity-90 transition-colors flex items-center gap-2";

                            if (isSoldOut) {
                                isDisabled = true;
                                buttonText = "Esgotado";
                                buttonClass = "bg-slate-600 text-white/70 font-bold py-2 px-4 rounded-lg text-sm cursor-not-allowed";
                            } else if (activeLotFound && typeof quantity === 'number') {
                                isLocked = true;
                                isDisabled = true;
                                buttonText = "Em Breve";
                                buttonClass = "bg-slate-600 text-white/70 font-bold py-2 px-4 rounded-lg text-sm cursor-not-allowed";
                            } else if (!isSoldOut && (typeof quantity === 'number' || quantity === undefined)) {
                                if (typeof quantity === 'number' && !activeLotFound) {
                                    activeLotFound = true;
                                }
                            }

                            return (
                                <div key={ticket.id} className={`flex justify-between items-center bg-black/20 p-3 rounded-lg border border-slate-700/50 ${isDisabled ? 'opacity-60' : ''}`}>
                                    <div className="flex-grow">
                                        <span className="font-semibold text-lg">{ticket.name}</span>
                                        {typeof quantity === 'number' && <span className="text-xs text-slate-400 ml-2">({sold}/{quantity})</span>}
                                    </div>
                                    <div className="flex items-center gap-4">
                                        <span className="text-2xl font-bold text-[var(--color-success)] text-shadow-glow-green">R$ {ticket.price.toFixed(2).replace('.', ',')}</span>
                                        {!isDisabled && (
                                            <input
                                                type="number"
                                                min="1"
                                                value={ticketQuantities[ticket.id] || ''}
                                                onChange={(e) => handleQuantityChange(ticket.id, e.target.value)}
                                                placeholder="1"
                                                className="w-16 text-center bg-black/30 rounded-md border border-slate-600 outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)]"
                                                disabled={isDisabled}
                                                aria-label={`Quantidade para ${ticket.name}`}
                                            />
                                        )}
                                        <button 
                                            onClick={() => handleAddToCartClick(ticket)}
                                            className={buttonClass}
                                            disabled={isDisabled}
                                        >
                                            <PlusIcon className="w-4 h-4"/> {buttonText}
                                        </button>
                                    </div>
                                </div>
                            );
                        });
                    })()
                ) : (
                    <p className="pl-7">Valores não informados.</p>
                )}
            </div>
          </div>
          
          {officialExcursions.length > 0 && (
            <div className="bg-black/20 p-4 rounded-lg">
                <h3 className="font-semibold text-lg mb-3 flex items-center gap-2 text-[var(--color-accent-primary)]"><BusIcon className="w-5 h-5" /> Excursões Oficiais</h3>
                <div className="pl-7 space-y-4">
                    {officialExcursions.map(ex => {
                        const passengerCount = passengers.filter(p => p.excursionId === ex.id).length;
                        const spotsLeft = ex.capacity - passengerCount;
                        const isFull = spotsLeft <= 0;
                        return (
                            <div key={ex.id} className="bg-black/20 p-3 rounded-md">
                                <p className="font-bold">{ex.name} ({ex.vehicleType})</p>
                                <div className="text-sm text-white/80 mt-2">
                                    <p className="font-semibold">Pontos de Encontro:</p>
                                    <ul className="list-disc list-inside pl-2">
                                        {ex.meetingPoints.map((point, index) => (
                                            <li key={index}>{point}</li>
                                        ))}
                                    </ul>
                                </div>
                                <div className="flex justify-between items-center mt-2">
                                    <div>
                                        <p className="font-semibold text-green-400">R$ {ex.price.toFixed(2)}</p>
                                        <p className={`text-xs ${isFull ? 'text-red-400' : 'text-yellow-300'}`}>
                                            {isFull ? 'Lotado' : `${spotsLeft} vagas restantes`}
                                        </p>
                                    </div>
                                    <button 
                                        onClick={() => onBookExcursionSlot(ex.id)}
                                        disabled={isFull}
                                        className="bg-teal-500 text-white font-bold py-1 px-3 rounded-md text-sm hover:bg-teal-400 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed">
                                        Reservar Vaga
                                    </button>
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
          )}

           <div className="bg-black/20 p-4 rounded-lg">
              <h3 className="font-semibold text-lg text-[var(--color-accent-primary)] mb-4">Serviços & Mídia do Evento</h3>
              <div className="space-y-6">
                {Object.keys(groupedServices).length > 0 ? (
                    Object.entries(groupedServices).map(([type, providers]: [string, User[]]) => (
                        <div key={type}>
                            <h4 className="font-bold text-md mb-3">{type}</h4>
                             {providers.map(provider => {
                                const providerPhotos = photosByProvider[provider.id] || [];
                                const providerVideos = videosByProvider[provider.id] || [];
                                return (
                                    <div key={provider.id} className="mb-4">
                                        <button onClick={() => onViewProfile(provider)} className="flex items-center gap-3 group mb-2">
                                             <div className="w-12 h-12 rounded-full bg-black/20 border-2 border-transparent group-hover:border-[var(--color-accent-primary)] transition-colors flex items-center justify-center overflow-hidden">
                                               {provider.profile.personal.profilePicture ? (
                                                    <img src={provider.profile.personal.profilePicture} alt={provider.profile.personal.fullName} className="w-full h-full object-cover" />
                                                ) : (
                                                    <UserIconDefault className="w-8 h-8 text-white" />
                                                )}
                                            </div>
                                            <span className="font-semibold text-white/90 group-hover:text-[var(--color-accent-primary)] transition-colors break-words">{provider.profile.personal.fullName}</span>
                                        </button>
                                        
                                        <ServiceProviderMediaCarousel photos={providerPhotos} videos={providerVideos} />
                                    </div>
                                );
                            })}
                        </div>
                    ))
                ) : <p className="text-white/70">Nenhum serviço contratado para este evento.</p>}

                {(organizerPhotos.length > 0 || (organizerVideos && organizerVideos.length > 0)) && (
                    <div className="mt-6 pt-6 border-t border-[var(--color-border)]">
                         <h4 className="font-bold text-md mb-3">Galeria do Organizador</h4>
                         {organizerPhotos.length > 0 && (
                            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2">
                                {organizerPhotos.map(photo => (
                                    <div key={photo.id} className="aspect-square bg-black/20 rounded-md overflow-hidden group relative">
                                        <img src={photo.url} alt={photo.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <a href={photo.url} download={photo.name || 'download'} className="btn bg-[var(--color-accent-secondary)] text-slate-900 !text-xs !py-1 !px-2"><SaveIcon className="w-4 h-4" /> Baixar</a>
                                        </div>
                                    </div>
                                ))}
                            </div>
                         )}
                         {organizerVideos && organizerVideos.length > 0 && (
                             <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2 mt-2">
                                {organizerVideos.map((video) => (
                                    <div key={video.id} className="aspect-video bg-black/20 rounded-md overflow-hidden group relative">
                                        <video src={video.url} className="w-full h-full object-cover" />
                                        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <a href={video.url} download={video.name || 'download'} className="btn bg-[var(--color-accent-secondary)] text-slate-900 !text-xs !py-1 !px-2"><SaveIcon className="w-4 h-4" /> Baixar</a>
                                        </div>
                                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-100 group-hover:opacity-0 transition-opacity">
                                            <VideoCameraIcon className="w-8 h-8 text-white/50" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                         )}
                    </div>
                )}
              </div>
            </div>

          <div className="bg-black/20 p-4 rounded-lg">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2 text-[var(--color-accent-primary)]"><InfoIcon className="w-5 h-5" /> Descrição</h3>
            <p className="pl-7 whitespace-pre-wrap">{event.description}</p>
          </div>
          
          {/* Comments Section */}
          <div className="bg-black/20 p-4 rounded-lg">
             <h3 className="font-semibold text-lg mb-4 text-[var(--color-accent-primary)]">Comentários ({event.comments.length})</h3>
             <div className="space-y-4 max-h-60 overflow-y-auto pr-2">
                {event.comments.map(comment => (
                    <CommentItem 
                        key={comment.id}
                        comment={comment}
                        currentUser={currentUser}
                        canManageEvent={canManage}
                        onUpdate={(commentId, text) => onUpdateComment(event.id, commentId, text)}
                        onDelete={(commentId) => onDeleteComment(event.id, commentId)}
                    />
                ))}
             </div>
              {currentUser && isFollowing && (
                <form onSubmit={handlePostComment} className="mt-4 pt-4 border-t border-[var(--color-border)] flex items-start gap-3">
                     <div className="w-10 h-10 rounded-full bg-black/20 flex-shrink-0 flex items-center justify-center overflow-hidden">
                         {currentUser.profile.personal.profilePicture ? (
                            <img src={currentUser.profile.personal.profilePicture} alt={currentUser.profile.personal.fullName} className="w-full h-full object-cover"/>
                         ) : (
                            <UserIconDefault className="w-6 h-6 text-white"/>
                         )}
                    </div>
                    <textarea 
                        value={newComment}
                        onChange={(e) => setNewComment(e.target.value)}
                        placeholder="Adicione um comentário..."
                        className="w-full bg-white/5 rounded-md p-2 text-sm border border-white/20 focus:ring-1 focus:ring-[var(--color-accent-primary)] outline-none transition-colors"
                        rows={2}
                    ></textarea>
                     <button type="submit" className="btn bg-[var(--color-accent-secondary)] text-slate-900 !py-2 !px-4">Enviar</button>
                </form>
              )}
              {currentUser && !isFollowing && (
                <div className="mt-4 pt-4 border-t border-[var(--color-border)] text-center text-sm text-[var(--color-text-secondary)]">
                    Você precisa seguir o evento para poder comentar.
                </div>
              )}
          </div>
        </div>

        <footer className="p-4 border-t border-[var(--color-border)] flex flex-wrap justify-end gap-3">
            {canManage && (
                <button onClick={() => onManage(event)} className="btn bg-blue-600 text-white font-bold">
                    <EditIcon className="w-5 h-5"/> Gerenciar Evento
                </button>
            )}
            {userRoles.length === 1 && userRoles[0] === UserType.USER && (
                <button onClick={() => onNavigateToContextualDashboard('profile')} className="btn bg-gray-600 text-white">
                    Meus Ingressos
                </button>
            )}
            {userRoles.includes(UserType.ORGANIZER) && !canManage && (
                <button onClick={() => onNavigateToContextualDashboard('mainDashboard')} className="btn bg-blue-500 text-white font-bold">
                    Painel de Organizador
                </button>
            )}
            {userRoles.includes(UserType.INFLUENCER) && <button onClick={() => onNavigateToContextualDashboard('influencerDashboard')} className="btn bg-yellow-500 text-slate-900 font-bold">Divulgar Evento</button>}
            {userRoles.includes(UserType.PROMOTER) && <button onClick={() => onNavigateToContextualDashboard('influencerDashboard')} className="btn bg-yellow-500 text-slate-900 font-bold">Divulgar Evento</button>}
            {userRoles.includes(UserType.DJ) && <button onClick={() => onNavigateToContextualDashboard('djDashboard')} className="btn bg-purple-500 text-white font-bold">Painel de DJ</button>}
            {userRoles.includes(UserType.STORE_OWNER) && <button onClick={() => onNavigateToContextualDashboard('storeDashboard')} className="btn bg-green-500 text-white font-bold">Vender Produtos</button>}
            {userRoles.includes(UserType.TRIP_ORGANIZER) && <button onClick={() => onNavigateToContextualDashboard('excursions')} className="btn bg-cyan-500 text-white font-bold">Gerenciar Excursão</button>}
            {userRoles.includes(UserType.PHOTOGRAPHER) && (
                isPhotographerApproved ? (
                <button onClick={() => onNavigateToContextualDashboard('photographerDashboard')} className="btn bg-teal-500 text-white font-bold">Painel de Fotógrafo</button>
                ) : (
                <button onClick={() => onRequestCoverage(event.id)} disabled={hasRequestedCoverage} className="btn bg-teal-600 text-white font-bold disabled:bg-slate-500 disabled:cursor-not-allowed">
                    {hasRequestedCoverage ? 'Solicitado' : 'Solicitar Cobertura'}
                </button>
                )
            )}
            {userRoles.includes(UserType.ARTIST) && <button onClick={() => onNavigateToContextualDashboard('artistDashboard')} className="btn bg-rose-500 text-white font-bold">Painel de Artista</button>}
            {userRoles.includes(UserType.SOUND_LIGHTING) && <button onClick={() => onNavigateToContextualDashboard('soundLightingDashboard')} className="btn bg-indigo-500 text-white font-bold">Som & Luz</button>}
            {userRoles.includes(UserType.DECORATION) && <button onClick={() => onNavigateToContextualDashboard('decorationDashboard')} className="btn bg-pink-500 text-white font-bold">Decoração</button>}
        </footer>
      </div>
    </div>
  );
};

export default EventDetailModal;