import React from 'react';
// FIX: Added PaymentDetails to types.ts and imported it here.
import { PaymentDetails } from '../../types.ts';
import { CloseIcon, CheckCircleIcon, WalletIcon } from '../Icons.tsx';

interface PaymentModalProps {
    details: PaymentDetails;
    onClose: () => void;
    onConfirmPayment: (payload: any) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({ details, onClose, onConfirmPayment }) => {
    const total = details.items.reduce((sum, item) => sum + (item.unit_price * item.quantity), 0);

    const handleSubmit = () => {
        onConfirmPayment(details.payload);
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins flex items-center gap-2">
                        <WalletIcon className="w-6 h-6 text-[var(--color-accent-primary)]" />
                        Confirmar Compra
                    </h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>

                <div className="p-8 space-y-6 overflow-y-auto">
                    <p className="text-sm text-center text-slate-400">Revise os itens do seu pedido antes de confirmar.</p>
                    
                    <div className="bg-black/20 p-4 rounded-lg border border-[var(--color-border)] space-y-3">
                        {details.items.map((item, index) => (
                            <div key={index} className="flex justify-between items-center">
                                <div>
                                    <p className="font-semibold">{item.title}</p>
                                    <p className="text-sm text-slate-400">{item.quantity} x R$ {item.unit_price.toFixed(2).replace('.', ',')}</p>
                                </div>
                                <p className="font-bold">R$ {(item.quantity * item.unit_price).toFixed(2).replace('.', ',')}</p>
                            </div>
                        ))}
                    </div>

                    <div className="flex justify-between items-center text-xl font-bold pt-4 border-t border-[var(--color-border)]">
                        <span>TOTAL:</span>
                        <span className="text-[var(--color-success)] text-2xl">R$ {total.toFixed(2).replace('.', ',')}</span>
                    </div>

                    <div className="bg-blue-900/50 text-blue-200 text-sm p-3 rounded-lg text-center">
                        Esta é uma simulação. Nenhum pagamento real será processado.
                    </div>
                </div>

                <footer className="p-6 border-t border-[var(--color-border)]">
                    <button 
                        onClick={handleSubmit}
                        className="w-full btn btn-save flex items-center justify-center gap-2 text-lg py-3"
                    >
                        <CheckCircleIcon className="w-6 h-6" /> Confirmar Compra (Simulação)
                    </button>
                </footer>
            </div>
        </div>
    );
};