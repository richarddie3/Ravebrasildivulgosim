import React, { useState, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { DecorationProject } from '../../types.ts';
import { CloseIcon, CloudUploadIcon, CheckCircleIcon, TrashIcon, PlusIcon, VideoCameraIcon } from '../Icons.tsx';

interface DecorationProjectModalProps {
    onClose: () => void;
    onSave: (projectData: Omit<DecorationProject, 'id' | 'userId'> & { id?: string }) => void;
    projectToEdit?: DecorationProject;
}

const DecorationProjectModal: React.FC<DecorationProjectModalProps> = ({ onClose, onSave, projectToEdit }) => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [coverImage, setCoverImage] = useState<string | null>(null);
    const [galleryImages, setGalleryImages] = useState<string[]>([]);
    const [videos, setVideos] = useState<string[]>([]);
    
    const isEditing = !!projectToEdit;

    useEffect(() => {
        if (projectToEdit) {
            setName(projectToEdit.name);
            setDescription(projectToEdit.description);
            setCoverImage(projectToEdit.coverImage);
            setGalleryImages(projectToEdit.images);
            setVideos(projectToEdit.videos || []);
        }
    }, [projectToEdit]);

    const handleFileDrop = useCallback((acceptedFiles: File[], target: 'cover' | 'gallery' | 'video') => {
        acceptedFiles.forEach(file => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                if (target === 'cover') {
                    setCoverImage(result);
                } else if (target === 'gallery') {
                    setGalleryImages(prev => [...prev, result]);
                } else {
                    setVideos(prev => [...prev, result]);
                }
            };
            reader.readAsDataURL(file);
        });
    }, []);

    const { getRootProps: getCoverRootProps, getInputProps: getCoverInputProps } = useDropzone({
        onDrop: files => handleFileDrop(files, 'cover'),
        accept: { 'image/*': [] },
        multiple: false,
    });
     const { getRootProps: getGalleryRootProps, getInputProps: getGalleryInputProps } = useDropzone({
        onDrop: files => handleFileDrop(files, 'gallery'),
        accept: { 'image/*': [] },
        multiple: true,
    });
     const { getRootProps: getVideoRootProps, getInputProps: getVideoInputProps } = useDropzone({
        onDrop: files => handleFileDrop(files, 'video'),
        accept: { 'video/*': [] },
        multiple: true,
    });
    
    const handleRemoveGalleryImage = (index: number) => setGalleryImages(prev => prev.filter((_, i) => i !== index));
    const handleRemoveVideo = (index: number) => setVideos(prev => prev.filter((_, i) => i !== index));

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || !coverImage) {
            alert('Nome e imagem de capa são obrigatórios.');
            return;
        }
        onSave({
            id: projectToEdit?.id,
            name,
            description,
            coverImage,
            images: galleryImages,
            videos,
        });
    };

    const commonLabelClass = "block text-sm font-bold text-[var(--color-text-secondary)] mb-1";

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">{isEditing ? 'Editar Projeto de Decoração' : 'Novo Projeto de Decoração'}</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10"><CloseIcon className="w-7 h-7" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 flex-grow overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div>
                                <label className={commonLabelClass}>Nome do Projeto</label>
                                <input type="text" value={name} onChange={e => setName(e.target.value)} className="form-control" required />
                            </div>
                            <div>
                                <label className={commonLabelClass}>Descrição</label>
                                <textarea value={description} onChange={e => setDescription(e.target.value)} rows={4} className="form-control" required />
                            </div>
                        </div>
                         <div>
                            <label className={commonLabelClass}>Imagem de Capa</label>
                            <div {...getCoverRootProps()} className="p-4 h-48 flex items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/20">
                                <input {...getCoverInputProps()} />
                                {coverImage ? (
                                    <img src={coverImage} alt="Cover preview" className="max-h-full max-w-full rounded-md" />
                                ) : (
                                    <p>Arraste a imagem de capa ou clique para selecionar</p>
                                )}
                            </div>
                        </div>
                    </div>
                     <div className="mt-6">
                        <label className={commonLabelClass}>🖼️ Galeria de Imagens</label>
                        <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                            {galleryImages.map((img, index) => (
                                <div key={index} className="relative group aspect-square">
                                    <img src={img} alt={`Gallery item ${index}`} className="w-full h-full object-cover rounded-md"/>
                                    <button type="button" onClick={() => handleRemoveGalleryImage(index)} className="absolute top-1 right-1 bg-red-600/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4" /></button>
                                </div>
                            ))}
                            <div {...getGalleryRootProps()} className="aspect-square flex items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/20">
                                <input {...getGalleryInputProps()} />
                                <div className="text-center"><PlusIcon className="w-6 h-6 mx-auto text-[var(--color-text-secondary)]"/><p className="text-xs mt-1">Adicionar</p></div>
                            </div>
                        </div>
                    </div>
                     <div className="mt-6">
                        <label className={commonLabelClass}>🎬 Galeria de Vídeos</label>
                        <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                            {videos.map((vid, index) => (
                                <div key={index} className="relative group aspect-square">
                                    <video src={vid} className="w-full h-full object-cover rounded-md bg-black"/>
                                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none"><VideoCameraIcon className="w-8 h-8 text-white/50 opacity-50 group-hover:opacity-0"/></div>
                                    <button type="button" onClick={() => handleRemoveVideo(index)} className="absolute top-1 right-1 bg-red-600/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4" /></button>
                                </div>
                            ))}
                            <div {...getVideoRootProps()} className="aspect-square flex items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/20">
                                <input {...getVideoInputProps()} />
                                <div className="text-center"><PlusIcon className="w-6 h-6 mx-auto text-[var(--color-text-secondary)]"/><p className="text-xs mt-1">Adicionar</p></div>
                            </div>
                        </div>
                    </div>
                     <footer className="mt-6 pt-6 flex justify-end gap-3 border-t border-[var(--color-border)]">
                        <button type="button" className="btn-cancel" onClick={onClose}>Cancelar</button>
                        <button type="submit" className="btn-save"><CheckCircleIcon className="w-5 h-5"/> Salvar Projeto</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default DecorationProjectModal;