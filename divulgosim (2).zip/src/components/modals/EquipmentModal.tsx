import React, { useState, useEffect, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Equipment, EquipmentCategory } from '../../types.ts';
import { CloseIcon, CloudUploadIcon, CheckCircleIcon, TrashIcon, PlusIcon, VideoCameraIcon } from '../Icons.tsx';

interface EquipmentModalProps {
    onClose: () => void;
    onSave: (equipmentData: Omit<Equipment, 'id' | 'ownerId'> & { id?: string }) => void;
    equipmentToEdit?: Equipment;
}

const EquipmentModal: React.FC<EquipmentModalProps> = ({ onClose, onSave, equipmentToEdit }) => {
    const [name, setName] = useState('');
    const [category, setCategory] = useState<EquipmentCategory>(EquipmentCategory.SOUND);
    const [price, setPrice] = useState(0);
    const [description, setDescription] = useState('');
    const [brand, setBrand] = useState('');
    const [voltage, setVoltage] = useState('');
    const [power, setPower] = useState('');
    const [images, setImages] = useState<string[]>([]);
    const [videos, setVideos] = useState<string[]>([]);

    const isEditing = !!equipmentToEdit;

    useEffect(() => {
        if (equipmentToEdit) {
            setName(equipmentToEdit.name);
            setCategory(equipmentToEdit.category);
            setPrice(equipmentToEdit.price);
            setDescription(equipmentToEdit.description);
            setBrand(equipmentToEdit.brand || '');
            setVoltage(equipmentToEdit.voltage || '');
            setPower(equipmentToEdit.power || '');
            setImages(equipmentToEdit.images || []);
            setVideos(equipmentToEdit.videos || []);
        }
    }, [equipmentToEdit]);

    const handleFileDrop = useCallback((acceptedFiles: File[], type: 'image' | 'video') => {
        acceptedFiles.forEach(file => {
            const reader = new FileReader();
            reader.onloadend = () => {
                const result = reader.result as string;
                if (type === 'image') {
                    setImages(prev => [...prev, result]);
                } else {
                    setVideos(prev => [...prev, result]);
                }
            };
            reader.readAsDataURL(file);
        });
    }, []);

    const { getRootProps: getImageRootProps, getInputProps: getImageInputProps } = useDropzone({
        onDrop: files => handleFileDrop(files, 'image'),
        accept: { 'image/*': [] },
        multiple: true,
    });

    const { getRootProps: getVideoRootProps, getInputProps: getVideoInputProps } = useDropzone({
        onDrop: files => handleFileDrop(files, 'video'),
        accept: { 'video/*': [] },
        multiple: true,
    });

    const handleRemoveImage = (index: number) => setImages(prev => prev.filter((_, i) => i !== index));
    const handleRemoveVideo = (index: number) => setVideos(prev => prev.filter((_, i) => i !== index));

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name || images.length === 0) {
            alert('Nome e pelo menos uma imagem são obrigatórios.');
            return;
        }
        onSave({
            id: equipmentToEdit?.id,
            name,
            category,
            price,
            description,
            brand,
            voltage,
            power,
            images,
            videos,
        });
    };

    const commonLabelClass = "block text-sm font-medium text-[var(--color-text-secondary)] mb-2";

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins">{isEditing ? 'Editar Equipamento' : 'Adicionar Equipamento'}</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10"><CloseIcon className="w-7 h-7" /></button>
                </header>
                <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                            <div><label className={commonLabelClass}>Nome do Equipamento <span className="text-red-500">*</span></label><input type="text" value={name} onChange={e => setName(e.target.value)} className="form-control" required /></div>
                            <div><label className={commonLabelClass}>Categoria</label><select value={category} onChange={e => setCategory(e.target.value as any)} className="form-control">{Object.values(EquipmentCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}</select></div>
                            <div><label className={commonLabelClass}>Preço (R$/dia)</label><input type="number" value={price} onChange={e => setPrice(parseFloat(e.target.value) || 0)} className="form-control" /></div>
                        </div>
                        <div className="space-y-4">
                            <div><label className={commonLabelClass}>Descrição</label><textarea value={description} onChange={e => setDescription(e.target.value)} rows={5} className="form-control"></textarea></div>
                        </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div><label className={commonLabelClass}>Marca</label><input type="text" value={brand} onChange={e => setBrand(e.target.value)} className="form-control"/></div>
                        <div><label className={commonLabelClass}>Voltagem</label><input type="text" value={voltage} onChange={e => setVoltage(e.target.value)} className="form-control" placeholder="110v, 220v..."/></div>
                        <div><label className={commonLabelClass}>Potência</label><input type="text" value={power} onChange={e => setPower(e.target.value)} className="form-control" placeholder="1000W..."/></div>
                    </div>

                    <div className="pt-4 border-t border-[var(--color-border)]">
                        <label className={commonLabelClass}>🖼️ Imagens do Equipamento <span className="text-red-500">*</span></label>
                        <div className="grid grid-cols-3 md:grid-cols-5 gap-3 mb-3">
                            {images.map((img, index) => (
                                <div key={index} className="relative group aspect-square">
                                    <img src={img} alt={`Preview ${index}`} className="w-full h-full object-cover rounded-md"/>
                                    <button type="button" onClick={() => handleRemoveImage(index)} className="absolute top-1 right-1 bg-red-600/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4" /></button>
                                </div>
                            ))}
                            <div {...getImageRootProps()} className="aspect-square flex items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/20">
                                <input {...getImageInputProps()} />
                                <div className="text-center"><PlusIcon className="w-6 h-6 mx-auto text-[var(--color-text-secondary)]"/><p className="text-xs mt-1">Adicionar</p></div>
                            </div>
                        </div>
                    </div>

                    <div className="pt-4 border-t border-[var(--color-border)]">
                        <label className={commonLabelClass}>🎬 Vídeos do Equipamento</label>
                        <div className="grid grid-cols-3 md:grid-cols-5 gap-3 mb-3">
                            {videos.map((vid, index) => (
                                <div key={index} className="relative group aspect-square">
                                    <video src={vid} className="w-full h-full object-cover rounded-md bg-black"/>
                                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none"><VideoCameraIcon className="w-8 h-8 text-white/50 opacity-50 group-hover:opacity-0"/></div>
                                    <button type="button" onClick={() => handleRemoveVideo(index)} className="absolute top-1 right-1 bg-red-600/80 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"><TrashIcon className="w-4 h-4" /></button>
                                </div>
                            ))}
                            <div {...getVideoRootProps()} className="aspect-square flex items-center justify-center border-2 border-dashed border-[var(--color-border)] rounded-lg text-center cursor-pointer hover:bg-black/20">
                                <input {...getVideoInputProps()} />
                                <div className="text-center"><PlusIcon className="w-6 h-6 mx-auto text-[var(--color-text-secondary)]"/><p className="text-xs mt-1">Adicionar</p></div>
                            </div>
                        </div>
                    </div>

                    <footer className="pt-6 flex justify-end gap-3 border-t border-[var(--color-border)]">
                        <button type="button" onClick={onClose} className="btn-cancel">Cancelar</button>
                        <button type="submit" className="btn-save"><CheckCircleIcon className="w-5 h-5"/> Salvar</button>
                    </footer>
                </form>
            </div>
        </div>
    );
};

export default EquipmentModal;