import React, { useState, useMemo } from 'react';
import { RaveEvent, Task, User, Campaign, CampaignApplication, Invitation, UserType, ExcursionApplication, GigApplication, PerformanceApplication, ServiceType, TicketSale, Excursion, Photo, Service, Ticket, CoverageRequest } from '../../types.ts';
import { CloseIcon, PlusIcon, EditIcon, TrashIcon, UserIcon as UserIconDefault, PaperClipIcon } from '../Icons.tsx';

type ActiveTab = 'tasks' | 'gallery' | 'campaigns' | 'requests' | 'vendas';

// Union type for all possible request/application types to avoid using `any`
type AnyApplication = (CoverageRequest | CampaignApplication | ExcursionApplication | GigApplication | PerformanceApplication) & { [key: string]: any };


interface ManageEventModalProps {
    event: RaveEvent;
    tasks: Task[];
    coverageRequests: CoverageRequest[];
    campaigns: Campaign[];
    applications: CampaignApplication[];
    invitations: Invitation[];
    excursionApplications: ExcursionApplication[];
    excursions: Excursion[];
    gigApplications: GigApplication[];
    performanceApplications: PerformanceApplication[];
    ticketSales: TicketSale[];
    users: User[];
    onClose: () => void;
    onViewProfile: (user: User) => void;
    onAddTask: (eventId: string) => void;
    onEdit: (event: RaveEvent) => void;
    onDelete: (eventId: string) => void;
    onManageRequest: (requestId: string, status: 'approved' | 'rejected') => void;
    onCreateCampaign: () => void;
    onManageApplication: (applicationId: string, status: 'approved' | 'rejected') => void;
    onInviteUser: () => void;
    onManageExcursionApplication: (applicationId: string, status: 'approved' | 'rejected') => void;
    onManageGigApplication: (applicationId: string, status: 'approved' | 'rejected') => void;
    onManagePerformanceApplication: (applicationId: string, status: 'approved' | 'rejected') => void;
    onManageGallery: (event: RaveEvent) => void;
    defaultTab?: ActiveTab;
}

export const ManageEventModal: React.FC<ManageEventModalProps> = (props) => {
    const { 
        event, tasks, coverageRequests, campaigns, applications, invitations, 
        excursionApplications, excursions, gigApplications, performanceApplications, 
        ticketSales, users, onClose, onViewProfile, onAddTask, onEdit, onDelete, 
        onManageRequest, onCreateCampaign, onManageApplication, onInviteUser, 
        onManageExcursionApplication, onManageGigApplication, onManagePerformanceApplication,
        onManageGallery, defaultTab
    } = props;
    const [activeTab, setActiveTab] = useState<ActiveTab>(defaultTab || 'requests');

    const tabButtonClass = (tab: ActiveTab) => 
    `px-4 py-2 rounded-t-lg font-semibold transition-colors w-full text-center
     ${activeTab === tab ? 'bg-black/20 border-b-2 border-[var(--color-accent-primary)] text-[var(--color-accent-primary)]' : 'bg-transparent text-white hover:bg-white/5'}`;

    const pendingRequests = coverageRequests.filter(r => r.status === 'pending');
    const pendingApplications = applications.filter(a => a.status === 'pending');
    const pendingExcursionApps = excursionApplications.filter(a => a.status === 'pending');
    const pendingGigApps = gigApplications.filter(a => a.status === 'pending');
    const pendingPerfApps = performanceApplications.filter(a => a.status === 'pending');
    const totalPending = pendingRequests.length + pendingApplications.length + pendingExcursionApps.length + pendingGigApps.length + pendingPerfApps.length;

    const salesReport = useMemo(() => {
        const totalRevenue = ticketSales.reduce((sum: number, sale: TicketSale) => sum + (sale.quantity * sale.pricePerTicket), 0);
        
        const promoterSales = ticketSales.reduce((acc: Record<string, { totalQuantity: number, totalRevenue: number }>, sale: TicketSale) => {
            if (!sale.promoterId) return acc;
            if (!acc[sale.promoterId]) {
                acc[sale.promoterId] = { totalQuantity: 0, totalRevenue: 0 };
            }
            acc[sale.promoterId].totalQuantity += sale.quantity;
            acc[sale.promoterId].totalRevenue += sale.quantity * sale.pricePerTicket;
            return acc;
        }, {} as Record<string, { totalQuantity: number, totalRevenue: number }>);

        const salesByTicket = ticketSales.reduce((acc: Record<string, { name: string, quantity: number, revenue: number }>, sale: TicketSale) => {
            if (!acc[sale.ticketId]) {
                acc[sale.ticketId] = { name: sale.ticketName, quantity: 0, revenue: 0 };
            }
            acc[sale.ticketId].quantity += sale.quantity;
            acc[sale.ticketId].revenue += sale.quantity * sale.pricePerTicket;
            return acc;
        }, {} as Record<string, { name: string, quantity: number, revenue: number }>);
        
        return {
            totalRevenue,
            promoterSales,
            salesByTicket,
            totalTicketsSold: ticketSales.reduce((sum: number, sale: TicketSale) => sum + sale.quantity, 0),
        };

    }, [ticketSales]);

    const renderContent = () => {
        switch (activeTab) {
            case 'tasks':
                return (
                    <div>
                        <button type="button" onClick={() => onAddTask(event.id)} className="btn bg-[var(--color-accent-secondary)] text-slate-900 mb-4"><PlusIcon className="w-5 h-5"/> Adicionar Tarefa</button>
                        <div className="space-y-3 max-h-80 overflow-y-auto pr-2">
                            {tasks.length > 0 ? tasks.map(task => (
                                <div key={task.id} className="bg-black/20 p-3 rounded-lg">
                                    <div className="flex justify-between items-start">
                                        <p className="font-semibold">{task.title}</p>
                                        {task.rewardRB && <p className="font-bold text-yellow-300 flex-shrink-0 ml-2">💎 {task.rewardRB} RB</p>}
                                    </div>
                                    <p className="text-sm text-white/70 mt-1">{task.description}</p>
                                    {task.link && <a href={task.link} target="_blank" rel="noopener noreferrer" className="text-xs text-cyan-400 hover:underline flex items-center gap-1 mt-1"><PaperClipIcon className="w-3 h-3"/> {task.link}</a>}
                                    <div>
                                        <p className="text-xs text-white/50 text-right mt-1">Prazo: {new Date(task.deadline).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}</p>
                                    </div>
                                </div>
                            )) : <p className="text-center text-sm text-white/70 p-4">Nenhuma tarefa criada para este evento.</p>}
                        </div>
                    </div>
                );
            case 'gallery':
                const team = event.services.map(s => {
                    const user = users.find(u => u.id === s.providerId);
                    return user ? { ...s, user } : null;
                }).filter((s): s is Service & { user: User } => s !== null);

                const galleryPhotos = event.gallery || [];

                return (
                    <div>
                         <button type="button" onClick={() => onManageGallery(event)} className="btn bg-[var(--color-accent-secondary)] text-slate-900 mb-6"><PlusIcon className="w-5 h-5"/> Gerenciar Galeria de Mídia</button>
                         <h3 className="font-bold text-lg mb-3">Equipe Contratada ({team.length})</h3>
                         <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                            {team.length > 0 ? team.map(member => (
                                <button type="button" onClick={() => onViewProfile(member.user)} key={member.providerId} className="bg-black/20 p-3 rounded-lg text-center transition-colors hover:bg-white/10">
                                    <div className="w-16 h-16 rounded-full mx-auto mb-2 bg-black/20 overflow-hidden">
                                        {member.user.profile.personal.profilePicture ? <img src={member.user.profile.personal.profilePicture} alt={member.user.profile.personal.fullName} className="w-full h-full object-cover" /> : <UserIconDefault className="w-10 h-10 text-white/50 m-auto"/>}
                                    </div>
                                    <p className="font-semibold text-sm">{member.user.profile.personal.fullName}</p>
                                    <p className="text-xs text-[var(--color-accent-primary)]">{member.type}</p>
                                </button>
                            )) : <p className="col-span-full text-center text-sm text-white/70 p-4">Nenhum prestador de serviço na equipe.</p>}
                         </div>
                         <h3 className="font-bold text-lg mb-3">Galeria do Evento ({galleryPhotos.length} fotos)</h3>
                         <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                            {galleryPhotos.slice(0, 10).map((photo: Photo) => (
                                <div key={photo.id} className="aspect-square bg-black/40 rounded-md overflow-hidden">
                                    <img src={photo.url} alt={photo.name} className="w-full h-full object-cover" />
                                </div>
                            ))}
                            {galleryPhotos.length > 10 && <div className="aspect-square bg-black/40 rounded-md flex items-center justify-center text-center text-xs">e mais {galleryPhotos.length - 10}...</div>}
                         </div>
                         {galleryPhotos.length === 0 && <p className="text-center text-sm text-white/70 p-4">A galeria está vazia.</p>}
                    </div>
                );
            case 'campaigns':
                return (
                    <div>
                        <div className="flex gap-4 mb-6">
                            <button type="button" onClick={onCreateCampaign} className="btn bg-[var(--color-accent-secondary)] text-slate-900"><PlusIcon className="w-5 h-5"/> Criar Campanha</button>
                            <button type="button" onClick={onInviteUser} className="btn bg-black/20 hover:bg-white/10 text-white"><PlusIcon className="w-5 h-5"/> Convidar Usuário</button>
                        </div>
                         <h3 className="font-bold text-lg mb-2">Campanhas Ativas</h3>
                        <div className="space-y-3 mb-6 max-h-40 overflow-y-auto pr-2">
                            {campaigns.length > 0 ? campaigns.map(c => <div key={c.id} className="bg-black/20 p-3 rounded-lg font-semibold flex justify-between"><span>{c.name}</span> <span className="text-green-400">R$ {c.payment}</span></div>) : <p className="text-center text-sm text-white/70 p-4">Nenhuma campanha criada.</p>}
                        </div>
                         <h3 className="font-bold text-lg mb-2">Convites Enviados</h3>
                         <div className="space-y-3 max-h-40 overflow-y-auto pr-2">
                            {invitations.length > 0 ? invitations.map(i => {
                                const user = users.find(u => u.id === i.inviteeId);
                                return <div key={i.id} className="bg-black/20 p-3 rounded-lg flex justify-between items-center text-sm">
                                    <div>
                                        <p className="font-semibold">{user?.profile.personal.fullName}</p>
                                        <p className="text-xs text-white/70">{i.role}</p>
                                    </div>
                                    <span className={`capitalize font-bold text-xs px-2 py-1 rounded-full ${i.status === 'pending' ? 'bg-yellow-500/20 text-yellow-300' : i.status === 'accepted' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>{i.status}</span>
                                </div>
                            }) : <p className="text-center text-sm text-white/70 p-4">Nenhum convite enviado.</p>}
                        </div>
                    </div>
                );
            case 'requests':
                const requestTypes = [
                    { title: 'Cobertura (Fotógrafos)', requests: pendingRequests, handler: onManageRequest, idField: 'photographerId', nameField: (req: AnyApplication) => users.find(u => u.id === req.photographerId)?.profile.personal.fullName },
                    { title: 'Campanhas (Influencers)', requests: pendingApplications, handler: onManageApplication, idField: 'influencerId', nameField: (req: AnyApplication) => users.find(u => u.id === req.influencerId)?.profile.personal.fullName },
                    { title: 'Excursões (Parceria Oficial)', requests: pendingExcursionApps, handler: onManageExcursionApplication, idField: 'tripOrganizerId', nameField: (req: AnyApplication) => { const user = users.find(u => u.id === req.tripOrganizerId); const excursion = excursions.find(ex => ex.id === req.excursionId); return `${excursion?.name} (por ${user?.profile.personal.fullName})`; }},
                    { title: 'Line-up (DJs)', requests: pendingGigApps, handler: onManageGigApplication, idField: 'djId', nameField: (req: AnyApplication) => users.find(u => u.id === req.djId)?.profile.personal.fullName },
                    { title: 'Performances (Artistas)', requests: pendingPerfApps, handler: onManagePerformanceApplication, idField: 'artistId', nameField: (req: AnyApplication) => users.find(u => u.id === req.artistId)?.profile.personal.fullName },
                ];
                 return (
                    <div className="space-y-6">
                        {totalPending === 0 && <p className="text-center text-sm text-white/70 p-4">Nenhuma solicitação pendente.</p>}
                        {requestTypes.map(type => type.requests.length > 0 && (
                             <div key={type.title}>
                                <h3 className="font-bold text-lg mb-2">{type.title}</h3>
                                <div className="space-y-2">
                                    {type.requests.map((req: AnyApplication) => {
                                        const user = users.find(u => u.id === req[type.idField]);
                                        return (
                                            <div key={req.id} className="bg-black/20 p-3 rounded-lg flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                                                <button type="button" onClick={() => user && onViewProfile(user)} className="font-semibold hover:underline text-left break-words">{type.nameField(req)}</button>
                                                <div className="flex gap-2 flex-shrink-0 self-end sm:self-center">
                                                    <button type="button" onClick={() => type.handler(req.id, 'approved')} className="btn bg-[var(--color-success)] text-slate-900 !text-xs !py-1 !px-2">Aprovar</button>
                                                    <button type="button" onClick={() => type.handler(req.id, 'rejected')} className="btn bg-[var(--color-danger)] text-white !text-xs !py-1 !px-2">Rejeitar</button>
                                                </div>
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        ))}
                    </div>
                );
            case 'vendas':
                 return (
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-center">
                            <div className="bg-black/20 p-4 rounded-lg border border-[var(--color-border)]">
                                <p className="text-sm text-white/70">Receita Total</p>
                                <p className="text-3xl font-bold text-green-400">R$ {salesReport.totalRevenue.toFixed(2).replace('.', ',')}</p>
                            </div>
                             <div className="bg-black/20 p-4 rounded-lg border border-[var(--color-border)]">
                                <p className="text-sm text-white/70">Ingressos Vendidos</p>
                                <p className="text-3xl font-bold">{salesReport.totalTicketsSold}</p>
                            </div>
                        </div>
                         <div>
                            <h3 className="font-bold text-lg mb-2">Vendas por Lote</h3>
                            <div className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)] space-y-2">
                                {Object.values(salesReport.salesByTicket).map((ticket: { name: string; quantity: number; revenue: number }, index) => (
                                    <div key={`${ticket.name}-${index}`} className="flex justify-between text-sm">
                                        <span>{ticket.name}</span>
                                        <span className="font-semibold">{ticket.quantity} vendidos (R$ {ticket.revenue.toFixed(2).replace('.', ',')})</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div>
                            <h3 className="font-bold text-lg mb-2">Vendas por Divulgador</h3>
                             <div className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)] space-y-2 max-h-40 overflow-y-auto">
                                {Object.entries(salesReport.promoterSales).map(([promoterId, data]: [string, { totalQuantity: number; totalRevenue: number }]) => {
                                    const promoter = users.find(u => u.id === promoterId);
                                    return (
                                        <div key={promoterId} className="flex justify-between text-sm">
                                            <span>{promoter?.profile.personal.fullName || 'Desconhecido'}</span>
                                            <span className="font-semibold">{data.totalQuantity} vendidos (R$ {data.totalRevenue.toFixed(2).replace('.', ',')})</span>
                                        </div>
                                    )
                                })}
                            </div>
                        </div>
                    </div>
                );
        }
    };
    
    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <div>
                        <h2 className="text-2xl font-bold font-poppins">Gerenciar Evento</h2>
                        <p className="text-[var(--color-accent-primary)]">{event.name}</p>
                    </div>
                    <div className="flex items-center gap-2">
                        <button type="button" onClick={() => onEdit(event)} className="p-2 rounded-full hover:bg-white/10" aria-label="Editar Informações"><EditIcon className="w-5 h-5"/></button>
                        <button type="button" onClick={() => onDelete(event.id)} className="p-2 rounded-full hover:bg-white/10" aria-label="Excluir Evento"><TrashIcon className="w-5 h-5"/></button>
                        <button type="button" onClick={onClose} className="p-1 rounded-full hover:bg-white/10"><CloseIcon className="w-7 h-7" /></button>
                    </div>
                </header>
                <nav className="flex-shrink-0 border-b border-[var(--color-border)] overflow-x-auto">
                    <div className="flex items-center whitespace-nowrap px-2">
                        <button type="button" onClick={() => setActiveTab('requests')} className={tabButtonClass('requests')}>
                            Solicitações {totalPending > 0 && <span className="ml-2 bg-red-500 text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded-full">{totalPending}</span>}
                        </button>
                        <button type="button" onClick={() => setActiveTab('tasks')} className={tabButtonClass('tasks')}>Tarefas</button>
                        <button type="button" onClick={() => setActiveTab('gallery')} className={tabButtonClass('gallery')}>Equipe & Mídia</button>
                        <button type="button" onClick={() => setActiveTab('campaigns')} className={tabButtonClass('campaigns')}>Marketing</button>
                        <button type="button" onClick={() => setActiveTab('vendas')} className={tabButtonClass('vendas')}>Vendas</button>
                    </div>
                </nav>
                <div className="flex-grow p-6 overflow-y-auto">
                    {renderContent()}
                </div>
            </div>
        </div>
    );
};