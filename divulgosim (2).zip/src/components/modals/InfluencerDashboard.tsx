import React, { useState, useMemo, useEffect } from 'react';
import { Product } from '../../types.ts';
import { CloseIcon, TagIcon, ShoppingCartIcon, ChevronLeftIcon, ChevronRightIcon } from '../Icons.tsx';

interface ProductDetailModalProps {
    product: Product;
    onClose: () => void;
    onAddToCart: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({ product, onClose, onAddToCart }) => {
    const [currentIndex, setCurrentIndex] = useState(0);

    const mediaItems = useMemo(() => {
        const items = [];
        if (product.images) {
            items.push(...product.images.map(url => ({ type: 'image', url })));
        }
        if (product.videos) {
            items.push(...product.videos.map(url => ({ type: 'video', url })));
        }
        return items;
    }, [product]);

    const handlePrev = () => {
        setCurrentIndex(prev => (prev === 0 ? mediaItems.length - 1 : prev - 1));
    };

    const handleNext = () => {
        setCurrentIndex(prev => (prev === mediaItems.length - 1 ? 0 : prev + 1));
    };

    useEffect(() => {
        setCurrentIndex(0);
    }, [product.id]);

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-3xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins text-[var(--color-accent-primary)]">{product.name}</h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>

                <div className="p-6 overflow-y-auto flex-grow grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="relative aspect-square bg-black/20 rounded-lg overflow-hidden group">
                        {mediaItems.length > 0 ? (
                            mediaItems[currentIndex].type === 'image' ? (
                                <img src={mediaItems[currentIndex].url} alt={`${product.name} - view ${currentIndex + 1}`} className="w-full h-full object-cover" />
                            ) : (
                                <video src={mediaItems[currentIndex].url} controls className="w-full h-full object-cover bg-black" />
                            )
                        ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-500">Sem mídia</div>
                        )}

                        {mediaItems.length > 1 && (
                            <>
                                <button onClick={handlePrev} className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                    <ChevronLeftIcon className="w-6 h-6" />
                                </button>
                                <button onClick={handleNext} className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 p-2 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                    <ChevronRightIcon className="w-6 h-6" />
                                </button>
                                <div className="absolute bottom-2 right-2 text-xs bg-black/50 px-2 py-1 rounded-full">
                                    {currentIndex + 1} / {mediaItems.length}
                                </div>
                            </>
                        )}
                    </div>
                    <div className="flex flex-col">
                        <div className="bg-slate-700/50 text-xs font-bold px-3 py-1 rounded-full self-start mb-4 flex items-center gap-2">
                            <TagIcon className="w-4 h-4" /> {product.category}
                        </div>
                        <p className="text-4xl font-bold text-green-400 mb-4">R$ {product.price.toFixed(2).replace('.', ',')}</p>
                        <p className="text-sm text-white/80 mb-6 flex-grow whitespace-pre-wrap">{product.description}</p>
                        <div className="text-sm text-slate-400 mb-4">
                            Estoque: {product.stock === 0 ? 'Disponível (Digital/Ilimitado)' : `${product.stock} unidades`}
                        </div>
                        <button 
                            onClick={() => onAddToCart(product)}
                            className="w-full btn bg-[var(--color-accent-primary)] text-slate-900 !py-3 text-base"
                        >
                            <ShoppingCartIcon className="w-5 h-5" /> Adicionar ao Carrinho
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};