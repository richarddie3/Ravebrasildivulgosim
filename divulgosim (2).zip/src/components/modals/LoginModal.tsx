import React, { useState } from 'react';
import { CloseIcon, MailIcon, LockClosedIcon } from '../Icons.tsx';

interface LoginModalProps {
    onClose: () => void;
    onRegisterClick: () => void;
    onLoginSubmit: (email: string) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose, onRegisterClick, onLoginSubmit }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // In a real app, you would validate password here before submitting
        if (!email) {
            alert("Por favor, preencha o email.");
            return;
        }
        onLoginSubmit(email);
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="relative bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-md max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-white">
                <div className="absolute top-4 right-4 z-10">
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </div>
                <div className="p-8 pt-12">
                    <div className="flex justify-center mb-6">
                        <h1 className="text-5xl font-bold font-montserrat text-center text-[var(--color-accent-primary)]">Divulgosim</h1>
                    </div>
                    <h2 className="text-3xl font-bold font-poppins text-center mb-8">Entrar</h2>
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="email">Email</label>
                            <div className="relative">
                                <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                    <MailIcon className="h-5 w-5 text-gray-400" />
                                </span>
                                <input
                                    type="email"
                                    id="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    className="form-control pl-10"
                                    placeholder="voce@exemplo.com"
                                    required
                                />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="password">Senha</label>
                             <div className="relative">
                                <span className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                    <LockClosedIcon className="h-5 w-5 text-gray-400" />
                                </span>
                                <input
                                    type="password"
                                    id="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="form-control pl-10"
                                    required
                                />
                            </div>
                        </div>
                        <button type="submit" className="w-full bg-[var(--color-accent-primary)] text-slate-900 font-semibold py-3 px-5 rounded-lg hover:bg-[var(--color-accent-secondary)] transition-colors shadow-md hover:shadow-lg">
                            Entrar
                        </button>
                        <p className="text-center text-sm text-[var(--color-text-secondary)]">
                            Não tem uma conta?{' '}
                            <button type="button" onClick={onRegisterClick} className="font-semibold text-[var(--color-accent-primary)] hover:text-[var(--color-accent-secondary)]">
                                Cadastre-se
                            </button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default LoginModal;