import React, { useState } from 'react';
import { generateAdvancedThemeCss } from '../../services/geminiService.ts';
import { CloseIcon, SparklesIcon } from '../Icons.tsx';

interface AIThemeModalProps {
    onClose: () => void;
    onApplyTheme: (css: string) => void;
    onResetTheme: () => void;
}

const AIThemeModal: React.FC<AIThemeModalProps> = ({ onClose, onApplyTheme, onResetTheme }) => {
    const [prompt, setPrompt] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleGenerate = async () => {
        if (!prompt) return;
        setIsLoading(true);
        setError(null);
        try {
            const css = await generateAdvancedThemeCss(prompt);
            onApplyTheme(css);
        } catch (e) {
            setError('Falha ao gerar o tema. Tente novamente.');
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
         <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-2xl w-full max-w-lg max-h-[90vh] flex flex-col shadow-2xl text-[var(--color-text-primary)]">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <h2 className="text-2xl font-bold font-poppins flex items-center gap-2">
                        <SparklesIcon className="w-6 h-6 text-[var(--color-accent-primary)]" />
                        Gerador de Tema com IA
                    </h2>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/10 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>
                <div className="p-8 space-y-6 overflow-y-auto">
                    <div>
                        <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2" htmlFor="theme-prompt">
                            Descreva o tema que você imagina
                        </label>
                        <textarea
                            id="theme-prompt"
                            value={prompt}
                            onChange={(e) => setPrompt(e.target.value)}
                            rows={4}
                            className="form-control"
                            placeholder="Ex: festa neon em uma floresta cyberpunk, pôr do sol na praia com tons pastel, psicodelia escura com toques de roxo..."
                        />
                    </div>
                    {error && <p className="text-red-400 text-sm text-center">{error}</p>}
                </div>
                <footer className="p-6 border-t border-[var(--color-border)] flex flex-col sm:flex-row justify-between items-center gap-4">
                     <button
                        onClick={handleGenerate}
                        disabled={isLoading || !prompt}
                        className="w-full sm:w-auto btn bg-[var(--color-accent-secondary)] hover:opacity-90 text-slate-900 disabled:bg-slate-600 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                        {isLoading ? (
                            <>
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Gerando...
                            </>
                        ) : (
                            <> <SparklesIcon className="w-5 h-5" /> Gerar Tema </>
                        )}
                    </button>
                    <button onClick={onResetTheme} className="text-sm text-[var(--color-text-secondary)] hover:text-[var(--color-text-primary)] hover:underline">
                        Restaurar Tema Padrão
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default AIThemeModal;