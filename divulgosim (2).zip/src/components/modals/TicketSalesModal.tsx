import React, { useState, useMemo } from 'react';
import { RaveEvent, Ticket } from '../../types.ts';
import { CloseIcon, TicketIcon } from '../Icons.tsx';

interface TicketSalesModalProps {
    event: RaveEvent;
    onClose: () => void;
    onConfirmSale: (quantities: { [ticketId: string]: number }) => void;
}

const TicketSalesModal: React.FC<TicketSalesModalProps> = ({ event, onClose, onConfirmSale }) => {
    const [quantities, setQuantities] = useState<{ [ticketId: string]: number }>({});

    const handleQuantityChange = (ticketId: string, quantity: number) => {
        setQuantities(prev => ({
            ...prev,
            [ticketId]: Math.max(0, quantity) // Ensure quantity is not negative
        }));
    };

    const total = useMemo(() => {
        return event.tickets.reduce((sum, ticket) => {
            const quantity = quantities[ticket.id] || 0;
            return sum + (quantity * ticket.price);
        }, 0);
    }, [quantities, event.tickets]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onConfirmSale(quantities);
    };

    return (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--color-bg-secondary)] rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col shadow-2xl border border-[var(--color-border)] text-[var(--color-text-primary)]">
                <header className="flex justify-between items-center p-6 border-b border-[var(--color-border)]">
                    <div>
                        <h2 className="text-2xl font-bold font-poppins">Vender Ingressos</h2>
                        <p className="text-[var(--color-text-secondary)]">{event.name}</p>
                    </div>
                    <button onClick={onClose} className="p-1 rounded-full hover:bg-white/20 transition-colors">
                        <CloseIcon className="w-7 h-7" />
                    </button>
                </header>

                <form id="ticket-sales-form" onSubmit={handleSubmit} className="p-6 overflow-y-auto flex-grow space-y-4">
                    {event.tickets.length > 0 ? (
                        (() => {
                            let activeLotFound = false;
                            return event.tickets.map(ticket => {
                                const sold = ticket.sold || 0;
                                const quantity = ticket.quantity;
                                const isSoldOut = typeof quantity === 'number' && sold >= quantity;
                                let isDisabled = false;
                                let statusText = null;

                                if (isSoldOut) {
                                    isDisabled = true;
                                    statusText = <span className="text-sm font-bold text-red-400">Esgotado</span>;
                                } else if (activeLotFound && typeof quantity === 'number') {
                                    isDisabled = true;
                                    statusText = <span className="text-sm font-bold text-yellow-400">Aguardando</span>;
                                } else if (!isSoldOut && (typeof quantity === 'number' || quantity === undefined)) {
                                     if (typeof quantity === 'number' && !activeLotFound) {
                                        activeLotFound = true;
                                    }
                                }
                                
                                const remaining = (quantity ?? Infinity) - sold;

                                return (
                                    <div key={ticket.id} className={`bg-black/20 p-4 rounded-lg flex justify-between items-center border border-[var(--color-border)] ${isDisabled ? 'opacity-60' : ''}`}>
                                        <div>
                                            <p className="font-bold">{ticket.name}</p>
                                            <p className="text-sm text-[var(--color-accent-primary)]">R$ {ticket.price.toFixed(2).replace('.', ',')}</p>
                                            {typeof quantity === 'number' && <p className="text-xs text-white/60">Restam: {remaining}</p>}
                                        </div>
                                        <div className="flex items-center gap-2">
                                            {isDisabled ? statusText : (
                                                <>
                                                    <label htmlFor={`qty-${ticket.id}`} className="text-sm">Qtd:</label>
                                                    <input 
                                                        type="number"
                                                        id={`qty-${ticket.id}`}
                                                        min="0"
                                                        max={remaining < Infinity ? remaining : undefined}
                                                        value={quantities[ticket.id] || ''}
                                                        onChange={(e) => handleQuantityChange(ticket.id, parseInt(e.target.value) || 0)}
                                                        className="w-20 form-control !py-1.5 !px-2 text-center"
                                                        disabled={isDisabled}
                                                    />
                                                </>
                                            )}
                                        </div>
                                    </div>
                                );
                            });
                        })()
                    ) : (
                        <div className="text-center py-8 text-[var(--color-text-secondary)]">
                            <TicketIcon className="w-12 h-12 mx-auto mb-2" />
                            <p>Nenhum ingresso disponível para este evento.</p>
                        </div>
                    )}
                </form>

                <footer className="p-6 border-t border-[var(--color-border)] space-y-4">
                    <div className="flex justify-between items-center text-xl font-bold">
                        <span>TOTAL:</span>
                        <span className="text-[var(--color-success)]">R$ {total.toFixed(2).replace('.', ',')}</span>
                    </div>
                    <button 
                        type="submit"
                        form="ticket-sales-form"
                        disabled={total <= 0}
                        className="w-full btn btn-save disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        Confirmar Venda
                    </button>
                </footer>
            </div>
        </div>
    );
};

export default TicketSalesModal;