import React from 'react';
import { User, AppView, UserType } from '../../types.ts';
import { 
    HomeIcon, UserIcon, ChatBubbleLeftRightIcon, ClipboardIcon, HeartIcon, ChartBarIcon, NewspaperIcon, StoreIcon, BusIcon, MusicIcon,
    CameraIcon, TheaterIcon, SpeakerIcon, SparklesIcon
} from './Icons.tsx';

interface MainMenuProps {
    user: User;
    activeView: AppView;
    onNavigate: (view: AppView) => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ user, activeView, onNavigate }) => {
    
    const allNavItems: { view: AppView; label: string; icon: React.FC<any>; roles: UserType[] | 'all' }[] = [
        { view: 'calendar', label: 'Início', icon: HomeIcon, roles: 'all' },
        { view: 'feed', label: 'Feed', icon: NewspaperIcon, roles: 'all' },
        { view: 'shop', label: 'Loja', icon: StoreIcon, roles: 'all' },
        { view: 'followedEvents', label: 'Meus Eventos', icon: HeartIcon, roles: 'all' },
        { view: 'messages', label: 'Mensagens', icon: ChatBubbleLeftRightIcon, roles: 'all' },
        { view: 'mainDashboard', label: 'Dashboard', icon: ChartBarIcon, roles: [UserType.ORGANIZER] },
        { view: 'influencerDashboard', label: 'Tarefas', icon: ClipboardIcon, roles: [UserType.PROMOTER, UserType.INFLUENCER] },
        { view: 'excursions', label: 'Excursões', icon: BusIcon, roles: [UserType.TRIP_ORGANIZER] },
        { view: 'djDashboard', label: 'Painel DJ', icon: MusicIcon, roles: [UserType.DJ] },
        { view: 'photographerDashboard', label: 'Painel Fotógrafo', icon: CameraIcon, roles: [UserType.PHOTOGRAPHER] },
        { view: 'artistDashboard', label: 'Painel Artista', icon: TheaterIcon, roles: [UserType.ARTIST] },
        { view: 'storeDashboard', label: 'Minha Loja', icon: StoreIcon, roles: [UserType.STORE_OWNER] },
        { view: 'soundLightingDashboard', label: 'Som & Luz', icon: SpeakerIcon, roles: [UserType.SOUND_LIGHTING] },
        { view: 'decorationDashboard', label: 'Decoração', icon: SparklesIcon, roles: [UserType.DECORATION] },
    ];

    const availableNavItems = allNavItems.filter(item => 
        item.roles === 'all' || item.roles.some(role => user.roles.includes(role))
    );

    return (
        <nav className="w-full max-w-7xl bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl p-2 shadow-lg">
            <div className="flex items-center gap-2 overflow-x-auto">
                {availableNavItems.map(({ view, label, icon: Icon }) => {
                    const isActive = activeView === view;
                    return (
                        <button
                            key={view}
                            onClick={() => onNavigate(view as AppView)}
                            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold transition-colors ${
                                isActive 
                                ? 'bg-[var(--color-accent-primary)] text-slate-900' 
                                : 'text-[var(--color-text-secondary)] hover:bg-white/10 hover:text-white'
                            }`}
                        >
                            <Icon className="w-5 h-5" />
                            <span>{label}</span>
                        </button>
                    );
                })}
            </div>
        </nav>
    );
};

export default MainMenu;
