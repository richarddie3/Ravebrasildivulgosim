import React from 'react';
import { RaveEvent, EventCategory, User, Task, UserType } from '../../types.ts';
import { CalendarIcon, LocationIcon, TagIcon, HeartIcon, ClipboardIcon } from '../Icons.tsx';

interface EventListProps {
  events: RaveEvent[];
  currentUser: User | null;
  tasks: Task[];
  onEventClick: (event: RaveEvent) => void;
  onToggleFollow: (eventId: string) => void;
}

const categoryStyles: { [key in EventCategory]: { bg: string, text: string } } = {
    [EventCategory.FESTIVAL]: { bg: 'bg-purple-500', text: 'text-white' },
    [EventCategory.RAVE]: { bg: 'bg-pink-500', text: 'text-white' },
    [EventCategory.PVT]: { bg: 'bg-orange-500', text: 'text-white' },
    [EventCategory.AFTER]: { bg: 'bg-cyan-500', text: 'text-white' },
};

interface EventCardProps {
    event: RaveEvent;
    onClick: () => void;
    onToggleFollow: (eventId: string) => void;
    isFollowed: boolean;
    currentUser: User | null;
    taskCount: number;
}


const EventCard: React.FC<EventCardProps> = ({ event, onClick, onToggleFollow, isFollowed, currentUser, taskCount }) => {
    const startingPrice = event.tickets && event.tickets.length > 0
        ? `A partir de R$ ${Math.min(...event.tickets.map(t => t.price)).toFixed(2).replace('.', ',')}`
        : 'Consulte';
    
    const categoryStyle = categoryStyles[event.category] || { bg: 'bg-gray-500', text: 'text-white' };
    const isPromoter = currentUser?.roles.includes(UserType.PROMOTER);

    return (
        <button 
            onClick={onClick}
            className="relative w-full text-left bg-slate-900/50 border border-[var(--color-border)] rounded-lg overflow-hidden group aspect-[3/4] transition-all duration-300 hover:shadow-2xl hover:border-yellow-400/50 cursor-pointer"
        >
            <img src={event.image || `https://picsum.photos/800/600?random=${event.id}`} alt={event.name} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent"></div>

            {isPromoter && taskCount > 0 && (
                <span className="absolute top-3 left-3 z-10 text-xs font-bold px-2 py-1 rounded-full bg-blue-500 text-white backdrop-blur-sm bg-opacity-80 flex items-center gap-1">
                    <ClipboardIcon className="w-3 h-3" /> {taskCount} {taskCount > 1 ? 'Tarefas' : 'Tarefa'}
                </span>
            )}
            
            <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${categoryStyle.bg} ${categoryStyle.text} backdrop-blur-sm bg-opacity-70`}>
                    {event.category}
                </span>
                {currentUser && (
                    <button
                        onClick={(e) => { e.stopPropagation(); onToggleFollow(event.id); }}
                        className={`p-1.5 rounded-full transition-colors ${isFollowed ? 'text-pink-500 bg-black/50' : 'text-white bg-black/50 hover:text-pink-400'}`}
                        aria-label={isFollowed ? 'Deixar de seguir' : 'Seguir evento'}
                    >
                        <HeartIcon className="w-6 h-6" fill={isFollowed ? 'currentColor' : 'none'} />
                    </button>
                )}
            </div>


            <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                <h3 className="text-xl font-bold text-[var(--color-accent-primary)] mb-2 font-poppins drop-shadow-lg">{event.name}</h3>
                
                <div className="pt-2 mt-2 border-t border-yellow-400/20 max-h-0 opacity-0 group-hover:max-h-40 group-hover:opacity-100 transition-all duration-300 ease-in-out">
                    <div className="space-y-1 text-sm text-gray-200">
                        <p className="flex items-center gap-2"><CalendarIcon className="w-4 h-4 text-yellow-400 flex-shrink-0" /> {event.dateString}</p>
                        <p className="flex items-center gap-2"><LocationIcon className="w-4 h-4 text-yellow-400 flex-shrink-0" /> {event.location}</p>
                        <p className="flex items-center gap-2 font-bold text-[var(--color-success)]"><TagIcon className="w-4 h-4 text-yellow-400 flex-shrink-0" /> {startingPrice}</p>
                    </div>
                </div>
            </div>
        </button>
    );
};

const EventList: React.FC<EventListProps> = ({ events, currentUser, tasks, onEventClick, onToggleFollow }) => {
    // Show upcoming events, sorted by followed status and then by date
    const upcomingEvents = events
        .filter(e => new Date(e.dates[e.dates.length - 1]) >= new Date(new Date().setDate(new Date().getDate() - 1))) // from yesterday onwards
        .sort((a,b) => {
            const aIsFollowed = currentUser?.followingEvents?.includes(a.id) ?? false;
            const bIsFollowed = currentUser?.followingEvents?.includes(b.id) ?? false;

            if (aIsFollowed && !bIsFollowed) return -1;
            if (!aIsFollowed && bIsFollowed) return 1;

            return new Date(a.dates[0]).getTime() - new Date(b.dates[0]).getTime();
        });

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingEvents.map(event => {
                const isFollowed = currentUser?.followingEvents?.includes(event.id) ?? false;
                const taskCount = tasks.filter(t => t.eventId === event.id).length;
                return (
                    <EventCard 
                        key={event.id} 
                        event={event} 
                        onClick={() => onEventClick(event)}
                        onToggleFollow={onToggleFollow}
                        isFollowed={isFollowed}
                        currentUser={currentUser}
                        taskCount={taskCount}
                    />
                );
            })}
        </div>
    );
};

export default EventList;