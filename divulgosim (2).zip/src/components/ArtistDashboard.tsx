import React from 'react';
import { User, Performance } from '../types.ts';
import { PlusIcon, TheaterIcon } from './Icons.tsx';

interface ArtistDashboardProps {
    user: User;
    performances: Performance[];
    onOpenPerformanceModal: () => void;
}

const ArtistDashboard: React.FC<ArtistDashboardProps> = ({ user, performances, onOpenPerformanceModal }) => {
    return (
         <div className="w-full max-w-7xl">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)]">Painel de Artista</h1>
                <button onClick={onOpenPerformanceModal} className="btn bg-[var(--color-accent-secondary)] text-slate-900">
                    <PlusIcon className="w-5 h-5" /> Cadastrar Performance
                </button>
            </div>
            
            {performances.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {performances.map(perf => (
                        <div key={perf.id} className="bg-black/20 p-4 rounded-lg border border-[var(--color-border)]">
                             <h3 className="font-bold text-lg">{perf.name} <span className="text-sm font-normal text-slate-400">({perf.category} - {perf.duration} min)</span></h3>
                             <p className="text-sm text-white/80 mt-2">{perf.description}</p>
                             {perf.technicalNeeds && <p className="text-xs text-yellow-300/80 mt-3"><strong>Necessidades Técnicas:</strong> {perf.technicalNeeds}</p>}
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16 bg-black/10 rounded-lg">
                    <TheaterIcon className="w-16 h-16 mx-auto text-slate-500 mb-4" />
                    <h3 className="text-xl font-semibold">Nenhuma performance cadastrada</h3>
                    <p className="text-slate-400 mt-2">Adicione suas performances para que organizadores de eventos possam te encontrar.</p>
                </div>
            )}
        </div>
    );
};

export default ArtistDashboard;
