import React from 'react';
import { Task, RaveEvent } from '../types.ts';
import { TaskCard } from './TaskCard.tsx';
import { ClipboardIcon } from './Icons.tsx';

interface InfluencerDashboardProps {
    tasks: Task[];
    events: RaveEvent[];
}

const InfluencerDashboard: React.FC<InfluencerDashboardProps> = ({ tasks, events }) => {
    
    const onCopyText = (text: string) => {
        navigator.clipboard.writeText(text);
        // In a real app, a toast notification would be shown here.
        // This functionality is handled by the parent `App` component.
    };

    return (
        <div className="w-full max-w-7xl">
            <h1 className="text-3xl font-bold mb-6 font-montserrat text-[var(--color-accent-primary)] flex items-center gap-3">
                <ClipboardIcon className="w-8 h-8"/> Painel de Tarefas
            </h1>
            {tasks.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {tasks.map(task => (
                        <TaskCard key={task.id} task={task} onCopyText={onCopyText} />
                    ))}
                </div>
            ) : (
                 <div className="text-center py-16 bg-black/10 rounded-lg">
                    <h3 className="text-xl font-semibold">Nenhuma tarefa disponível</h3>
                    <p className="text-slate-400 mt-2">Fique de olho, organizadores podem adicionar novas tarefas a qualquer momento.</p>
                </div>
            )}
        </div>
    );
};

export default InfluencerDashboard;
