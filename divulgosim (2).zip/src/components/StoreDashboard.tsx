import React from 'react';
import { User, Product, Order, OrderStatus } from '../types.ts';
import { PlusIcon, ShoppingCartIcon, ReceiptIcon, ShareIcon } from './Icons.tsx';

interface StoreDashboardProps {
    user: User;
    products: Product[];
    orders: Order[];
    onOpenProductModal: (product?: Product) => void;
    onShareProduct: (product: Product) => void;
    onUpdateOrder: (orderId: string, newStatus: OrderStatus) => void;
}

const StoreDashboard: React.FC<StoreDashboardProps> = ({ user, products, orders, onOpenProductModal, onShareProduct, onUpdateOrder }) => {
    
    return (
        <div className="w-full max-w-7xl">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)]">Minha Loja</h1>
                <button onClick={() => onOpenProductModal()} className="btn bg-[var(--color-accent-secondary)] text-slate-900">
                    <PlusIcon className="w-5 h-5" /> Adicionar Produto
                </button>
            </div>

            <div className="mb-8">
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><ShoppingCartIcon className="w-5 h-5"/> Meus Produtos ({products.length})</h2>
                 {products.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        {products.map(product => (
                            <div key={product.id} className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)] flex flex-col">
                                <div className="w-full h-32 bg-black/20 rounded-md mb-2 overflow-hidden">
                                    <img src={product.images[0] || 'https://via.placeholder.com/300'} alt={product.name} className="w-full h-full object-cover" />
                                </div>
                                <div className="flex-grow">
                                    <h3 className="font-bold truncate">{product.name}</h3>
                                    <p className="text-sm text-green-400">R$ {product.price.toFixed(2)}</p>
                                    <p className="text-xs text-slate-400">Estoque: {product.stock === 0 ? 'Ilimitado' : product.stock}</p>
                                </div>
                                <div className="flex gap-2 mt-3">
                                    <button onClick={() => onOpenProductModal(product)} className="w-full btn bg-slate-600 text-white !text-xs">Editar</button>
                                    <button onClick={() => onShareProduct(product)} className="btn bg-blue-600 text-white !text-xs !px-2"><ShareIcon className="w-4 h-4" /></button>
                                </div>
                            </div>
                        ))}
                    </div>
                 ) : (
                    <p className="text-center text-slate-400 py-8 bg-black/10 rounded-lg">Nenhum produto cadastrado.</p>
                 )}
            </div>

             <div>
                <h2 className="text-xl font-bold mb-4 flex items-center gap-2"><ReceiptIcon className="w-5 h-5"/> Pedidos Recebidos ({orders.length})</h2>
                {orders.length > 0 ? (
                    <div className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)]">
                        <div className="space-y-4">
                             {orders.map(order => (
                                <div key={order.id} className="p-4 bg-black/20 rounded-lg border border-slate-700/50">
                                    <div className="flex flex-col sm:flex-row justify-between sm:items-start">
                                        <div>
                                            <p className="font-bold">Pedido #{order.id.slice(-6)}</p>
                                            <p className="text-xs text-slate-400">{new Date(order.createdAt).toLocaleString('pt-BR')}</p>
                                        </div>
                                        <p className="font-bold text-green-400 text-lg mt-2 sm:mt-0">R$ {order.total.toFixed(2)}</p>
                                    </div>
                                    <div className="mt-3 text-sm space-y-1 border-t border-slate-700/50 pt-2">
                                        <p className="font-semibold text-slate-300">Itens:</p>
                                        {order.items.map(item => (
                                            <p key={item.productId} className="text-slate-400 ml-2">{item.quantity}x {item.productName}</p>
                                        ))}
                                    </div>
                                    <div className="mt-4 flex items-center justify-between">
                                        <p className="text-sm font-semibold">Status:</p>
                                        <select 
                                            value={order.status} 
                                            onChange={(e) => onUpdateOrder(order.id, e.target.value as OrderStatus)}
                                            className="form-control !py-1 !text-xs !w-auto bg-slate-700"
                                        >
                                            {Object.values(OrderStatus).map(s => <option key={s} value={s}>{s}</option>)}
                                        </select>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <p className="text-center text-slate-400 py-8 bg-black/10 rounded-lg">Nenhum pedido encontrado.</p>
                )}
            </div>
        </div>
    );
};

export default StoreDashboard;