import React, { useState, useRef } from 'react';
import { Track } from '../../types.ts';
import { PlayIcon, PauseIcon, EditIcon, TrashIcon, MusicIcon } from './Icons.tsx';

interface FaixaCardProps {
    track: Track;
    onEdit: (track: Track) => void;
    onDelete: (trackId: string) => void;
}

const FaixaCard: React.FC<FaixaCardProps> = ({ track, onEdit, onDelete }) => {
    const [isPlaying, setIsPlaying] = useState(false);
    const audioRef = useRef<HTMLAudioElement>(null);

    const togglePlayPause = () => {
        if (audioRef.current) {
            if (isPlaying) {
                audioRef.current.pause();
            } else {
                audioRef.current.play();
            }
            setIsPlaying(!isPlaying);
        }
    };
    
    const handleDelete = () => {
        if (window.confirm(`Tem certeza que deseja excluir a faixa "${track.title}"?`)) {
            onDelete(track.id);
        }
    };

    return (
        <div style={{ backgroundColor: '#1E293B', borderRadius: '12px' }} className="border border-slate-700 shadow-lg p-4 flex flex-col gap-4">
            <div className="flex items-start gap-4">
                <div className="w-24 h-24 rounded-md bg-black/20 flex-shrink-0 flex items-center justify-center overflow-hidden">
                    {track.coverUrl ? (
                        <img src={track.coverUrl} alt={track.title} className="w-full h-full object-cover"/>
                    ) : (
                        <MusicIcon className="w-12 h-12 text-slate-500" />
                    )}
                </div>
                <div className="flex-grow">
                    <h4 className="font-bold font-montserrat text-lg text-white truncate">{track.title}</h4>
                    {track.genre && <p className="text-sm text-slate-400 font-inter">{track.genre}</p>}
                    <p className="text-xs text-slate-500 mt-1 font-inter">{new Date(track.createdAt).toLocaleDateString('pt-BR')}</p>
                </div>
            </div>
            
            <audio 
                ref={audioRef} 
                src={track.url} 
                onEnded={() => setIsPlaying(false)} 
                className="hidden"
            />

            <div className="flex items-center justify-between gap-2 mt-auto">
                <button 
                    type="button"
                    onClick={togglePlayPause}
                    style={{ backgroundColor: '#FFD700', color: '#1E293B' }}
                    className="flex-grow btn font-bold"
                >
                    {isPlaying ? <PauseIcon className="w-5 h-5"/> : <PlayIcon className="w-5 h-5"/>}
                    {isPlaying ? 'Pausar' : 'Reproduzir'}
                </button>
                <button 
                    type="button"
                    onClick={() => onEdit(track)}
                    style={{ backgroundColor: '#9C27B0' }}
                    className="btn p-2.5 text-white" 
                    aria-label="Editar"
                >
                    <EditIcon className="w-5 h-5"/>
                </button>
                <button 
                    type="button"
                    onClick={handleDelete}
                    style={{ backgroundColor: '#ef4444' }}
                    className="btn p-2.5 text-white" 
                    aria-label="Excluir"
                >
                    <TrashIcon className="w-5 h-5"/>
                </button>
            </div>
        </div>
    );
};

export default FaixaCard;