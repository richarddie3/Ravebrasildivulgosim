import React, { useState, ChangeEvent, useEffect, Fragment } from 'react';
import { User, UserProfile, UserType, TicketSale, RaveEvent, Notification, RBTransaction, AppView, LEVEL_DATA, RBLevel, RealTransaction, NotificationType } from '../../types.ts';
import { 
    UserIcon as UserIconDefault, MailIcon, LockClosedIcon, SecurityShieldIcon, ChevronRightIcon,
    WalletIcon, TicketIcon, BellIcon, CogIcon, ReceiptIcon, LocationIcon, TagIcon, CalendarIcon, PlusIcon, TrashIcon,
    InstagramIcon, FacebookIcon, TikTokIcon, LinkedInIcon, YouTubeIcon, GlobeAltIcon, PaperClipIcon, InfoIcon, ExclamationTriangleIcon,
    ChevronLeftIcon,
    ArrowUpCircleIcon,
    ArrowDownCircleIcon,
    ShoppingCartIcon,
    SparklesIcon,
    ClipboardIcon,
} from './Icons.tsx';

interface ProfileViewProps {
  user: User;
  allEvents: RaveEvent[];
  ticketSales: TicketSale[];
  notifications: Notification[];
  rbTransactions: RBTransaction[];
  realTransactions: RealTransaction[];
  onUpdateUser: (user: User) => void;
  onBack: () => void;
  onOpenWithdrawal: () => void;
  onOpenRewardStore: () => void;
  onOpenChangePasswordModal: () => void;
  onOpenNotificationSettingsModal: () => void;
  onOpenDeleteAccountModal: () => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

type ProfileSection = 'personal' | 'address' | 'social' | 'medical' | 'wallet' | 'tickets' | 'history' | 'notifications' | 'settings';

const rbToCurrency = (rb: number) => (rb * 0.01).toFixed(2).replace('.', ',');

const ProfileView: React.FC<ProfileViewProps> = (props) => {
  const { user, onUpdateUser, onBack } = props;
  const [isEditMode, setIsEditMode] = useState(false);
  const [activeSection, setActiveSection] = useState<ProfileSection>('personal');
  const [formData, setFormData] = useState<UserProfile>(user.profile);
  const [roles, setRoles] = useState<UserType[]>(user.roles);
  const [currentNotifications, setCurrentNotifications] = useState<Notification[]>(props.notifications);

  useEffect(() => {
    const synchronizedProfile = {
      ...user.profile,
      medical: {
        ...user.profile.medical,
        emergencyContacts: (user.profile.medical.emergencyContacts?.length > 0 ? user.profile.medical.emergencyContacts : [{ name: '', phone: '', relationship: '' }])
          .map((c, i) => ({ ...c, id: c.id || `contact_${Date.now()}_${i}` })),
        attachedDocuments: user.profile.medical.attachedDocuments || [],
      },
    };
    setFormData(synchronizedProfile as UserProfile);
    setRoles(user.roles);
    setCurrentNotifications(props.notifications);
  }, [user, props.notifications]);

  const handleInputChange = (section: keyof UserProfile, field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...(prev[section] as any),
        [field]: value
      }
    }));
  };
  
  const handlePhotoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        const file = e.target.files[0];
        const reader = new FileReader();
        reader.onloadend = () => {
            handleInputChange('personal', 'profilePicture', reader.result as string);
        };
        reader.readAsDataURL(file);
    }
  };

    const handleEmergencyContactChange = (index: number, field: string, value: string) => {
        setFormData(prev => {
            const newContacts = [...prev.medical.emergencyContacts];
            newContacts[index] = { ...newContacts[index], [field]: value };
            return {
                ...prev,
                medical: {
                    ...prev.medical,
                    emergencyContacts: newContacts,
                }
            };
        });
    };

    const addEmergencyContact = () => {
        setFormData(prev => ({
            ...prev,
            medical: {
                ...prev.medical,
                emergencyContacts: [
                    ...prev.medical.emergencyContacts,
                    { id: `contact_${Date.now()}`, name: '', phone: '', relationship: '' }
                ],
            }
        }));
    };

    const removeEmergencyContact = (id: string | number) => {
        setFormData(prev => ({
            ...prev,
            medical: {
                ...prev.medical,
                emergencyContacts: prev.medical.emergencyContacts.length > 1 
                    ? prev.medical.emergencyContacts.filter(c => c.id !== id)
                    : [{ id: `contact_new_${Date.now()}`, name: '', phone: '', relationship: '' }],
            }
        }));
    };

  const handleRoleChange = (role: UserType, isChecked: boolean) => {
    setRoles(prevRoles => {
        if (isChecked) {
            if (!prevRoles.includes(role)) return [...prevRoles, role];
        } else {
            if (prevRoles.length > 1) return prevRoles.filter(r => r !== role);
        }
        return prevRoles;
    });
  };

  const handleSaveChanges = () => {
    const finalContacts = formData.medical.emergencyContacts.filter(c => c.name.trim() !== '').map(({ id, ...rest }) => rest);
    const updatedProfile = {
        ...formData,
        medical: { ...formData.medical, emergencyContacts: finalContacts, lastUpdated: new Date().toISOString() }
    };
    onUpdateUser({ ...user, profile: updatedProfile, roles });
    setIsEditMode(false);
  };
  
  const handleNotificationClick = (id: string) => {
        setCurrentNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n));
  };
    
  const handleMarkAllAsRead = () => {
        setCurrentNotifications(prev => prev.map(n => ({ ...n, isRead: true })));
  };

  const getNotificationIcon = (type: NotificationType) => {
      switch (type) {
          case NotificationType.ALERT: return <ExclamationTriangleIcon className="w-6 h-6 text-yellow-400" />;
          case NotificationType.REQUEST: return <UserIconDefault className="w-6 h-6 text-blue-400" />;
          case NotificationType.INVITE: return <MailIcon className="w-6 h-6 text-purple-400" />;
          default: return <InfoIcon className="w-6 h-6 text-gray-400" />;
      }
  };

  const renderContent = () => {
      switch (activeSection) {
        case 'personal':
          return (
            <div>
              <h3 className="text-xl font-bold mb-4">Dados Pessoais</h3>
              {isEditMode ? (
                <div className="space-y-4">
                   <div className="flex items-center gap-4">
                       <img src={formData.personal.profilePicture || 'https://via.placeholder.com/100'} alt="Foto de Perfil" className="w-24 h-24 rounded-full object-cover"/>
                       <input type="file" accept="image/*" onChange={handlePhotoUpload} className="form-control" />
                   </div>
                  <input className="form-control" value={formData.personal.fullName} onChange={(e) => handleInputChange('personal', 'fullName', e.target.value)} placeholder="Nome Completo" />
                  <input className="form-control" value={formData.personal.username} onChange={(e) => handleInputChange('personal', 'username', e.target.value)} placeholder="Nome de usuário" />
                   <div className="grid grid-cols-2 gap-4">
                     <input className="form-control" type="date" value={formData.personal.birthDate} onChange={(e) => handleInputChange('personal', 'birthDate', e.target.value)} placeholder="Data de Nascimento" />
                     <input className="form-control" value={formData.personal.phone} onChange={(e) => handleInputChange('personal', 'phone', e.target.value)} placeholder="Telefone" />
                   </div>
                  <div className="grid grid-cols-2 gap-4">
                     <input className="form-control" value={formData.personal.cpf} onChange={(e) => handleInputChange('personal', 'cpf', e.target.value)} placeholder="CPF" />
                     <input className="form-control" value={formData.personal.rg} onChange={(e) => handleInputChange('personal', 'rg', e.target.value)} placeholder="RG" />
                  </div>
                   <div>
                       <h4 className="font-bold my-2">Funções na Plataforma</h4>
                       <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                           {Object.values(UserType).map(role => (
                               <label key={role} className={`p-2 rounded-md border flex items-center gap-2 cursor-pointer ${roles.includes(role) ? 'bg-yellow-400/20 border-yellow-400' : 'bg-black/20 border-slate-700'}`}>
                                   <input type="checkbox" checked={roles.includes(role)} onChange={e => handleRoleChange(role, e.target.checked)} className="form-checkbox rounded text-yellow-500 bg-slate-800 border-slate-600 focus:ring-yellow-500" disabled={role === UserType.USER} />
                                   <span className="text-sm">{role}</span>
                               </label>
                           ))}
                       </div>
                   </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <p><strong>Nome:</strong> {user.profile.personal.fullName}</p>
                  <p><strong>Email:</strong> {user.email}</p>
                  <p><strong>Funções:</strong> {user.roles.join(', ')}</p>
                </div>
              )}
            </div>
          );
        case 'address':
            return (
                <div>
                  <h3 className="text-xl font-bold mb-4">Endereço</h3>
                  {isEditMode ? (
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <input className="form-control col-span-1" value={formData.address.cep} onChange={(e) => handleInputChange('address', 'cep', e.target.value)} placeholder="CEP" />
                        <input className="form-control col-span-2" value={formData.address.street} onChange={(e) => handleInputChange('address', 'street', e.target.value)} placeholder="Rua / Logradouro" />
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                        <input className="form-control" value={formData.address.number} onChange={(e) => handleInputChange('address', 'number', e.target.value)} placeholder="Número" />
                        <input className="form-control col-span-2" value={formData.address.complement} onChange={(e) => handleInputChange('address', 'complement', e.target.value)} placeholder="Complemento" />
                      </div>
                      <input className="form-control" value={formData.address.neighborhood} onChange={(e) => handleInputChange('address', 'neighborhood', e.target.value)} placeholder="Bairro" />
                      <div className="grid grid-cols-2 gap-4">
                        <input className="form-control" value={formData.address.city} onChange={(e) => handleInputChange('address', 'city', e.target.value)} placeholder="Cidade" />
                        <input className="form-control" value={formData.address.state} onChange={(e) => handleInputChange('address', 'state', e.target.value)} placeholder="Estado" />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2 text-sm">
                      <p><strong>CEP:</strong> {user.profile.address.cep || 'Não informado'}</p>
                      <p><strong>Endereço:</strong> {`${user.profile.address.street || ''}, ${user.profile.address.number || ''} - ${user.profile.address.neighborhood || ''}`}</p>
                      <p><strong>Complemento:</strong> {user.profile.address.complement || 'Não informado'}</p>
                      <p><strong>Cidade/Estado:</strong> {`${user.profile.address.city || ''} - ${user.profile.address.state || ''}`}</p>
                    </div>
                  )}
                </div>
              );
        case 'social':
             return (
                <div>
                  <h3 className="text-xl font-bold mb-4">Redes Sociais</h3>
                  {isEditMode ? (
                    <div className="space-y-4">
                      <div className="relative flex items-center"><InstagramIcon className="absolute left-3 w-5 h-5 text-gray-400" /><input className="form-control pl-10" value={formData.social.instagram} onChange={(e) => handleInputChange('social', 'instagram', e.target.value)} placeholder="URL do Instagram" /></div>
                      <div className="relative flex items-center"><FacebookIcon className="absolute left-3 w-5 h-5" /><input className="form-control pl-10" value={formData.social.facebook} onChange={(e) => handleInputChange('social', 'facebook', e.target.value)} placeholder="URL do Facebook" /></div>
                      <div className="relative flex items-center"><TikTokIcon className="absolute left-3 w-5 h-5" /><input className="form-control pl-10" value={formData.social.tiktok} onChange={(e) => handleInputChange('social', 'tiktok', e.target.value)} placeholder="URL do TikTok" /></div>
                      <div className="relative flex items-center"><LinkedInIcon className="absolute left-3 w-5 h-5" /><input className="form-control pl-10" value={formData.social.linkedin} onChange={(e) => handleInputChange('social', 'linkedin', e.target.value)} placeholder="URL do LinkedIn" /></div>
                      <div className="relative flex items-center"><YouTubeIcon className="absolute left-3 w-5 h-5" /><input className="form-control pl-10" value={formData.social.youtube} onChange={(e) => handleInputChange('social', 'youtube', e.target.value)} placeholder="URL do YouTube" /></div>
                      <div className="relative flex items-center"><GlobeAltIcon className="absolute left-3 w-5 h-5 text-gray-400" /><input className="form-control pl-10" value={formData.social.website} onChange={(e) => handleInputChange('social', 'website', e.target.value)} placeholder="Website Pessoal" /></div>
                    </div>
                  ) : (
                     <div className="space-y-3">
                        {Object.entries(user.profile.social).map(([key, value]) => value && (
                            <a key={key} href={value as string} target="_blank" rel="noopener noreferrer" className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors">
                                {key === 'instagram' && <InstagramIcon className="w-6 h-6" />}
                                {key === 'facebook' && <FacebookIcon className="w-6 h-6" />}
                                {key === 'tiktok' && <TikTokIcon className="w-6 h-6" />}
                                {key === 'linkedin' && <LinkedInIcon className="w-6 h-6" />}
                                {key === 'youtube' && <YouTubeIcon className="w-6 h-6" />}
                                {key === 'website' && <GlobeAltIcon className="w-6 h-6" />}
                                <span className="truncate text-sm text-blue-300">{value}</span>
                            </a>
                        ))}
                     </div>
                  )}
                </div>
              );
        case 'medical':
            return (
                <div>
                  <h3 className="text-xl font-bold mb-4">Ficha Médica</h3>
                  {isEditMode ? (
                     <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <input className="form-control" value={formData.medical.bloodType} onChange={(e) => handleInputChange('medical', 'bloodType', e.target.value)} placeholder="Tipo Sanguíneo" />
                            <input className="form-control" value={formData.medical.allergies} onChange={(e) => handleInputChange('medical', 'allergies', e.target.value)} placeholder="Alergias" />
                        </div>
                        <div>
                            <h4 className="font-bold mb-2">Contatos de Emergência</h4>
                            {formData.medical.emergencyContacts.map((contact, index) => (
                                <div key={contact.id} className="grid grid-cols-1 md:grid-cols-7 gap-2 items-center mb-2 bg-black/20 p-2 rounded-md">
                                    <input className="form-control md:col-span-3" value={contact.name} onChange={(e) => handleEmergencyContactChange(index, 'name', e.target.value)} placeholder="Nome do Contato" />
                                    <input className="form-control md:col-span-2" value={contact.phone} onChange={(e) => handleEmergencyContactChange(index, 'phone', e.target.value)} placeholder="Telefone" />
                                    <input className="form-control md:col-span-1" value={contact.relationship} onChange={(e) => handleEmergencyContactChange(index, 'relationship', e.target.value)} placeholder="Parentesco" />
                                    <button type="button" onClick={() => removeEmergencyContact(contact.id!)} className="p-2 text-red-400 hover:bg-red-400/10 rounded-md disabled:opacity-50" disabled={formData.medical.emergencyContacts.length <= 1}><TrashIcon className="w-5 h-5"/></button>
                                </div>
                            ))}
                            <button type="button" onClick={addEmergencyContact} className="mt-2 text-sm flex items-center gap-1 text-blue-400 hover:text-blue-300"><PlusIcon className="w-4 h-4"/> Adicionar Contato</button>
                        </div>
                     </div>
                  ) : (
                    <div className="space-y-4 text-sm">
                        <div>
                            <p><strong>Tipo Sanguíneo:</strong> {user.profile.medical.bloodType || 'Não informado'}</p>
                            <p><strong>Alergias:</strong> {user.profile.medical.allergies || 'Nenhuma informada'}</p>
                        </div>
                        <div>
                            <h4 className="font-semibold text-base mb-2">Contatos de Emergência</h4>
                            {(user.profile.medical.emergencyContacts?.length > 0 && user.profile.medical.emergencyContacts[0].name) ? user.profile.medical.emergencyContacts?.map((contact, index) => (
                                <div key={index} className="p-2 bg-black/20 rounded-md mb-2">
                                    <p><strong>{contact.name}</strong> ({contact.relationship}) - {contact.phone}</p>
                                </div>
                            )) : <p>Nenhum contato de emergência cadastrado.</p>}
                        </div>
                    </div>
                  )}
                </div>
              );
        case 'wallet':
            const currentLevel = LEVEL_DATA[user.rbLevel];
            const nextLevelKey = Object.keys(LEVEL_DATA).find(key => LEVEL_DATA[key as RBLevel].min > currentLevel.min);
            const nextLevel = nextLevelKey ? LEVEL_DATA[nextLevelKey as RBLevel] : null;
            const progressPercentage = nextLevel ? ((user.rbBalance - currentLevel.min) / (nextLevel.min - currentLevel.min)) * 100 : 100;

            return (
                <div>
                    <h3 className="text-xl font-bold mb-4">Carteira</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-black/30 p-4 rounded-lg text-center">
                            <p className="text-sm text-slate-400">Saldo em Reais</p>
                            <p className="text-3xl font-bold text-green-400">R$ {user.realBalance.toFixed(2).replace('.', ',')}</p>
                        </div>
                         <div className="bg-black/30 p-4 rounded-lg text-center">
                            <p className="text-sm text-slate-400">Saldo RB</p>
                            <p className="text-3xl font-bold text-yellow-300">💎 {user.rbBalance.toLocaleString('pt-BR')}</p>
                        </div>
                    </div>
                     <div className="mt-6 bg-black/30 p-4 rounded-lg">
                        <div className="flex justify-between items-center text-sm font-bold">
                            <span className="text-yellow-300">{currentLevel.name}</span>
                            {nextLevel && <span className="text-slate-400">Próximo Nível: {nextLevel.name}</span>}
                        </div>
                        <div className="w-full bg-slate-700 rounded-full h-2.5 mt-2">
                            <div className="bg-yellow-400 h-2.5 rounded-full" style={{width: `${progressPercentage}%`}}></div>
                        </div>
                        <p className="text-xs text-slate-500 text-right mt-1">{user.rbBalance.toLocaleString('pt-BR')} / {nextLevel ? nextLevel.min.toLocaleString('pt-BR') : ''} RB</p>
                    </div>
                     <div className="mt-6 flex gap-4">
                        <button onClick={props.onOpenWithdrawal} className="btn-save w-full">Sacar</button>
                        <button onClick={props.onOpenRewardStore} className="btn bg-purple-600 text-white w-full">Loja de Recompensas</button>
                    </div>
                </div>
            );
        case 'tickets':
             const userSales = props.ticketSales.filter(sale => sale.buyerId === user.id);
             return (
                <div>
                    <h3 className="text-xl font-bold mb-4">Meus Ingressos</h3>
                    {userSales.length > 0 ? (
                        <div className="space-y-4">
                            {userSales.map(sale => {
                                const event = props.allEvents.find(e => e.id === sale.eventId);
                                return (
                                    <div key={sale.id} className="bg-black/30 p-4 rounded-lg flex justify-between items-center">
                                        <div>
                                            <p className="font-bold">{sale.quantity}x {sale.ticketName}</p>
                                            <p className="text-sm text-slate-300">{event?.name || 'Evento desconhecido'}</p>
                                            <p className="text-xs text-slate-400">{event?.dateString}</p>
                                        </div>
                                        <button className="btn-save !bg-blue-600">Ver QR Code</button>
                                    </div>
                                );
                            })}
                        </div>
                    ) : <p className="text-slate-400">Você ainda não comprou nenhum ingresso.</p>}
                </div>
             );
        case 'history':
                const getTransactionIcon = (type: RBTransaction['type'] | RealTransaction['type']) => {
                    switch (type) {
                        case 'deposit': return <ArrowUpCircleIcon className="w-6 h-6 text-green-400" />;
                        case 'purchase': return <ShoppingCartIcon className="w-6 h-6 text-red-400" />;
                        case 'withdrawal':
                        case 'withdraw-request':
                        case 'withdraw-fee': return <ArrowDownCircleIcon className="w-6 h-6 text-red-400" />;
                        case 'earn-task': return <ClipboardIcon className="w-6 h-6 text-green-400" />;
                        case 'redeem-item': return <TagIcon className="w-6 h-6 text-red-400" />;
                        case 'achievement': return <SparklesIcon className="w-6 h-6 text-yellow-400" />;
                        case 'daily-mission': return <CalendarIcon className="w-6 h-6 text-blue-400" />;
                        default: return <WalletIcon className="w-6 h-6 text-gray-400" />;
                    }
                };
                
                const getStatusBadge = (status: 'completed' | 'pending' | 'rejected') => {
                    const styles = {
                        completed: 'bg-green-500/20 text-green-300',
                        pending: 'bg-yellow-500/20 text-yellow-300',
                        rejected: 'bg-red-500/20 text-red-300',
                    };
                    return <span className={`text-xs font-bold px-2 py-1 rounded-full ${styles[status]}`}>{status}</span>;
                };

                return (
                    <div className="space-y-8">
                        <div>
                            <h3 className="text-xl font-bold mb-4">Transações em Reais (R$)</h3>
                            {props.realTransactions.length > 0 ? (
                                <div className="space-y-3">
                                    {props.realTransactions.map(tx => (
                                        <div key={tx.id} className="bg-black/20 p-3 rounded-lg flex items-center gap-4">
                                            {getTransactionIcon(tx.type)}
                                            <div className="flex-grow">
                                                <p className="font-semibold">{tx.description}</p>
                                                <p className="text-xs text-slate-400">{new Date(tx.timestamp).toLocaleString('pt-BR')}</p>
                                            </div>
                                            <div className="text-right">
                                                <p className={`font-bold ${tx.amount > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                                    {tx.amount > 0 ? '+' : '-'} R$ {Math.abs(tx.amount).toFixed(2).replace('.', ',')}
                                                </p>
                                                {getStatusBadge(tx.status)}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : <p className="text-slate-400">Nenhuma transação em Reais encontrada.</p>}
                        </div>
                        <div>
                            <h3 className="text-xl font-bold mb-4">Transações de RB (💎)</h3>
                            {props.rbTransactions.length > 0 ? (
                                <div className="space-y-3">
                                    {props.rbTransactions.map(tx => (
                                        <div key={tx.id} className="bg-black/20 p-3 rounded-lg flex items-center gap-4">
                                            {getTransactionIcon(tx.type)}
                                            <div className="flex-grow">
                                                <p className="font-semibold">{tx.description}</p>
                                                <p className="text-xs text-slate-400">{new Date(tx.timestamp).toLocaleString('pt-BR')}</p>
                                            </div>
                                            <div className="text-right">
                                                <p className={`font-bold ${tx.amountRB > 0 ? 'text-green-400' : 'text-red-400'}`}>
                                                    {tx.amountRB > 0 ? '+' : ''} {tx.amountRB.toLocaleString('pt-BR')} RB
                                                </p>
                                                 {getStatusBadge(tx.status)}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : <p className="text-slate-400">Nenhuma transação de RB encontrada.</p>}
                        </div>
                    </div>
                );
        case 'notifications':
             return (
                 <div>
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-xl font-bold">Notificações</h3>
                        <button onClick={handleMarkAllAsRead} className="text-sm text-blue-400 hover:underline">Marcar todas como lidas</button>
                    </div>
                     {currentNotifications.length > 0 ? (
                        <div className="space-y-3">
                            {currentNotifications.map(n => (
                                <div key={n.id} onClick={() => handleNotificationClick(n.id)} className={`p-3 rounded-lg flex items-start gap-3 cursor-pointer transition-colors ${n.isRead ? 'bg-black/20' : 'bg-blue-500/10 border border-blue-400/50'}`}>
                                    <div className="flex-shrink-0 mt-1">{getNotificationIcon(n.type)}</div>
                                    <div className="flex-grow">
                                        <p className={`font-semibold ${!n.isRead && 'text-white'}`}>{n.message}</p>
                                        <p className="text-xs text-slate-400">{new Date(n.createdAt).toLocaleString('pt-BR')}</p>
                                    </div>
                                    {!n.isRead && <div className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"></div>}
                                </div>
                            ))}
                        </div>
                     ) : <p className="text-slate-400">Nenhuma notificação nova.</p>}
                 </div>
             );
        case 'settings':
             return (
                 <div>
                    <h3 className="text-xl font-bold mb-4">Configurações da Conta</h3>
                     <div className="space-y-3">
                        <button onClick={props.onOpenChangePasswordModal} className="w-full text-left p-4 bg-black/20 rounded-lg hover:bg-white/5 flex justify-between items-center">
                            <span>Alterar Senha</span>
                            <ChevronRightIcon className="w-5 h-5" />
                        </button>
                        <button onClick={props.onOpenNotificationSettingsModal} className="w-full text-left p-4 bg-black/20 rounded-lg hover:bg-white/5 flex justify-between items-center">
                            <span>Notificações</span>
                            <ChevronRightIcon className="w-5 h-5" />
                        </button>
                        <button onClick={props.onOpenDeleteAccountModal} className="w-full text-left p-4 bg-black/20 rounded-lg hover:bg-red-500/10 text-red-400 flex justify-between items-center">
                            <span>Excluir Conta</span>
                            <ChevronRightIcon className="w-5 h-5" />
                        </button>
                     </div>
                 </div>
             );
        default:
          return null;
      }
  };
    
    const menuItems: { id: ProfileSection; label: string; icon: React.FC<any> }[] = [
        { id: 'personal', label: 'Dados Pessoais', icon: UserIconDefault },
        { id: 'address', label: 'Endereço', icon: LocationIcon },
        { id: 'social', label: 'Redes Sociais', icon: GlobeAltIcon },
        { id: 'medical', label: 'Ficha Médica', icon: SecurityShieldIcon },
        { id: 'wallet', label: 'Carteira', icon: WalletIcon },
        { id: 'tickets', label: 'Meus Ingressos', icon: TicketIcon },
        { id: 'history', label: 'Histórico', icon: ReceiptIcon },
        { id: 'notifications', label: 'Notificações', icon: BellIcon },
        { id: 'settings', label: 'Configurações', icon: CogIcon },
    ];

    return (
        <div className="w-full max-w-7xl">
            <header className="flex items-center gap-4 mb-6">
                 <button onClick={onBack} className="p-2 rounded-full hover:bg-white/10 transition-colors">
                    <ChevronLeftIcon className="w-6 h-6"/>
                </button>
                <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)]">Meu Perfil</h1>
                <div className="ml-auto">
                    {activeSection !== 'history' && activeSection !== 'wallet' && activeSection !== 'tickets' && activeSection !== 'notifications' && activeSection !== 'settings' && (
                         isEditMode ? (
                            <div className="flex gap-2">
                                 <button onClick={() => setIsEditMode(false)} className="btn-cancel">Cancelar</button>
                                 <button onClick={handleSaveChanges} className="btn-save">Salvar Alterações</button>
                            </div>
                        ) : (
                            <button onClick={() => setIsEditMode(true)} className="btn bg-[var(--color-accent-secondary)] text-slate-900">
                                Editar Perfil
                            </button>
                        )
                    )}
                </div>
            </header>
            
            <div className="flex flex-col md:flex-row gap-8">
                <aside className="w-full md:w-1/4">
                    <div className="bg-black/20 p-3 rounded-lg border border-[var(--color-border)] space-y-1">
                        {menuItems.map(item => (
                            <button 
                                key={item.id}
                                onClick={() => setActiveSection(item.id)}
                                className={`w-full flex items-center gap-3 p-3 rounded-md text-left transition-colors ${activeSection === item.id ? 'bg-white/10 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-white'}`}
                            >
                                <item.icon className="w-5 h-5" />
                                <span className="font-semibold">{item.label}</span>
                            </button>
                        ))}
                    </div>
                </aside>
                
                <main className="flex-grow w-full md:w-3/4 bg-black/20 p-6 rounded-lg border border-[var(--color-border)]">
                    {renderContent()}
                </main>
            </div>
        </div>
    );
};

export default ProfileView;