import React from 'react';
import { User, Track, GigProposal, DJStats, RaveEvent } from '../../types.ts';
import { PlusIcon } from './Icons.tsx';
import FaixaCard from './FaixaCard.tsx';
import PropostaCard from './PropostaCard.tsx';
import { default as DJStatsPanel } from './DJStats.tsx';

interface DJDashboardProps {
    user: User;
    tracks: Track[];
    proposals: GigProposal[];
    allUsers: User[];
    allEvents: RaveEvent[];
    onOpenUploadModal: (track?: Track) => void;
    onDeleteTrack: (trackId: string) => void;
    onUpdateProposal: (proposalId: string, status: 'accepted' | 'rejected') => void;
}

const DJDashboard: React.FC<DJDashboardProps> = ({ 
    user, tracks, proposals, allUsers, allEvents, 
    onOpenUploadModal, onDeleteTrack, onUpdateProposal 
}) => {
    
    // Mock stats for now, in a real app this would come from props/API
    const stats: DJStats = {
        trackCount: tracks.length,
        monthlyListeners: 1800, // mock
        eventsPlayed: proposals.filter(p => p.status === 'accepted').length, // mock
    };
    
    const pendingProposals = proposals.filter(p => p.status === 'pending');
    const historicalProposals = proposals.filter(p => p.status !== 'pending');

    return (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-2xl font-bold text-[var(--color-accent-primary)]">Painel do DJ</h2>
                    <button 
                        onClick={() => onOpenUploadModal()}
                        style={{ backgroundColor: '#FFD700', color: '#1E293B' }}
                        className="btn font-bold"
                    >
                        <PlusIcon className="w-5 h-5" /> Enviar Nova Faixa/Mix
                    </button>
                </div>

                {/* Proposals Section */}
                {pendingProposals.length > 0 && (
                    <div className="mb-8">
                        <h3 className="text-xl font-semibold mb-4">📩 Propostas de Eventos para Você</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {pendingProposals.map(proposal => (
                                <PropostaCard 
                                    key={proposal.id}
                                    proposal={proposal}
                                    event={allEvents.find(e => e.id === proposal.eventId)}
                                    organizer={allUsers.find(u => u.id === proposal.organizerId)}
                                    onUpdateProposal={onUpdateProposal}
                                />
                            ))}
                        </div>
                    </div>
                )}

                {/* Historical Proposals Section */}
                {historicalProposals.length > 0 && (
                    <div className="mb-8">
                        <h3 className="text-xl font-semibold mb-4">🎉 Eventos com Minhas Faixas</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {historicalProposals.map(proposal => {
                                const event = allEvents.find(e => e.id === proposal.eventId);
                                if (!event) return null;
                                const statusIcon = proposal.status === 'accepted' ? '✅' : '❌';
                                const statusText = proposal.status === 'accepted' ? 'Confirmada' : 'Rejeitada';
                                const statusColor = proposal.status === 'accepted' ? 'text-green-400' : 'text-red-400';

                                return (
                                    <div key={proposal.id} style={{ backgroundColor: '#1E293B', borderRadius: '12px' }} className="border border-slate-700 shadow-md p-4 flex flex-col gap-3">
                                        <div>
                                            <h4 className="font-bold font-montserrat text-lg text-white">{event.name}</h4>
                                            <p className="text-sm text-slate-400">{event.dateString}</p>
                                            <p className="text-sm text-slate-500 mt-1">{event.location}</p>
                                            <p className={`text-sm mt-2 font-semibold ${statusColor}`}>
                                                Status: {statusIcon} {statusText}
                                            </p>
                                        </div>
                                        <button className="btn bg-slate-600 hover:bg-slate-500 text-white w-full !text-sm mt-auto">
                                            Ver Detalhes do Evento
                                        </button>
                                    </div>
                                )
                            })}
                        </div>
                    </div>
                )}

                {/* Tracks Section */}
                <div>
                     <h3 className="text-xl font-semibold mb-4">🎶 Minhas Faixas e Mixes</h3>
                    {tracks.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {tracks.map(track => (
                                <FaixaCard 
                                    key={track.id} 
                                    track={track} 
                                    onEdit={() => onOpenUploadModal(track)}
                                    onDelete={onDeleteTrack}
                                />
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-16 bg-black/10 rounded-lg">
                            <p className="text-slate-400">Nenhuma faixa enviada ainda.</p>
                            <p className="text-slate-500 text-sm mt-2">Clique em "Enviar Nova Faixa/Mix" para começar.</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Stats Sidebar */}
            <aside className="lg:col-span-1">
                <DJStatsPanel stats={stats} user={user} />
            </aside>
        </div>
    );
};

export default DJDashboard;