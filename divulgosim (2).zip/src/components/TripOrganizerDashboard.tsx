import React from 'react';
import { User, Excursion, Passenger, RaveEvent } from '../types.ts';
import { PlusIcon, BusIcon } from './Icons.tsx';

interface ExcursionsViewProps {
    user: User;
    excursions: Excursion[];
    passengers: Passenger[];
    events: RaveEvent[];
    onCreateExcursion: () => void;
    onEditExcursion: (excursion: Excursion) => void;
}

const ExcursionsView: React.FC<ExcursionsViewProps> = ({ user, excursions, passengers, events, onCreateExcursion, onEditExcursion }) => {
    const myExcursions = excursions.filter(ex => ex.tripOrganizerId === user.id);

    const statusClasses: Record<Excursion['status'], string> = {
        'ativo': 'bg-green-500/20 text-green-300',
        'em andamento': 'bg-blue-500/20 text-blue-300',
        'finalizado': 'bg-slate-500/20 text-slate-400',
    };

    return (
        <div className="w-full max-w-7xl">
            <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold font-montserrat text-[var(--color-accent-primary)]">Minhas Excursões</h1>
                <button onClick={onCreateExcursion} className="btn bg-[var(--color-accent-secondary)] text-slate-900">
                    <PlusIcon className="w-5 h-5" /> Criar Nova Excursão
                </button>
            </div>
            {myExcursions.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {myExcursions.map(ex => {
                        const event = events.find(e => e.id === ex.eventId);
                        const passengerCount = passengers.filter(p => p.excursionId === ex.id).length;
                        return (
                            <div key={ex.id} className="bg-black/20 p-4 rounded-lg border border-[var(--color-border)] flex flex-col gap-3">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <h3 className="font-bold text-lg">{ex.name}</h3>
                                        <p className="text-sm text-slate-400">Para: {event?.name || 'Evento não encontrado'}</p>
                                    </div>
                                    <span className={`capitalize text-xs font-semibold px-2 py-1 rounded-full ${statusClasses[ex.status] || ''}`}>
                                        {ex.status}
                                    </span>
                                </div>
                                <div className="grid grid-cols-3 gap-2 text-center text-sm">
                                    <div className="bg-black/30 p-2 rounded-md">
                                        <p className="font-bold">{passengerCount} / {ex.capacity}</p>
                                        <p className="text-xs text-slate-400">Passageiros</p>
                                    </div>
                                    <div className="bg-black/30 p-2 rounded-md">
                                        <p className="font-bold">R$ {ex.price.toFixed(2)}</p>
                                        <p className="text-xs text-slate-400">Preço</p>
                                    </div>
                                     <div className="bg-black/30 p-2 rounded-md">
                                        <p className="font-bold">{ex.vehicleType}</p>
                                        <p className="text-xs text-slate-400">Veículo</p>
                                    </div>
                                </div>
                                 <div className="flex-grow"></div>
                                <div className="flex gap-2 mt-2">
                                    <button className="btn bg-blue-600 text-white w-full !text-sm">Gerenciar</button>
                                    <button onClick={() => onEditExcursion(ex)} className="btn bg-slate-600 text-white w-full !text-sm">Editar</button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                 <div className="text-center py-16 bg-black/10 rounded-lg">
                    <BusIcon className="w-16 h-16 mx-auto text-slate-500 mb-4" />
                    <h3 className="text-xl font-semibold">Nenhuma excursão criada</h3>
                    <p className="text-slate-400 mt-2">Clique em "Criar Nova Excursão" para começar.</p>
                </div>
            )}
        </div>
    );
};

export default ExcursionsView;