import React from 'react';
import { Task, SocialPlatform } from '../../types.ts';
import { InstagramIcon, FacebookIcon, TikTokIcon, XIcon, PaperClipIcon, SaveIcon, ClipboardCopyIcon } from './Icons.tsx';

interface TaskCardProps {
    task: Task;
    onCopyText: (text: string) => void;
}

const platformIcons: Record<SocialPlatform, React.ReactNode> = {
    [SocialPlatform.INSTAGRAM]: <InstagramIcon className="w-5 h-5" />,
    [SocialPlatform.FACEBOOK]: <FacebookIcon className="w-5 h-5" />,
    [SocialPlatform.TIKTOK]: <TikTokIcon className="w-5 h-5" />,
    [SocialPlatform.X]: <XIcon className="w-5 h-5" />,
};

export const TaskCard: React.FC<TaskCardProps> = ({ task, onCopyText }) => {

    const handleCardClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
        // Prevent card navigation if a button was clicked
        if ((e.target as HTMLElement).closest('button, a[download]')) {
            e.preventDefault();
        }
    };
    
    return (
        <a 
            href={task.link || '#'} 
            target="_blank" 
            rel="noopener noreferrer"
            onClick={handleCardClick}
            className="bg-[var(--color-bg-secondary)] border border-[var(--color-border)] rounded-xl p-4 flex flex-col gap-3 transition-all hover:border-[var(--color-accent-primary)] hover:-translate-y-1 group"
        >
            <div className="flex justify-between items-start">
                <h3 className="font-bold text-lg text-white group-hover:text-[var(--color-accent-primary)] pr-2">{task.title}</h3>
                {task.rewardRB && (
                    <div className="flex-shrink-0 font-bold text-yellow-300 bg-yellow-400/10 px-2 py-1 rounded-full text-sm">
                        💎 {task.rewardRB} RB
                    </div>
                )}
            </div>

            {task.description && <p className="text-sm text-[var(--color-text-secondary)]">{task.description}</p>}
            
            <div className="flex-grow"></div> {/* Spacer */}

            <div className="flex flex-wrap items-center gap-2 text-xs text-[var(--color-text-secondary)]">
                {task.platform && (
                     <div className="flex items-center gap-1.5 bg-black/20 px-2 py-1 rounded-md">
                        {platformIcons[task.platform]}
                        <span>{task.platform}</span>
                        {task.placement && <span>/ {task.placement}</span>}
                    </div>
                )}
                 <div className="flex items-center gap-1.5 bg-black/20 px-2 py-1 rounded-md">
                    <span>Prazo: {new Date(task.deadline).toLocaleDateString('pt-BR', { timeZone: 'UTC' })}</span>
                </div>
            </div>

            <div className="mt-2 pt-3 border-t border-[var(--color-border)] flex flex-wrap gap-2">
                {task.media && (
                     <a 
                        href={task.media.url} 
                        download={task.media.name}
                        className="btn bg-blue-600 text-white !text-xs !py-1 !px-3 hover:bg-blue-500"
                        title="Baixar mídia"
                     >
                        <SaveIcon className="w-4 h-4" /> Baixar Mídia
                    </a>
                )}
                 {task.description && (
                     <button 
                        onClick={() => onCopyText(task.description)}
                        className="btn bg-gray-600 text-white !text-xs !py-1 !px-3 hover:bg-gray-500"
                        title="Copiar texto da descrição"
                     >
                        <ClipboardCopyIcon className="w-4 h-4" /> Copiar Texto
                    </button>
                )}
                 {task.link && (
                     <span className="btn bg-green-600 text-white !text-xs !py-1 !px-3 hover:bg-green-500 cursor-pointer">
                        <PaperClipIcon className="w-4 h-4" /> Ir para o Link
                    </span>
                )}
            </div>
        </a>
    );
};