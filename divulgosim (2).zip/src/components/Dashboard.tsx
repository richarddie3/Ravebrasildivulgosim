import React from 'react';

// This component is deprecated and its logic has been split into role-specific dashboards
// (e.g., StoreDashboard, PhotographerDashboard, etc.). It is no longer used in the app.
const Dashboard: React.FC = () => {
  return null;
};

export default Dashboard;
