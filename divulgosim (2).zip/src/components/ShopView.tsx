import React, { useState, useMemo } from 'react';
import { Product, ProductCategory, User, UserType } from '../types.ts';
import { ShoppingCartIcon, PlusIcon } from './Icons.tsx';

interface ShopViewProps {
    products: Product[];
    onAddToCart: (product: Product) => void;
    currentUser: User | null;
    onOpenProductModal: () => void;
    onViewProduct: (product: Product) => void;
}

const ShopView: React.FC<ShopViewProps> = ({ products, onAddToCart, currentUser, onOpenProductModal, onViewProduct }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'all'>('all');

    const isStoreOwner = currentUser?.roles.includes(UserType.STORE_OWNER);

    const filteredProducts = useMemo(() => {
        let userProducts = products;
        // If store owner, show only their products
        if (isStoreOwner && currentUser) {
            userProducts = products.filter(p => p.storeOwnerId === currentUser.id);
        }
        
        return userProducts.filter(product => {
            const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
            const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [products, searchTerm, selectedCategory, isStoreOwner, currentUser]);
    
    const categories = Object.values(ProductCategory);

    return (
        <div className="w-full max-w-7xl">
            <header className="mb-8 text-center">
                {isStoreOwner ? (
                    <>
                        <h1 className="text-4xl font-bold font-montserrat text-[var(--color-accent-primary)]">Sua Vitrine</h1>
                        <p className="text-[var(--color-text-secondary)] mt-2 mb-6">Gerencie os produtos da sua loja e veja como eles aparecem para os clientes.</p>
                        <button 
                            onClick={onOpenProductModal}
                            className="btn bg-[var(--color-accent-secondary)] text-slate-900 !py-2 !px-5 text-base"
                        >
                            <PlusIcon className="w-5 h-5" /> Adicionar Novo Produto
                        </button>
                    </>
                ) : (
                    <>
                        <h1 className="text-4xl font-bold font-montserrat text-[var(--color-accent-primary)]">Loja</h1>
                        <p className="text-[var(--color-text-secondary)] mt-2">Produtos exclusivos dos nossos parceiros.</p>
                    </>
                )}
            </header>

            <div className="bg-black/20 p-4 rounded-xl border border-[var(--color-border)] mb-8 flex flex-col md:flex-row items-center gap-4">
                <input 
                    type="text"
                    placeholder="Buscar por nome do produto..."
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="form-control !py-2 flex-grow"
                />
                <div className="flex items-center gap-2 overflow-x-auto">
                    <button onClick={() => setSelectedCategory('all')} className={`text-sm font-semibold px-3 py-1 rounded-full whitespace-nowrap ${selectedCategory === 'all' ? 'bg-yellow-400 text-slate-900' : 'bg-slate-700 text-white'}`}>
                        Todas
                    </button>
                    {categories.map(cat => (
                         <button key={cat} onClick={() => setSelectedCategory(cat)} className={`text-sm font-semibold px-3 py-1 rounded-full whitespace-nowrap ${selectedCategory === cat ? 'bg-yellow-400 text-slate-900' : 'bg-slate-700 text-white'}`}>
                            {cat}
                        </button>
                    ))}
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {filteredProducts.map(product => (
                    <div 
                        key={product.id}
                        onClick={() => onViewProduct(product)}
                        className="bg-black/20 rounded-xl overflow-hidden border border-[var(--color-border)] transition-transform hover:-translate-y-1 group flex flex-col cursor-pointer"
                    >
                        <div className="aspect-square w-full overflow-hidden bg-black/20">
                            <img src={product.images[0] || 'https://via.placeholder.com/400'} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                        </div>
                        <div className="p-4 flex flex-col flex-grow">
                            <div className="flex-grow">
                                <h3 className="font-bold truncate">{product.name}</h3>
                                <p className="text-xs text-[var(--color-text-secondary)]">{product.category}</p>
                            </div>
                            <div className="flex justify-between items-center mt-3">
                                <p className="text-lg font-bold text-green-400">R$ {product.price.toFixed(2)}</p>
                                <button 
                                    onClick={(e) => { e.stopPropagation(); onAddToCart(product); }}
                                    className="btn bg-[var(--color-accent-primary)] text-slate-900 !py-1 !px-3"
                                >
                                    Adicionar
                                </button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
             {filteredProducts.length === 0 && (
                <div className="text-center py-16 text-slate-400">
                    <h3 className="text-xl font-semibold">
                        {isStoreOwner ? 'Você ainda não tem produtos' : 'Nenhum produto encontrado'}
                    </h3>
                    <p>
                        {isStoreOwner ? 'Clique em "Adicionar Novo Produto" para começar a vender.' : 'Tente ajustar seus filtros de busca.'}
                    </p>
                </div>
             )}
        </div>
    );
};

export default ShopView;