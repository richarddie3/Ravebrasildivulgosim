import { 
    RaveEvent, EventCategory, User, UserType, UserProfile, RBLevel,
    Task, Campaign, CampaignApplication, Invitation, Excursion, Passenger, 
    ExcursionApplication, GigApplication, PerformanceApplication, TicketSale, 
    Notification, RBTransaction, DailyMission, RewardStoreItem, DecorationProject,
    Equipment, Product, Message, Conversation, Post, Track, Performance, Photo,
    Video, Order, CoverageRequest, SocialPlatform, Placement, PostComment,
    ProductCategory
} from '../types.ts';

// Helper to create a deep copy to avoid mutation issues
const deepCopy = <T>(obj: T): T => JSON.parse(JSON.stringify(obj));

const today = new Date();
const currentYear = today.getFullYear();
const currentMonth = today.getMonth(); // 0-11
const currentDate = today.getDate();

const categories = Object.values(EventCategory);

// Generate dynamic sample events to ensure they are always visible
const sampleEvents: Omit<RaveEvent, 'id' | 'organizerId' | 'services' | 'comments' | 'gallery' | 'videos'>[] = [];

// 1. Universo Paralello - always upcoming new year
sampleEvents.push({
    name: 'Universo Paralello',
    category: EventCategory.FESTIVAL,
    dates: [`${currentYear}-12-27`, `${currentYear}-12-28`, `${currentYear}-12-29`, `${currentYear}-12-30`, `${currentYear}-12-31`, `${currentYear + 1}-01-01`, `${currentYear + 1}-01-02`, `${currentYear + 1}-01-03`],
    dateString: `27/Dez a 03/Jan`,
    location: 'Praia de Pratigi, BA',
    tickets: [
        { id: 't1', name: 'Lote 3', price: 1200, quantity: 5000, sold: 4800 },
        { id: 't2', name: 'Lote 4', price: 1450, quantity: 2000, sold: 0 },
    ],
    description: 'O maior festival de cultura alternativa do Brasil, celebrando a virada de ano com muita música e arte.',
    image: 'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60',
    commissionRate: 0.1,
});

// 2. XXXPerience - November of current or next year
const xxxYear = (currentMonth > 10 || (currentMonth === 10 && currentDate > 15)) ? currentYear + 1 : currentYear;
sampleEvents.push({
    name: 'XXXPerience',
    category: EventCategory.FESTIVAL,
    dates: [`${xxxYear}-11-15`],
    dateString: `15 de Novembro de ${xxxYear}`,
    location: 'Arena Maeda, Itu/SP',
    tickets: [
        { id: 't3', name: 'Pista Lote 1', price: 250, quantity: 2000, sold: 2000 },
        { id: 't4', name: 'Pista Lote 2', price: 300, quantity: 3000, sold: 1500 },
        { id: 't5', name: 'VIP', price: 450, quantity: 1000, sold: 800 },
    ],
    description: 'Um dos festivais mais tradicionais de música eletrônica do Brasil, comemorando mais uma edição histórica.',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=60',
    commissionRate: 0.1,
});

// 3. Generate a few events for the next few months
let eventDate = new Date();
eventDate.setDate(eventDate.getDate() + 3); // Start 3 days from now

for (let i = 0; i < 15; i++) {
    const dateStr = eventDate.toISOString().split('T')[0];
    const day = eventDate.getDate();
    const monthName = eventDate.toLocaleString('pt-BR', { month: 'long' });

    sampleEvents.push({
        name: `Rave Exemplo #${i + 1}`,
        category: categories[i % categories.length],
        dates: [dateStr],
        dateString: `${day} de ${monthName}`,
        location: 'Local Aleatório, BR',
        tickets: [{ id: `t-dyn-${i}`, name: 'Pista', price: 100 + i * 5, quantity: 500, sold: 50 + i * 10 }],
        description: `Descrição do evento de exemplo #${i + 1}.`,
        image: `https://picsum.photos/800/600?random=${i + 10}`,
        commissionRate: 0.1,
    });

    eventDate.setDate(eventDate.getDate() + (i % 4 + 3)); // Add 3-6 days for the next event
}


const baseProfile: UserProfile = {
    // FIX: Added missing 'username' property to conform to UserProfile.personal type.
    personal: { fullName: '', username: '', birthDate: '', phone: '', profilePicture: null, cpf: '', rg: '' },
    address: { cep: '', street: '', number: '', complement: '', neighborhood: '', city: '', state: '', country: 'Brasil' },
    social: { instagram: '', facebook: '', tiktok: '', linkedin: '', youtube: '', website: '' },
    medical: { 
        bloodType: '', allergies: '', medications: '', conditions: '', 
        emergencyContacts: [{name: '', phone: '', relationship: ''}], 
        chronicDiseases: '', surgeries: '', recentTreatments: '', 
        primaryCarePhysician: { name: '', phone: '', email: '' }, 
        preferredHospital: '', 
        healthInsurance: { provider: '', policyNumber: '', validity: '', category: '', emergencyPhone: '' }, 
        religion: '', specialNeeds: '', medicalDevices: '', 
        lastUpdated: new Date().toISOString(), 
        attachedDocuments: [] 
    }
};

let allUsers: User[] = [
    {
        id: 'user-organizer-1', email: 'organizador@demo.com', roles: [UserType.ORGANIZER, UserType.STORE_OWNER],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Organizador Chefe', username: 'organizadorchefe', profilePicture: 'https://i.pravatar.cc/150?u=org' }},
        plan: 'premium', subscriptionStatus: 'active',
        realBalance: 500.00,
        rbBalance: 15000, rbLevel: RBLevel.PLATINA,
        cart: { items: [], total: 0 },
        followers: ['user-promoter-1'],
        following: ['user-promoter-1', 'user-photographer-1'],
    },
    {
        id: 'user-photographer-1',
        email: 'fotografo@demo.com',
        roles: [UserType.PHOTOGRAPHER],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Click Mágico', username: 'clickmagico', profilePicture: 'https://i.pravatar.cc/150?u=photographer' }},
        portfolio: [], isVerified: true, 
        realBalance: 150.75,
        rbBalance: 850, rbLevel: RBLevel.PRATA,
        cart: { items: [], total: 0 },
        followers: ['user-organizer-1'],
        following: [],
    },
    {
        id: 'user-promoter-1',
        email: 'promoter@demo.com',
        roles: [UserType.PROMOTER, UserType.INFLUENCER, UserType.USER],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'Promoter Top', username: 'promotertop', profilePicture: 'https://i.pravatar.cc/150?u=promoter' }},
        isVerified: true, 
        realBalance: 25.50,
        rbBalance: 1250, rbLevel: RBLevel.PRATA, followingEvents: ['event-2'],
        cart: { items: [], total: 0 },
        followers: ['user-organizer-1'],
        following: ['user-organizer-1'],
    },
    {
        id: 'user-dj-1',
        email: 'dj@demo.com',
        roles: [UserType.DJ],
        profile: { ...deepCopy(baseProfile), personal: { ...baseProfile.personal, fullName: 'DJ Beatmaster', username: 'djbeatmaster', profilePicture: 'https://i.pravatar.cc/150?u=dj' }},
        isVerified: true,
        realBalance: 1200.00,
        rbBalance: 2500, rbLevel: RBLevel.OURO,
        cart: { items: [], total: 0 },
        followers: [],
        following: [],
    },
];

let allEvents: RaveEvent[] = sampleEvents.map((e, i) => ({
    ...e,
    id: `event-${i+1}`,
    organizerId: 'user-organizer-1',
    services: [],
    comments: [],
    gallery: [],
    videos: []
}));

let allTracks: Track[] = [
    { id: 'track-1', userId: 'user-dj-1', title: 'Psychedelic Sunrise', genre: 'Psytrance', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', createdAt: new Date().toISOString(), coverUrl: 'https://picsum.photos/200/200?random=track1', description: 'Uma jornada psicodélica pelo amanhecer.' },
    { id: 'track-2', userId: 'user-dj-1', title: 'Midnight Drive', genre: 'Techno', url: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4', createdAt: new Date(Date.now() - 86400000 * 5).toISOString(), coverUrl: 'https://picsum.photos/200/200?random=track2', description: 'A trilha sonora perfeita para uma viagem noturna.' },
];

let allGigProposals: GigApplication[] = [
    { id: 'prop-1', eventId: 'event-1', djId: 'user-dj-1', status: 'pending' },
];

// Add some initial data for relationships

let allCoverageRequests: CoverageRequest[] = [];
let allTasks: Task[] = [
    { 
        id: 'task-1', 
        eventId: 'event-2', // XXXPerience
        title: 'Post sobre a XXXPerience no Instagram', 
        description: 'Faça um post no feed sobre a próxima XXXPerience, use a #xxxperience e marque o perfil oficial.', 
        deadline: new Date(new Date().setDate(new Date().getDate() + 10)).toISOString().split('T')[0],
        rewardRB: 50,
        platform: SocialPlatform.INSTAGRAM,
        placement: Placement.FEED,
        assigneeId: 'user-promoter-1',
        status: 'completed',
        link: 'https://instagram.com/p/12345'
    },
    { 
        id: 'task-2', 
        eventId: 'event-1', // Universo Paralello
        title: 'Stories sobre o Universo Paralello', 
        description: 'Postar uma sequência de 3 stories sobre a venda de ingressos do Lote 4.', 
        deadline: new Date(new Date().setDate(new Date().getDate() + 5)).toISOString().split('T')[0],
        rewardRB: 25,
        platform: SocialPlatform.INSTAGRAM,
        placement: Placement.STORY,
        assigneeId: 'user-promoter-1',
        status: 'approved'
    },
    { 
        id: 'task-3', 
        eventId: 'event-3', // Rave Exemplo #1
        title: 'Divulgar Rave Exemplo #1 no Facebook', 
        description: 'Compartilhar o evento no seu perfil do Facebook.', 
        deadline: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split('T')[0],
        rewardRB: 15,
        platform: SocialPlatform.FACEBOOK,
        placement: Placement.POST,
        status: 'pending' // No assignee yet
    }
];
let allCampaigns: Campaign[] = [];
let allCampaignApplications: CampaignApplication[] = [];
let allInvitations: Invitation[] = [];
let allExcursions: Excursion[] = [];
let allPassengers: Passenger[] = [];
let allExcursionApplications: ExcursionApplication[] = [];
let allGigApplications: GigApplication[] = [];
let allPerformanceApplications: PerformanceApplication[] = [];
let allTicketSales: TicketSale[] = [];
let allNotifications: Notification[] = [];

let allRbTransactions: RBTransaction[] = [
    { id: 'rbtx1', userId: 'user-promoter-1', type: 'earn-task', description: 'Post no Instagram: XXXPerience', amountRB: 10, timestamp: new Date(Date.now() - 86400000 * 2).toISOString(), status: 'completed' },
    { id: 'rbtx2', userId: 'user-promoter-1', type: 'daily-mission', description: 'Check-in Diário', amountRB: 10, timestamp: new Date(Date.now() - 86400000 * 1).toISOString(), status: 'completed' },
    { id: 'rbtx3', userId: 'user-promoter-1', type: 'earn-task', description: 'Story: Universo Paralello', amountRB: 5, timestamp: new Date().toISOString(), status: 'completed' },
    { id: 'rbtx4', userId: 'user-organizer-1', type: 'purchase', description: 'Compra de Pacote Pro', amountRB: 15000, timestamp: new Date().toISOString(), status: 'completed' },
    { id: 'rbtx5', userId: 'user-photographer-1', type: 'earn-task', description: 'Bônus de Cobertura de Evento', amountRB: 500, timestamp: new Date().toISOString(), status: 'completed' },
];

let allRewardStoreItems: RewardStoreItem[] = [
    { id: 'rew1', name: 'Adesivo Exclusivo DivulgoSim', description: 'Mostre seu apoio com um adesivo de alta qualidade.', icon: '✨', priceRB: 150 },
    { id: 'rew2', name: 'Copo Oficial do Evento X', description: 'Leve uma lembrança para casa.', icon: '🥤', priceRB: 500 },
    { id: 'rew3', name: 'Desconto de 10% no Ingresso', description: 'Use seus RBs para economizar na próxima compra.', icon: '🎟️', priceRB: 1000 },
    { id: 'rew4', name: 'Acesso VIP ao Backstage', description: 'Uma experiência única para os mais dedicados.', icon: '⭐', priceRB: 5000 },
];

let allDailyMissions: DailyMission[] = [{id: 'dm1', title: 'Check-in Diário', description: 'Faça check-in para ganhar RB!', target: 1, progress: 0, rewardRB: 10, isCompleted: false}];
let allDecorationProjects: DecorationProject[] = [];
let allEquipment: Equipment[] = [];
// FIX: Changed 'imageUrl' to 'images' array to match the Product type.
let allProducts: Product[] = [
    { id: 'prod1', storeOwnerId: 'user-organizer-1', name: 'Copo Oficial Universo Paralello', category: ProductCategory.ACCESSORY, price: 45, description: 'Copo ecológico oficial do UP 2025.', images: ['https://picsum.photos/400/400?random=prod1'], stock: 500 },
    { id: 'prod2', storeOwnerId: 'user-organizer-1', name: 'Camiseta XXXPerience 2024', category: ProductCategory.APPAREL, price: 90, description: 'Camiseta de algodão com estampa exclusiva.', images: ['https://picsum.photos/400/400?random=prod2'], stock: 200 },
];
let allMessages: Message[] = [];
let allConversations: Conversation[] = [];
let allPosts: Post[] = [];
let allPerformances: Performance[] = [];
let allPhotos: Photo[] = [];
let allVideos: Video[] = [];
let allOrders: Order[] = [];
