export type CoverageRequestStatus = 'pending' | 'approved' | 'rejected';

export interface CoverageRequest {
    id: string;
    eventId: string;
    photographerId: string;
    status: CoverageRequestStatus;
}


export enum OrderStatus {
    PENDING = 'Pendente',
    PROCESSING = 'Processando',
    SHIPPED = 'Enviado',
    DELIVERED = 'Entregue',
    CANCELED = 'Cancelado',
}

export interface OrderItem {
    productId: string;
    productName: string;
    quantity: number;
    price: number;
}

export interface Order {
    id: string;
    storeOwnerId: string;
    buyerId: string;
    items: OrderItem[];
    total: number;
    status: OrderStatus;
    createdAt: string;
}

export enum ProductCategory {
    TICKET = 'Ingresso',
    APPAREL = 'Vestuário',
    ACCESSORY = 'Acessório',
    DECOR = 'Decoração',
    DIGITAL = 'Digital',
}

export enum ServiceType {
  TRIP = 'Excursão',
  INFLUENCER = 'Influenciador',
  DJ = 'DJ',
  PHOTOGRAPHER = 'Fotógrafo',
  STORE = 'Lojas',
  INTERVENTION = 'Intervenção Artística'
}

export interface Service {
  type: ServiceType;
  providerId: string; // Changed from description to directly link to a user
}

export interface Ticket {
    id: string;
    name: string;
    price: number;
    quantity?: number; // Total available tickets for this lot
    sold?: number;     // Tickets sold for this lot
}

export interface EventComment {
    id: string;
    userId: string;
    userName: string;
    userProfilePicture: string | null;
    text: string;
    createdAt: string; // ISO String
}

export interface Photo {
    id: string;
    userId: string;
    url: string;
    name: string;
    eventId?: string;
    isPublic: boolean;
    createdAt: string;
}

export interface Video {
    id: string;
    userId: string;
    url: string;
    name: string;
    eventId?: string;
    createdAt: string;
}

export enum EventCategory {
    RAVE = 'Rave',
    PVT = 'PVT',
    FESTIVAL = 'Festival',
    AFTER = 'After',
}

export interface RaveEvent {
  id: string;
  organizerId: string;
  name: string;
  category: EventCategory;
  dates: string[]; // ISO date strings (YYYY-MM-DD)
  dateString: string;
  location: string;
  tickets: Ticket[];
  description: string;
  image: string | null;
  services: Service[];
  comments: EventComment[];
  gallery: Photo[];
  videos?: Video[];
  commissionRate?: number; // Default commission rate for promoters
  rbPool?: number; // Organizer's reward pool for this event
  followers?: string[];
}

export enum UserType {
    USER = 'Usuário',
    ORGANIZER = 'Organizador',
    PHOTOGRAPHER = 'Fotógrafo',
    TRIP_ORGANIZER = 'Excursionista',
    INFLUENCER = 'Influenciador',
    PROMOTER = 'Divulgador',
    DJ = 'DJ',
    ARTIST = 'Intervenção Artística',
    STORE_OWNER = 'Lojas',
    SOUND_LIGHTING = 'Som e Iluminação',
    DECORATION = 'Decoração',
}

export interface UserProfile {
    personal: {
        fullName: string;
        username: string;
        birthDate: string;
        phone: string;
        profilePicture: string | null;
        cpf: string;
        rg: string;
    };
    address: {
        cep: string;
        street: string;
        number: string;
        complement: string;
        neighborhood: string;
        city: string;
        state: string;
        country: string;
    };
    social: {
        instagram: string;
        facebook: string;
        tiktok: string;
        linkedin: string;
        youtube: string;
        website: string;
    };
    medical: {
        bloodType: string;
        allergies: string;
        medications: string;
        conditions: string;
        emergencyContacts: {
            id?: string | number;
            name: string;
            phone: string;
            relationship: string;
        }[];
        chronicDiseases: string;
        surgeries: string;
        recentTreatments: string;
        primaryCarePhysician: {
            name: string;
            phone: string;
            email: string;
        };
        preferredHospital: string;
        healthInsurance: {
            provider: string;
            policyNumber: string;
            validity: string;
            category: string;
            emergencyPhone: string;
        };
        religion: string;
        specialNeeds: string;
        medicalDevices: string;
        lastUpdated: string;
        attachedDocuments: { name: string; url: string; }[];
    };
}

export interface PostComment {
    id: string;
    userId: string;
    text: string;
    createdAt: string;
}

export interface Post {
    id: string;
    userId: string;
    mediaUrl?: string;
    mediaType?: 'image' | 'video';
    caption: string;
    createdAt: string;
    likes: string[];
    comments: PostComment[];
}

export interface Track {
    id: string;
    userId: string;
    url: string;
    title: string;
    genre?: string;
    createdAt: string;
    coverUrl?: string;
    description?: string;
}

export interface GigProposal {
    id: string;
    eventId: string;
    djId: string;
    organizerId: string;
    status: 'pending' | 'accepted' | 'rejected';
}

export interface DJStats {
    trackCount: number;
    monthlyListeners: number;
    eventsPlayed: number;
}

export interface Performance {
    id: string;
    userId: string;
    name: string;
    description: string;
    duration: number; // in minutes
    category: string;
    technicalNeeds: string;
    createdAt: string;
}

export enum RBLevel {
    NOVATO = 'Novato', // 0-500 RB
    PRATA = 'Prata',   // 501-2000 RB
    OURO = 'Ouro',     // 2001-5000 RB
    PLATINA = 'Platina' // 5001+ RB
}

export const LEVEL_DATA: Record<RBLevel, { min: number, max: number, name: string }> = {
    [RBLevel.NOVATO]: { min: 0, max: 500, name: 'Novato' },
    [RBLevel.PRATA]: { min: 501, max: 2000, name: 'Prata' },
    [RBLevel.OURO]: { min: 2001, max: 5000, name: 'Ouro' },
    [RBLevel.PLATINA]: { min: 5001, max: Infinity, name: 'Platina' },
};

export interface NotificationSettings {
    partnerships: boolean;
    tasks: boolean;
    comments: boolean;
    messages: boolean;
}

export type UserPlan = 'basic' | 'professional' | 'premium';
export type SubscriptionStatus = 'active' | 'inactive' | 'trial';

export interface CartItem {
    ticketId: string;
    eventId: string;
    eventName: string;
    ticketName: string;
    quantity: number;
    price: number;
}

export interface Cart {
    items: CartItem[];
    total: number;
}

// FIX: Added missing PaymentDetails interface used in PaymentModal.
export interface PaymentDetails {
  items: {
    title: string;
    quantity: number;
    unit_price: number;
  }[];
  payload: any;
}

export interface User {
    id: string;
    email: string;
    password?: string;
    roles: UserType[];
    profile: UserProfile;
    notificationSettings?: NotificationSettings;
    portfolio?: Photo[];
    isVerified?: boolean;
    // Influencer specific
    followerCount?: number;
    engagementRate?: number;
    posts?: Post[];
    // DJ specific
    tracks?: Track[];
    // Artist specific
    performances?: Performance[];
    // Organizer specific
    plan?: UserPlan | null;
    subscriptionStatus?: SubscriptionStatus;
    // Wallet
    realBalance: number;
    rbBalance: number;
    rbLevel: RBLevel;
    cart?: Cart;
    lastCheckInDate?: string; // ISO Date string (YYYY-MM-DD)
    followingEvents?: string[];
    // Social
    followers?: string[];
    following?: string[];
}

export interface Campaign {
    id: string;
    eventId: string;
    organizerId: string;
    name: string;
    description: string;
    payment: number;
    status: 'open' | 'closed';
}

export type CampaignApplicationStatus = 'pending' | 'approved' | 'rejected';

export interface CampaignApplication {
    id: string;
    campaignId: string;
    influencerId: string;
    status: CampaignApplicationStatus;
}

export type GigApplicationStatus = 'pending' | 'approved' | 'rejected';

export interface GigApplication {
    id: string;
    djId: string;
    eventId: string;
    status: GigApplicationStatus;
}

export type PerformanceApplicationStatus = 'pending' | 'approved' | 'rejected';
export interface PerformanceApplication {
    id: string;
    artistId: string;
    eventId: string;
    status: PerformanceApplicationStatus;
}

export type InvitationStatus = 'pending' | 'accepted' | 'declined';

export interface Invitation {
    id: string;
    eventId: string;
    organizerId: string;
    inviteeId: string;
    role: UserType;
    status: InvitationStatus;
    createdAt: string;
}

export interface Excursion {
    id: string;
    tripOrganizerId: string;
    eventId: string;
    name: string;
    departureTime: string;
    returnTime: string;
    meetingPoints: string[];
    price: number;
    capacity: number;
    vehicleType: 'Ônibus' | 'Van' | 'Micro-ônibus' | 'Carro';
    description: string;
    isOfficial: boolean;
    status: 'ativo' | 'em andamento' | 'finalizado';
    imageUrl?: string;
}

export interface Passenger {
    id: string;
    excursionId: string;
    userId: string;
    paymentStatus: 'paid' | 'pending' | 'cancelled';
    checkedIn: boolean;
}

export type ExcursionApplicationStatus = 'pending' | 'approved' | 'rejected';
export interface ExcursionApplication {
    id: string;
    tripOrganizerId: string;
    eventId: string;
    excursionId: string;
    status: ExcursionApplicationStatus;
}

export interface TaskMedia {
    url: string;
    type: 'image' | 'video';
    name: string;
}

export enum SocialPlatform {
    INSTAGRAM = 'Instagram',
    FACEBOOK = 'Facebook',
    TIKTOK = 'TikTok',
    X = 'X (Twitter)',
}

export enum Placement {
    STORY = 'Story',
    FEED = 'Feed',
    REELS = 'Reels',
    POST = 'Post',
}

export interface Task {
    id: string;
    eventId: string;
    title: string;
    description: string;
    deadline: string; // ISO date string YYYY-MM-DD
    media?: TaskMedia;
    platform?: SocialPlatform;
    placement?: Placement;
    rewardRB?: number;
    link?: string;
    assigneeId?: string; // Promoter assigned to the task
    status: 'pending' | 'completed' | 'approved';
}

export enum NotificationType {
    INFO = 'info',
    ALERT = 'alert',
    REQUEST = 'request',
    INVITE = 'invite',
}

export interface Notification {
    id: string;
    userId: string; // The user who should see the notification
    message: string;
    type: NotificationType;
    isRead: boolean;
    createdAt: string; // ISO String
    relatedEntityId?: string; // e.g., eventId, userId
}

export interface TicketSale {
    id: string;
    eventId: string;
    promoterId?: string; // Promoter who sold it
    buyerId?: string; // User who bought it
    ticketId: string;
    ticketName: string;
    quantity: number;
    pricePerTicket: number;
    soldAt: string; // ISO String
}

export interface RBTransaction {
    id: string;
    userId: string;
    type: 'earn-task' | 'redeem-item' | 'withdraw-request' | 'withdraw-fee' | 'achievement' | 'daily-mission' | 'purchase';
    description: string;
    amountRB: number; // can be negative
    timestamp: string; // ISO String
    status: 'completed' | 'pending' | 'rejected';
}

export interface RealTransaction {
    id: string;
    userId: string;
    type: 'deposit' | 'purchase' | 'withdrawal';
    description: string;
    amount: number; // can be negative
    timestamp: string;
    status: 'completed' | 'pending' | 'rejected';
}

export interface DailyMission {
    id: string;
    title: string;
    description: string;
    target: number;
    progress: number;
    rewardRB: number;
    isCompleted: boolean;
}

export interface RewardStoreItem {
    id: string;
    name: string;
    description: string;
    icon: string; // emoji or icon name
    priceRB: number;
}

export interface DecorationProject {
    id: string;
    userId: string;
    name: string;
    description: string;
    coverImage: string;
    images: string[];
    videos?: string[];
}

export type ModalState =
  | { type: null }
  | { type: 'EVENT_FORM'; date?: Date; eventToEdit?: RaveEvent }
  | { type: 'DAY_EVENTS'; date: Date; events: RaveEvent[] }
  | { type: 'EVENT_DETAILS'; event: RaveEvent }
  | { type: 'ALL_EVENTS' }
  | { type: 'LOGIN' }
  | { type: 'REGISTER'; defaultType?: UserType }
  | { type: 'TASK_FORM'; eventId: string }
  | { type: 'MANAGE_EVENT'; event: RaveEvent; defaultTab?: 'tasks' | 'gallery' | 'requests' | 'campaigns' | 'vendas' }
  // FIX: Added optional 'from' property to allow tracking navigation context for the public profile modal.
  | { type: 'PUBLIC_PROFILE'; user: User; event?: RaveEvent; from?: 'MANAGE_EVENT' | 'EVENT_DETAILS'; }
  | { type: 'CREATE_CAMPAIGN'; event: RaveEvent }
  | { type: 'INVITE_USER'; event: RaveEvent }
  | { type: 'CREATE_EXCURSION'; eventId?: string; allEvents?: RaveEvent[]; excursionToEdit?: Excursion }
  | { type: 'UPLOAD_TRACK'; trackToEdit?: Track }
  | { type: 'CREATE_PERFORMANCE'; performanceToEdit?: Performance }
  | { type: 'PRODUCT_FORM'; productToEdit?: Product }
  | { type: 'EQUIPMENT_FORM'; equipmentToEdit?: Equipment }
  | { type: 'MANAGE_EVENT_GALLERY'; event: RaveEvent }
  | { type: 'TICKET_SALES'; event: RaveEvent }
  | { type: 'REWARD_STORE' }
  | { type: 'DECORATION_PROJECT_FORM'; projectToEdit?: DecorationProject }
  | { type: 'WITHDRAWAL' }
  | { type: 'CHANGE_PASSWORD' }
  | { type: 'NOTIFICATION_SETTINGS' }
  | { type: 'DELETE_ACCOUNT' }
  | { type: 'ORGANIZER_BILLING' }
  | { type: 'PRODUCT_DETAILS'; product: Product }
  | { type: 'CART' };

export type AppView = 
  | 'calendar' 
  | 'profile' 
  | 'messages' 
  | 'mainDashboard'
  | 'tasks'
  | 'followedEvents'
  | 'feed'
  | 'shop'
  | 'excursions'
  | 'djDashboard'
  | 'photographerDashboard'
  | 'artistDashboard'
  | 'storeDashboard'
  | 'influencerDashboard'
  | 'soundLightingDashboard'
  | 'decorationDashboard';


export interface Product {
    id: string;
    storeOwnerId: string;
    name: string;
    category: ProductCategory;
    price: number;
    description: string;
    images: string[];
    videos?: string[];
    stock: number; // 0 for digital/unlimited, > 0 for physical
}

export enum EquipmentCategory {
    SOUND = 'Caixa de Som',
    MIXER = 'Mesa de Som',
    LIGHTING = 'Iluminação',
    STRUCTURE = 'Estrutura',
    CABLES = 'Cabos',
    OTHER = 'Outros',
}

export interface Equipment {
    id: string;
    ownerId: string;
    name: string;
    category: EquipmentCategory;
    price: number; // price per day or per event
    description: string;
    images: string[];
    videos?: string[];
    brand?: string;
    voltage?: string; // e.g., '110v', '220v', 'Bivolt'
    power?: string; // e.g., '1000W'
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  text: string;
  timestamp: string; // ISO String
  isRead: boolean;
}

export interface Conversation {
  id: string;
  participants: string[]; // array of user IDs
}

export interface ToastMessage {
  id: number;
  message: string;
  type: 'success' | 'error' | 'info';
}