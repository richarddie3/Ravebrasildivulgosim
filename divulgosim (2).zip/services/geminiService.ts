import { GoogleGenAI, Type } from "@google/genai";
// FIX: Corrected import path for types
import { RaveEvent, Ticket } from "../types.ts";

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.warn("Gemini API key not found. AI features will be disabled.");
}

const fileToGenerativePart = async (file: File) => {
    const base64EncodedDataPromise = new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
            if (typeof reader.result === 'string') {
                resolve(reader.result.split(',')[1]);
            } else {
                reject(new Error("Failed to read file."));
            }
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(file);
    });
    return {
        inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
};

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        name: { type: Type.STRING, description: "The name of the event." },
        category: { type: Type.STRING, description: "The category of the event. Must be one of: 'Rave', 'PVT', 'Festival', 'After'." },
        dateString: { type: Type.STRING, description: "The date or date range of the event as a string (e.g., '15 de Novembro de 2024' or '15 a 17 de Novembro de 2024')." },
        location: { type: Type.STRING, description: "The location of the event." },
        tickets: {
            type: Type.ARRAY,
            description: "List of available ticket tiers and their prices.",
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING, description: "The name of the ticket tier (e.g., 'Lote 1', 'VIP')." },
                    price: { type: Type.NUMBER, description: "The price of the ticket tier." },
                    quantity: { type: Type.INTEGER, description: "Optional. The total quantity of tickets available for this tier." }
                }
            }
        },
        description: { type: Type.STRING, description: "A detailed description of the event, lineup, and attractions." },
    }
};

type GeminiResponse = Omit<Partial<RaveEvent>, 'tickets' | 'gallery'> & { tickets?: Omit<Ticket, 'id'>[] };


export const analyzeEvent = async (text?: string, image?: File): Promise<Partial<RaveEvent>> => {
  if (!ai) {
    throw new Error("API key for Gemini is not configured.");
  }
  
  const promptParts: ({ text: string } | { inlineData: { data: string; mimeType: string } })[] = [];
  const currentYear = new Date().getFullYear();
  let systemInstruction = `Você é um especialista em extrair informações de eventos de música eletrônica (raves). Analise o texto ou a imagem a seguir e extraia os detalhes do evento no formato JSON especificado. Mantenha os detalhes fiéis ao material de origem. A data do evento é crucial. Se o ano não for especificado, presuma que o evento ocorrerá no ano atual, ${currentYear}. A categoria do evento deve ser uma das seguintes: 'Rave', 'PVT', 'Festival', 'After'.`;
  
  if (image) {
      const imagePart = await fileToGenerativePart(image);
      promptParts.push(imagePart);
      promptParts.push({ text: "\nExtraia os detalhes do evento deste flyer. " });
  }
  
  if (text) {
      promptParts.push({ text });
  }

  if (promptParts.length === 0) {
      throw new Error("No content provided for analysis.");
  }

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: promptParts },
        config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json",
            responseSchema: responseSchema,
        },
    });

    const jsonString = response.text.trim();
    if (jsonString) {
        const parsedJson = JSON.parse(jsonString) as GeminiResponse;
        
        // Add unique IDs to the tickets
        const raveEventPartial: Partial<RaveEvent> = {
            ...parsedJson,
            tickets: parsedJson.tickets?.map(t => ({...t, id: `ticket_${Date.now()}_${Math.random()}`}))
        };
        return raveEventPartial;
    }
    return {};

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to analyze event details with AI.");
  }
};

export const generateAdvancedThemeCss = async (prompt: string): Promise<string> => {
  if (!ai) {
    throw new Error("API key for Gemini is not configured.");
  }

  const systemInstruction = `Você é um especialista em design de UI/UX e CSS. Sua tarefa é gerar um tema CSS avançado para uma aplicação web com base na descrição do usuário. O tema deve ser encapsulado em um seletor ':root' e usar apenas variáveis CSS. O tema deve incluir, no mínimo, as seguintes variáveis:
--color-bg-primary: A cor de fundo principal (geralmente escura).
--color-bg-secondary: A cor de fundo para elementos secundários como modais e painéis.
--color-text-primary: A cor do texto principal.
--color-text-secondary: A cor do texto secundário, para legendas e informações menos importantes.
--color-accent-primary: A cor de destaque principal, usada para botões, links e elementos importantes.
--color-accent-secondary: Uma segunda cor de destaque, para interações secundárias ou estados de hover.
--color-border: A cor para bordas sutis.
--color-success: Cor para feedback de sucesso (geralmente um tom de verde).
--color-danger: Cor para feedback de erro (geralmente um tom de vermelho).
--font-primary: A fonte principal a ser usada. Use fontes do Google Fonts.
--font-secondary: Uma fonte secundária, se aplicável (por exemplo, para títulos).
Adicione efeitos sutis como sombras de texto ou brilhos ('glow') que combinem com o tema, especialmente para as cores de destaque.
Responda APENAS com o bloco de código CSS. Não inclua a palavra 'css' ou backticks (\`\`\`) no início ou no fim.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
      },
    });

    const css = response.text.trim();
    // Clean up potential markdown code block fences
    return css.replace(/```css|```/g, '').trim();
  } catch (error) {
    console.error("Error calling Gemini API for theme generation:", error);
    throw new Error("Failed to generate theme with AI.");
  }
};